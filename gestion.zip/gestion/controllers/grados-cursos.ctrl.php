<?php

require_once '/var/www/CAS/config.inc.php';
// Load the CAS lib
require_once $phpcas_path . '/CAS.php';
require_once '/var/www/Front/clases.inc.php';

// Call to models
require_once '../models/grado.mdl.php';
require_once '../models/grupo.mdl.php';
require_once '../models/progreso.mdl.php';

$grade  = new dbCoursesGrades;
$group = new dbGroups;
$progress = new dbProgress;

// Uncomment to enable debugging
phpCAS::setDebug();

// Initialize phpCAS
phpCAS::client(CAS_VERSION_2_0, $cas_host, $cas_port, $cas_context);

phpCAS::setNoCasServerValidation();
// phpCAS::setCasServerCACert($cas_server_ca_cert_path);
// force CAS authentication
phpCAS::forceAuthentication();

$yo = new Usuario(phpCAS::getUser());


if (!isset($_SESSION['idCol']) || empty($_SESSION['idCol'])) {
    $inst = new Institucion($yo->institucion());
} else {
    $inst = new Institucion($_SESSION['idCol']);
}


if (isset($_POST['grado'])) {
    $grado = $_POST['grado'];
    $res = $grade->createGrade($inst->id(), $grado);
    if ($res) {
        echo true;
    } else {
        echo "Error en la consulta en el ingreso del grado " . $grado . ". Consulte con el desarrollador";
    }
}
elseif (isset($_POST['tipoGrupo'])) {
    $tipoGrado = $_POST['tipoGrupo'];
    $res = $group->createTypeGroup($inst->id(), $tipoGrado);
    if ($res) {
        echo true;
        echo "progress". $progress->insertProgress($inst->id(), 2,1);
    } else {
        echo "Error en la consulta en el ingreso del tipo de grado Consulte con el desarrollador";
    }
}
elseif (isset($_POST['function'])) {
    $function = $_POST['function'];
    if ($function == 'get_info') {
        $res = $grade->searchGrade($inst->id());
        if ($res) {
            echo json_encode($res);
        } else {
            echo false;
        }
    } else if ($function == 'get_type') {
        $res = $group->searchTypeGroup($inst->id());
        echo $res;
    }
    $progress->insertProgress($inst->id(), 1, 1);
}
elseif (isset($_POST['getProgress'])) {
    echo ($progress->getProgress($inst->id())) * 100 / 11;
}

elseif (isset($_POST['getProgressPestana'])) {
    echo json_encode($progress->getProgressPestana($inst->id()));
}
elseif(isset($_POST['setGroupe'])){
    echo $group->createGroup($inst->id(), $_POST['setGroupe'], $_POST['setCourses'] );
    $progress->insertProgress($inst->id(), 3,1);
}
elseif(isset($_POST['getGroups'])){
    echo json_encode($group->searchGroup($inst->id()));
}
elseif (isset($_POST['setFind'])) {
    echo $progress->insertProgress($inst->id(), 2, 6);
}
