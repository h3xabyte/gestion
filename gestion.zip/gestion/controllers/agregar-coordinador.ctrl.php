<?php


require_once '/var/www/CAS/config.inc.php';
// Load the CAS lib
require_once $phpcas_path . '/CAS.php';
require_once '/var/www/Front/clases.inc.php';

// Call to models
require_once '../models/progreso.mdl.php';
require_once '../models/grupos_materias.mdl.php';
require_once '../models/asignatura.mdl.php';
require_once '../models/grado.mdl.php';
require_once '../models/grupo.mdl.php';
require_once '../models/usuarios.mdl.php';
require_once '/var/www/Front/resources/php/libs/PHPExcel/PHPExcel.php';


$subject = new dbSubject;
$progress = new dbProgress;
$grade  = new dbCoursesGrades;
$group = new dbGroups;
$group_subject = new dbGroupsSubjects;
$user = new dbUsers;

// Uncomment to enable debugging
phpCAS::setDebug();

// Initialize phpCAS
phpCAS::client(CAS_VERSION_2_0, $cas_host, $cas_port, $cas_context);

phpCAS::setNoCasServerValidation();
// phpCAS::setCasServerCACert($cas_server_ca_cert_path);
// force CAS authentication
phpCAS::forceAuthentication();

$yo = new Usuario(phpCAS::getUser());

if (!isset($_SESSION['idCol']) || empty($_SESSION['idCol'])) {
    $inst = new Institucion($yo->institucion());
} else {
    $inst = new Institucion($_SESSION['idCol']);
}


if (isset($_POST['setSubject'])) {
    if ($_POST['setSubject'] != '') {
        echo $subject->createSubject($inst->id(), $_POST['setSubject']);
    } else {
        echo "error_void";
    }
} elseif (isset($_POST['getSubject'])) {
    echo json_encode($subject->searchSubject($inst->id()));
} elseif (isset($_POST['setUser'])) {
    $nombre = strip_tags(trim($_POST['setName']));
    $apellido = strip_tags(trim($_POST['setLastName']));
    $correo = strip_tags(trim($_POST['setEmail']));
    $tipo = 'coordinador';
    $movil = strip_tags(trim($_POST['setMovil']));
    $pin = 0;
    $bytes = openssl_random_pseudo_bytes(3);
    $hex   = bin2hex($bytes);
    $permitted_chars = 'abcdefghjkmnpqrstuvwxyz';

    $hex  = str_replace(0, rand(1, 15), $hex);

    if ($nombre != null && $apellido != null && $correo != null && $movil != null) {
        if ($correo == 'sie@educar.com.co' || $correo == 'solicitudesit@educar.com.co' || $correo == 'notificaciones@educar.com.co' || $correo == 'noreply@educar.com.co') {
            echo "error_email";
        } else {
            $nombre = str_replace(
            array('Á', 'É', 'Í', 'Ó', 'Ú', 'á', 'é', 'í', 'ó', 'ú', 'Ñ', 'ñ'),
            array('A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u', 'N', 'n'),
            $nombre
            );
            $apellido = str_replace(
            array('Á', 'É', 'Í', 'Ó', 'Ú', 'á', 'é', 'í', 'ó', 'ú', 'Ñ', 'ñ'),
            array('A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u', 'N', 'n'),
            $apellido
            );

            if (!strpos($nombre, ' ')) {
                $usuario =  $nombre."-".explode(" ",$apellido)[0]. rand(100, 999);
            }else{
                $countspaces = count(explode(" ",$nombre));
                for ($i=0; $i < $countspaces; $i++) { 
                    if (count(explode(" ",$nombre)[$i]) > 0) {
                        $usuario =  explode(" ",$nombre)[$i]."-".explode(" ",$apellido)[0]. rand(100, 999);
                        break;
                     }
                }
            }
            $create = false;
            do {
                if (!$yo->existe($usuario)) {
                    if ($yo->crear($usuario, $nombre, $apellido, $correo, $hex, $tipo, $movil, $yo->usuario(), null, null)) {
                        $create = true;
                        break;
                    }
                } else {
                    if (!strpos($nombre, ' ')) {
                        $usuario =  $nombre."-".explode(" ",$apellido)[0]. rand(100, 999);
                    }else{
                        $countspaces = count(explode(" ",$nombre));
                        for ($i=0; $i < $countspaces; $i++) { 
                            if (count(explode(" ",$nombre)[$i]) > 0) {
                                $usuario =  explode(" ",$nombre)[$i]."-".explode(" ",$apellido)[0]. rand(100, 999);
                                break;
                             }
                        }
                    }
                }
            } while ($create);

            if ($create) {
                $progress->insertProgress($inst->id(), 1, 3);
                echo $hex . "u-" . $usuario;
            }
        }
    } else {
        echo "error_all_data";
    }
} elseif (isset($_POST['getGroups'])) {
    echo json_encode($group->searchGroup($inst->id()));
} elseif (isset($_POST['function'])) {
    $function = $_POST['function'];
    if ($function == 'get_info') {
        $res = $grade->searchGrade($inst->id());
        if ($res) {
            echo json_encode($res);
        } else {
            echo false;
        }
    } else if ($function == 'get_type') {
        $res = $group->searchTypeGroup($inst->id());
        echo $res;
    }
} elseif (isset($_POST['setUserSubject'])) {
    $groupRegist = $_POST['setGroup'];
    $courseRegist = $_POST['setCourse'];
    $subj =  $_POST['setSubjectID'];
    $teach = $_POST['setTeach'];
    $idTeach =  $user->searchUserByUsername($teach);

    $inst->asociar_materia($courseRegist, $subj);
    $newCourse = new Curso($groupRegist);
    $newCourse->matricular($idTeach, false, $subj);
    echo true;
} elseif (isset($_POST['editUserSubject'])) {
    $groupRegist = $_POST['setGroup'];
    $courseRegist = $_POST['setCourse'];
    $subj =  $_POST['setSubjectID'];
    $teach = $_POST['setTeach'];
    $newCourse = new Curso($groupRegist);
    if ($_POST['setCheck'] == "true") {
        $inst->asociar_materia($courseRegist, $subj);
        $newCourse->matricular($teach, false, $subj);
    } else {
        $newCourse->desmatricular($teach, false, $subj);
    }
    echo "ok";
} elseif (isset($_POST['delUserSubject'])) {
    $groupRegist = $_POST['setGroup'];
    $courseRegist = $_POST['setCourse'];
    $subj =  $_POST['setSubjectID'];
    $teach = $_POST['setTeach'];
    $newCourse = new Curso($groupRegist);
    $newCourse->desmatricular($teach, false, $subj);
    echo "ok";
} elseif ($_POST['getInfoTeachs']) {
    $usuarios = json_decode($inst->listar_carga_coordinadores());
    foreach ($usuarios as $key => $value) {
        $user = new Usuario($value->usuario);
        $value->clave = base64_decode($user->clave());
    }
    echo json_encode($usuarios);
} elseif ($_POST['downUsers']) {

    $objPHPExcel = new PHPExcel();
    $objPHPExcel->getProperties()
        ->setCreator("SIE")
        ->setLastModifiedBy("SIE-Informes")
        ->setTitle("Usuarios plataforma SIE para " . $inst->nombre(true))
        ->setSubject("Usuarios plataforma SIE")
        ->setDescription("Usuarios plataforma SIE")
        ->setKeywords("Usuarios plataforma SIE")
        ->setCategory("Usuarios plataforma SIE");


    $periodo = explode(' ', $objPeriodo->periodo)[1];
    $objPHPExcel->setActiveSheetIndex(0)
        ->setCellValue('A1', 'FECHA INFORME: ' . date('d-m-Y H:i:s'))
        ->setCellValue('A2', $inst->nombre(true))
        ->setCellValue('A3', 'INFORME DE USUARIOS Y CONTRASEÑAS DE LOS COORDINADORES')
        ->setCellValue('A4', 'NOMBRES')
        ->setCellValue('B4', 'APELLIDOS')
        ->setCellValue('C4', 'USUARIO')
        ->setCellValue('D4', 'CONTRASEÑA')
        ->setCellValue('E4', 'MATERIAS');

    foreach (range('A', 'E') as $columnID) {
        $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)
            ->setWidth('50');
    }


    $styleArrayNombreColegio = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        ),
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 20,
            'name'  => 'Levenim MT',
        )
    );

    $styleArrayTittle = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        ),
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => 'FFFFFF'),
            'size'  => 12,
            'name'  => 'Levenim MT',
        )
    );

    $styleArray = array(
        'borders' => array(
            'allborders' => array(
                'style' => PHPExcel_Style_Border::BORDER_THIN,
                'color' => array('rgb' => 'DDDDDD')
            )
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        ),
        'font'  => array(
            'bold'  => false,
            'color' => array('rgb' => '000000'),
            'size'  => 10,
            'name'  => 'Levenim MT'
        )
    );

    $styleArrayInfo = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        ),
        'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => '000000'),
            'size'  => 12,
            'name'  => 'Levenim MT'
        )
    );

    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:E1');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A2:E2');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A3:E3');

    $objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray($styleArrayNombreColegio);


    $objPHPExcel->getActiveSheet()->getStyle('A1')->applyFromArray($styleArrayInfo);
    $objPHPExcel->getActiveSheet()->getStyle('A3')->applyFromArray($styleArrayInfo);
    $objPHPExcel->getActiveSheet()->getStyle('E3')->applyFromArray($styleArrayInfo);
    $objPHPExcel->getActiveSheet()->getStyle('A4')->applyFromArray($styleArrayTittle);
    $objPHPExcel->getActiveSheet()->getStyle('B4')->applyFromArray($styleArrayTittle);
    $objPHPExcel->getActiveSheet()->getStyle('C4')->applyFromArray($styleArrayTittle);
    $objPHPExcel->getActiveSheet()->getStyle('D4')->applyFromArray($styleArrayTittle);
    $objPHPExcel->getActiveSheet()->getStyle('E4')->applyFromArray($styleArrayTittle);

    $infoPass = $user->searchPasswordUser($inst->id());
    $infoTeachs = json_decode($inst->listar_carga_coordinadores());
    $iterador = 6;
    $infoFinal = [];

    foreach ($infoTeachs as $key => $value) {
        foreach ($infoPass as $key => $valuePass) {
            if ($value->usuario == $valuePass->usuario) {
                $objectFinal = new stdClass();
                $objectFinal->nombres = $value->nombres;
                $objectFinal->apellidos = $value->apellidos;
                $objectFinal->usuario = $value->usuario;
                $objectFinal->clave = $valuePass->clave;
                $objectFinal->cursos = '';
                $infoFinal[] = $objectFinal;
            }
        }
    }

    foreach ($infoFinal as $key => $value) {
        foreach ($infoTeachs as $key => $valueTeach) {
            if ($valueTeach->usuario == $value->usuario && $valueTeach->curso != "******") {
                $value->cursos = $value->cursos . $valueTeach->curso . ", ";
            }
        }
    }

    $infoClean = [];

    foreach ($infoFinal as $key => $value) {
        $validate = false;
        foreach ($infoClean as $key => $valueClean) {
            if ($value->usuario == $valueClean->usuario) {
                $validate = true;
            }
        }
        if (!$validate) {
            $infoClean[] = $value;
        }
    }

    foreach ($infoClean as $key => $value) {
        $objPHPExcel->getActiveSheet()->getStyle('A' . $iterador . '')->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('B' . $iterador . '')->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('C' . $iterador . '')->applyFromArray($styleArray);
        $objPHPExcel->getActiveSheet()->getStyle('D' . $iterador . '')->applyFromArray($styleArray);

        $objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(-1);
        $objPHPExcel->getActiveSheet()->getStyle('E')->getAlignment()->setWrapText(true);
        $objPHPExcel->getActiveSheet()->getStyle('A' . $iterador . ':D' . $iterador)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);

        if ($value->clave == '' || $value->clave == NULL || !$value->clave) {
            $value->clave = "NULL";
        } else {
            $value->clave = base64_decode($value->clave);
        }

        $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A' . $iterador, $value->nombres)
            ->setCellValue('B' . $iterador, $value->apellidos)
            ->setCellValue('C' . $iterador, $value->usuario)
            ->setCellValue('D' . $iterador, $value->clave)
            ->setCellValue('E' . $iterador, $value->cursos);
        $iterador++;
    }

    $celdas = "A" . ($iterador + 1) . ":E" . ($iterador + 1);
    $style = array(
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        )
    );
    $objPHPExcel->getDefaultStyle()->applyFromArray($style);
    $objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(-1);
    $objPHPExcel->getActiveSheet()->getStyle('A:E')->getAlignment()->setWrapText(true);
    $objPHPExcel->getActiveSheet()->setCellValue("B" . ($iterador + 1), "\n\n\n");


    $objPHPExcel->getActiveSheet()->getStyle($celdas)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
    $objPHPExcel->getActiveSheet()->getStyle($celdas)->getFill()->getStartColor()->setARGB('323232');
    $objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
    $objPHPExcel->getActiveSheet()->getStyle('A4:E4')->getFill()->getStartColor()->setARGB('0097B6');

    $objDrawing = new PHPExcel_Worksheet_Drawing();    //create object for Worksheet drawing
    $objDrawing->setName('Customer Signature');
    $objDrawing->setDescription('Customer Signature'); //set description to image
    $path = __DIR__ . '/../assets/img/src/logo1.png';
    $objDrawing->setPath($path);
    $objDrawing->setOffsetX(25);                       //setOffsetX works properly
    $objDrawing->setOffsetY(10);                       //setOffsetY works properly
    $objDrawing->setCoordinates('E' . ($iterador + 1));        //set image to cell
    $objDrawing->setWidth(55);
    $objDrawing->setHeight(55);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());  //save

    $objDrawing = new PHPExcel_Worksheet_Drawing();    //create object for Worksheet drawing
    $objDrawing->setName('Customer Signature');
    $objDrawing->setDescription('Customer Signature'); //set description to image
    $path = __DIR__ . '/../assets/img/src/logo2.png';
    $objDrawing->setPath($path);
    $objDrawing->setOffsetX(25);                       //setOffsetX works properly
    $objDrawing->setOffsetY(10);                       //setOffsetY works properly
    $objDrawing->setCoordinates('A' . ($iterador + 1));        //set image to cell
    $objDrawing->setWidth(55);
    $objDrawing->setHeight(55);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());  //save

    $progress->insertProgress($inst->id(), 2, 3);

    // indicar que se envia un archivo de Excel.
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="Informe usuarios y contraseñas SIE.xlsx"');
    header('Cache-Control: max-age=0');
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
}
