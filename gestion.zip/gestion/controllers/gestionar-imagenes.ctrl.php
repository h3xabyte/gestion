<?php

require_once '/var/www/CAS/config.inc.php';
// Load the CAS lib
require_once $phpcas_path . '/CAS.php';
require_once '/var/www/Front/clases.inc.php';

// Uncomment to enable debugging
phpCAS::setDebug();

// Initialize phpCAS
phpCAS::client(CAS_VERSION_2_0, $cas_host, $cas_port, $cas_context);

phpCAS::setNoCasServerValidation();
// phpCAS::setCasServerCACert($cas_server_ca_cert_path);
// force CAS authentication
phpCAS::forceAuthentication();

// Functions for BaseD
require_once '../models/imagenes.mdl.php';
require_once '../models/progreso.mdl.php';

$image = new dbImages;
$progress = new dbProgress;


$yo = new Usuario(phpCAS::getUser());

if (!isset($_SESSION['idCol']) || empty($_SESSION['idCol'])) {
    $inst = new Institucion($yo->institucion());
} else {
    $inst = new Institucion($_SESSION['idCol']);
}

if(isset($_POST['setImage']))
{
    $imagePost = $_POST['setImage'];
    $clase = $_POST['setClassImage'];
    $imageParts = explode(";base64,", $imagePost);
    $type = $_POST['setTypeImage'];
    $size = $_POST['setSizeImage'];
    $imageReal = base64_decode($imageParts[1]);
    $count = $image->countImages($inst->id());
    $res = $image->searchImagesForResource($inst->id());
    $validateShieldExist = new stdClass();
    $validateShieldExist->validate = false;

    if (!file_exists("/var/www/Front/images/portadas/".$inst->nombre())) {
       mkdir("/var/www/Front/images/portadas/".$inst->nombre(), 0770);
    }

    if($res[1] && $clase == 'shield'){
        foreach ($res[1] as $key => $value) {
            if ($value->clase == 'shield') {
                $validateShieldExist->validate = true;
                $validateShieldExist->url = $value->url;
                break;
            }
        }
    }
    if ($count < 5 || $clase == 'shield') {
        if($validateShieldExist->validate){
                $dir = "/var/www/Front/images/portadas/".$inst->nombre()."/";
                $directorio = opendir($dir); //ruta actual
                while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
                {
                    if (!is_dir($archivo))//verificamos si es o no un directorio
                    {
                        if (strpos($archivo, 'shield')) {
                            unlink($dir.$archivo);
                            exec("cd ".$dir." && chmod -R 7777 ./".$archivo);
                            exec("cd ".$dir." && rm -r ./".$archivo);
                            "deleted -".$archivo."\n";
                        }else{
                            "not deleted -". $archivo."\n";
                        }
                    }
                }      
                    
                $azar = rand(0,999);
                $elemento = explode("=",$validateShieldExist->url)[1];
                $dir = "/var/www/Front/images/portadas/".$inst->nombre()."/1-shield-".$azar.str_replace("image/", ".", $type);
                if ($size < 1048576) {
                    if (file_put_contents($dir, $imageReal)) {
                        echo "updateOk";
                    }else{
                        echo "notUpdate";
                    }
                }else{
                    echo "imagen excede tamaño";
                }
        }else{
            if ($res == 'error_limit') {
                echo 'updateOk';
            }else{
                if ($clase == 'shield') {                    
                    $nameImage = "1-shield".str_replace("image/", ".", $type);
                    $dir = "/var/www/Front/images/portadas/".$inst->nombre()."/".$nameImage;
                }else{
                    $nameImage = str_replace(")", "", str_replace("(", "", $_POST['setNameImage']));
                    for ($i=0; $i < 10; $i++) { 
                        $dir = "/var/www/Front/images/portadas/".$inst->nombre()."/".$nameImage;
                        if (file_exists($dir)) {
                            $nameImage = str_replace(".", "dt".$i.".", $_POST['setNameImage']);
                        }else{
                            break;                            
                        }
                    }
                }
                if ($size < 3048576 && $size > 0) {
                    if (file_put_contents($dir, $imageReal)) {
                        $recurso =  $inst->id();                      
                        $url = str_replace(" ", "%20", "http://sie.educar.com.co/images/portadas/".$inst->nombre()."/".$nameImage);
                        $image->addImage($recurso, $type, $nameImage, $url, $clase);
                        echo "upOk";
                    }else{
                        echo "notUpdates";
                    }
                }else{
                    echo "imagen excede tamaño";
                }
            }
        }
    }else{
        echo 'error_limit';
    }
    $progress->insertProgress($inst->id(), 1, 6);

}elseif (isset($_POST['getImageShield'])) {
    $res = $image->searchImagesForResource($inst->id());
    if ($res) {
        echo json_encode($res[1]);
    }
}elseif (isset($_GET['showImage'])) {
    $file = $_GET['showImage'];
    $nameSchool = $_SESSION['nameSchool'];
    $dir = "/var/www/Front/images/portadas/".$nameSchool."/{$file}";
    header("Content-Disposition: attachment; filename=explode('.', $file)[0]");
    header("Content-Type: explode('.', $file)[1]");
    readfile($dir);
}elseif (isset($_POST['deleteImageBanner'])) {
    echo $image->deleteImage($inst->id(), $_POST['deleteImageBanner']);
}
