<?php

   require_once '/var/www/CAS/config.inc.php';
   // Load the CAS lib
   require_once $phpcas_path . '/CAS.php';
   require_once '/var/www/Front/clases.inc.php';

   // Call to models
   // require_once '../models/progreso.mdl.php';
   require_once '../models/usuarios.mdl.php';
   require_once '/var/www/Front/resources/php/libs/PHPExcel/PHPExcel.php';
   $user = new dbUsers;
   // $subject = new dbSubject;
   // Uncomment to enable debugging
   phpCAS::setDebug();

   // Initialize phpCAS
   phpCAS::client(CAS_VERSION_2_0, $cas_host, $cas_port, $cas_context);

   phpCAS::setNoCasServerValidation();
   // phpCAS::setCasServerCACert($cas_server_ca_cert_path);
   // force CAS authentication
   phpCAS::forceAuthentication();

   $yo = new Usuario(phpCAS::getUser());

   if (!isset($_SESSION['idCol']) || empty($_SESSION['idCol'])) {
      $inst = new Institucion($yo->institucion());
   } else {
      $inst = new Institucion($_SESSION['idCol']);
   }

   if (isset($_POST['setUsersAsign'])) {
      if (isset($_POST['setDuplicate']) && $_POST['setDuplicate'] == 'false' && isset($_POST['setNumberLength']) && $_POST['setNumberLength'] == 'false') {
            $nombre = $_POST['setName'];
            $apellido = strip_tags(trim($_POST['setLastName']));
            $correo = strip_tags(trim($_POST['setEmail']));
            $tipo = $_POST['setType'];
            $movil = strip_tags(trim($_POST['setMovil']));
            $courses = $_POST['setCourses'];
            $pin = 0;
            $bytes = openssl_random_pseudo_bytes(3);
            $hex   = bin2hex($bytes);
            $permitted_chars = 'abcdefghjkmnpqrstuvwxyz';

      
            $hex  = str_replace(0, rand(1,9), $hex);
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            if (
                  $nombre != null && $apellido != null && $correo != null && $movil != null 
               && $nombre != 'undefined' && $apellido != 'undefined' && $correo != 'undefined' && $movil != 'undefined'
               && $nombre != 'NULL' && $apellido != 'NULL' && $correo != 'NULL' && $movil != 'NULL'
               ) {
               if ($correo == 'sie@educar.com.co' || $correo == 'solicitudesit@educar.com.co' || $correo == 'notificaciones@educar.com.co' || $correo == 'noreply@educar.com.co') {
                  echo "error_email";
               }else{
                  $nombre = str_replace(
                  array('Á', 'É', 'Í', 'Ó', 'Ú', 'á', 'é', 'í', 'ó', 'ú', 'Ñ', 'ñ'),
                  array('A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u', 'N', 'n'),
                  $nombre
                  );
                  $apellido = str_replace(
                  array('Á', 'É', 'Í', 'Ó', 'Ú', 'á', 'é', 'í', 'ó', 'ú', 'Ñ', 'ñ'),
                  array('A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u', 'N', 'n'),
                  $apellido
                  );
                     if (!strpos($nombre, ' ')) {
                           $usuario =  $nombre."-".explode(" ",$apellido)[0]. rand(100, 999);
                     }else{
                           $countspaces = count(explode(" ",$nombre));
                           for ($i=0; $i < $countspaces; $i++) { 
                              if (count(explode(" ",$nombre)[$i]) > 0) {
                                 $usuario =  explode(" ",$nombre)[$i]."-".explode(" ",$apellido)[0]. rand(100, 999);
                                 break;
                              }
                           }
                     }
                     $create = false;
                     $i = 0;
                     do {
                        $i++;
                        if (!$yo->existe($usuario)) {
                              if (strlen($nombre) > 1 && strlen($apellido) > 1) {
                                 $createUser = $yo->crear($usuario, $nombre, $apellido, $correo, $hex, $tipo, $movil, $yo->usuario(), null, null);
                                 $create = true;
                                 if ($createUser) {
                                    break;
                                 }
                              }else {
                                 echo "none_name";
                              }
                        }
                        else{
                           if (!strpos($nombre, ' ')) {
                              $usuario =  $nombre."-".explode(" ",$apellido)[0]. rand(100, 999);
                          }else{
                              $countspaces = count(explode(" ",$nombre));
                              for ($i=0; $i < $countspaces; $i++) { 
                                  if (count(explode(" ",$nombre)[$i]) > 0) {
                                      $usuario =  explode(" ",$nombre)[$i]."-".explode(" ",$apellido)[0]. rand(100, 999);
                                      break;
                                   }
                              }
                          }
                        }
                        if ($i == 3) {
                           die;
                        }
                     } while (!$yo->existe($usuario));
   
                     if ($create == true) {
                        $groups = json_decode($courses, true);
                        foreach ($groups as $key => $data) {                  
                           foreach ($data['groups'] as $key => $value) {
                              # code...
                              if ($value['check']) {
                                 $groupRegist = $value['idGroup'];
                                 $courseRegist = $value['idCourse'];
                                 $subj =  $value['idAsign'];
                                 $teach = $usuario;
                                 $idTeach =  $user->searchUserByUsername($teach);   
                                 $inst->asociar_materia($courseRegist, $subj);
                                 $newCourse = new Curso($groupRegist);
                                 $newCourse->matricular($idTeach, false, $subj); 
                              }
                           }
                        }                 
                     }  
                     echo 'complete';  
                  
               }   
      
         }else{
               echo "error_all_data";
         }
      }else{
         echo "duplicate";
      }

}else if ($_POST['downFormat']) {


      $objPHPExcel = new PHPExcel();
      $objPHPExcel->getProperties()
          ->setCreator("SIE")
          ->setLastModifiedBy("SIE-Informes")
          ->setTitle("Formato Usarios SIE para ".$inst->nombre(true))
          ->setSubject("Formato Usarios SIE")
          ->setDescription("Formato Usarios SIE")
          ->setKeywords("Formato Usarios SIE")
          ->setCategory("Formato Usarios SIE");
          
          
          $periodo = explode(' ', $objPeriodo->periodo)[1];
          $objPHPExcel->setActiveSheetIndex(0)
          ->setCellValue('A1', 'Nombres')
          ->setCellValue('B1', 'Apellidos')
          ->setCellValue('C1', 'Correo')
          ->setCellValue('D1', 'Celular')
          ->setCellValue('E1', 'Formato de importacion de usuarios')
          ->setCellValue('E10', 'Por favor ingrese todos los datos de los docentes en su respectiva columna.')
          ;
          
          foreach(range('A','D') as $columnID) {
             $objPHPExcel->getActiveSheet()->getColumnDimension($columnID)
             ->setWidth(30);
      }
      
         $styleArrayInfo = array(
         'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
         ),
         'font'  => array(
            'bold'  => true,
            'color' => array('rgb' => 'FFFFFF'),
            'size'  => 12,
            'name'  => 'Levenim MT'
         ));
         $alert = array(
            'alignment' => array(
               'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            ),
            'font'  => array(
               'bold'  => false,
               'color' => array('rgb' => '856404'),
               'size'  => 11,
               'name'  => 'Levenim MT'
            ));
         $style = array(
            'alignment' => array(
               'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
               )
            );
      $objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(-1);
      $objPHPExcel->getActiveSheet()->getStyle('A:M')->getAlignment()->setWrapText(true);
      $objPHPExcel->getActiveSheet()->setCellValue("M1", "\n");
      $objPHPExcel->getDefaultStyle()->applyFromArray($style);
      $objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(-1);
      $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
      $objPHPExcel->getActiveSheet()->getStyle('E2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
      $objPHPExcel->getActiveSheet()->getStyle('E3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
      $objPHPExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray($styleArrayInfo);
      $objPHPExcel->getActiveSheet()->getStyle('E10')->applyFromArray($alert);
      
      $objPHPExcel->setActiveSheetIndex(0)->mergeCells('E2:M9');
      $objPHPExcel->setActiveSheetIndex(0)->mergeCells('E10:M10');
      $objPHPExcel->setActiveSheetIndex(0)->mergeCells('E1:M1');
      $objPHPExcel->getActiveSheet()->getStyle('E2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
      $objPHPExcel->getActiveSheet()->getStyle('E2')->getFill()->getStartColor()->setARGB('323232');
      $objPHPExcel->getActiveSheet()->getStyle('E1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
      $objPHPExcel->getActiveSheet()->getStyle('E1')->getFill()->getStartColor()->setARGB('323232');
      $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
      $objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFill()->getStartColor()->setARGB('323232');
      $objPHPExcel->getActiveSheet()->getStyle('E10')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
      $objPHPExcel->getActiveSheet()->getStyle('E10')->getFill()->getStartColor()->setARGB('fff3cd');
      
      $objDrawing = new PHPExcel_Worksheet_Drawing();    //create object for Worksheet drawing
      $objDrawing->setName('Customer Signature');
      $objDrawing->setDescription('Customer Signature'); //set description to image
      $path = __DIR__. '/../assets/img/educarInnovacion.png';
      $objDrawing->setPath($path);
      $objDrawing->setOffsetX(70);                       //setOffsetX works properly
      $objDrawing->setOffsetY(120);                       //setOffsetY works properly
      $objDrawing->setCoordinates('E2');        //set image to cell
      $objDrawing->setWidth(80);
      $objDrawing->setHeight(90);
      $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());  //save
    
      // indicar que se envia un archivo de Excel.
      // header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      // header('Content-Disposition: attachment;filename="Formato de importación de usuarios SIE.xlsx"');
      // header('Cache-Control: max-age=0');
      $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
      header('Content-Type: application/vnd.ms-excel'); header('Content-Disposition: attachment;filename="Formato para importar usuarios SIE.xlsx"'); 
      header('Cache-Control: max-age=0'); 
      $objWriter->save('php://output'); 
    
    }
   





    