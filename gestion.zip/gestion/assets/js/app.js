const app = new Vue({
    el: '#nav',
    data: {
        varTituloConfiguracion: true,
        varTituloConfiguracionAvanzada : false,
        coursesLetters: [{
            1: 'Primero',
            2: 'Segundo',
            3: 'Tercero',
            4: 'Cuarto',
            5: 'Quinto',
            6: 'Sexto',
            7: 'Septimo',
            8: 'Octavo',
            9: 'Noveno',
            10: 'Decimo',
            11: 'Once',
            P: 'Párvulos',
            PJ: 'PreJardín',
            J: 'Jardín',
            T: 'Transición'
        }],
        coursesLettersObject: [
            { 1: 'Primero' },
            { 2: 'Segundo' },
            { 3: 'Tercero' },
            { 4: 'Cuarto' },
            { 5: 'Quinto' },
            { 6: 'Sexto' },
            { 7: 'Septimo' },
            { 8: 'Octavo' },
            { 9: 'Noveno' },
            { 10: 'Decimo' },
            { 11: 'Once' },
            { P: 'Párvulos' },
            { PJ: 'PreJardín' },
            { J: 'Jardín' },
            { T: 'Transición' }
        ],
        letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
        imageEscudo: {},
        progresoUsuario: 0
    },
    created() {
       // this.getImage(),
        this.getProgress()

    },
    computed: {},
    methods: {
        getImage() {
            let self = this
            let data = new FormData()
            data.append('getImageShield', 'get')
            axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                .then(res => {
                    if (res.data && res.data != 'error_limit') {
                        res.data.forEach(dataRes => {
                            if (dataRes.clase == 'shield') {
                                self.imageEscudo = dataRes
                                $("#idShieldSchool, .idShieldSchool, .idShieldSchool2").attr('src', './' + self.imageEscudo.url)
                                var preview = new Image
                                preview.src = self.imageEscudo.url
                                preview.id = "idEscudoPreview"
                                preview.onload = () => {
                                    const elem = document.createElement('canvas');
                                    elem.width = 100;
                                    elem.height = 100;
                                    const ctx = elem.getContext('2d');
                                    // img.width and img.height will contain the original dimensions
                                    ctx.drawImage(preview, 0, 0, 100, 100);
                                    ctx.canvas.toBlob((blob) => {
                                        const file = new File([blob], dataRes.name, {
                                            type: dataRes.type,
                                            lastModified: Date.now()
                                        });
                                    }, dataRes.type, 1);
                                    let newImage = new Image
                                    newImage.src = elem.toDataURL(dataRes.type)
                                    newImage.id = "idEscudoPreview"
                                    $(".clPreviewImageSquad").after(newImage)
                                }
                            }
                        })
                    }
                })
                .catch(err => {
                    console.error(err);
                })
        },
        getProgress() {
            var self = this
            const data = new FormData()
            data.append('getProgressPestana', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    self.progresoUsuario = res.data
                })
                .catch(err => {
                    console.error(err)
                })
        }
    }
})