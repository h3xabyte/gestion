const progreso = new Vue({
    el: "#module-progreso",
    data: {
        progresoUsuario: 0
    },
    created: function() {
        this.getProgress()
    },
    methods: {
        getProgress() {
            var self = this
            const data = new FormData()
            data.append('getProgress', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    if (Math.round(res.data) <= 100) {
                        self.progresoUsuario = Math.round(res.data)
                        if (Math.round(res.data) == 100) {
                            swal({
                                title: "Felicitaciones",
                                text: "Has completado el tutorial",
                                button: "Finalizar",
                                icon: "success"
                            }).then(() => {
                                let data = new FormData()
                                data.append('setFind', 'true')
                                axios.post('./controllers/grados-cursos.ctrl.php', data)
                            })
                        }
                    } else {
                        self.progresoUsuario = 100
                    }
                })
                .catch(err => {
                    console.error(err)
                })
        }
    }
})
