const home = new Vue({
    el: "#module-home",
    data: {
        progresoUsuario: 0
    },
    created() {},
    mounted() {
        this.getProgress()
    },
    methods: {
        tour() {
            if (!this.progresoUsuario.pestana_uno) {
                introJs().start()
            }
        },
        getProgress() {
            var self = this
            const data = new FormData()
            data.append('getProgressPestana', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    self.progresoUsuario = res.data
                    this.tour()
                })
                .catch(err => {
                    console.error(err)
                })
        }
    }
})