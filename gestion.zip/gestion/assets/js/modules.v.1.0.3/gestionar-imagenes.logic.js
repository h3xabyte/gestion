// Animate carousel
$('#idCarruselPrevista').carousel({ interval: 500 })
    // Vue proccess
const agregarImagenes = new Vue({
    el: "#module-agregar-imagenes",
    created() {

    },
    mounted() {
        this.fileDrop()
        this.getImage()
        this.getProgress()
    },
    data: {
        nameImage: '',
        imageEscudo: {},
        nameCover: '',
        imagesCover: [],
        arrayDelete: [],
        progresoUsuario: 0,
    },
    methods: {
        autoTour() {
            var intro = introJs();
            intro.start("tab" + this.tabSelected);
        },
        tour() {
            if (this.progresoUsuario == 0 || !this.progresoUsuario) {
                introJs().start("tab1")
            }
        },
        getProgress() {
            var self = this;
            const data = new FormData();
            data.append("getProgressPestana", "get")
            axios.post("./controllers/grados-cursos.ctrl.php", data)
                .then(res => {
                    self.progresoUsuario = res.data.pestana_seis
                    self.tour()
                })
                .catch(err => {
                    console.error(err)
                });
        },
        upImage() {

            if (this.imageEscudo.type == 'image/jpg' || this.imageEscudo.type == 'image/png' || this.imageEscudo.type == "image/jpeg") {
                let data = new FormData()
                if (
                    this.imageEscudo.type != undefined &&
                    this.imageEscudo.size != undefined &&
                    this.imageEscudo.name != undefined
                ) {
                    data.append('setTypeImage', this.imageEscudo.type)
                    data.append('setSizeImage', this.imageEscudo.size)
                    data.append('setNameImage', this.imageEscudo.name)
                    data.append('setImage', this.imageEscudo.src)
                    data.append('setClassImage', 'shield')
                    axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                        .then(res => {
                            console.log(res.data);
                            
                            if (res.data != "updateOk") {
                                swal({
                                    allowOutsideClick: "true",

                                    title: "Correcto",
                                    text: "La imagen se ha subido satisfactoriamente",
                                    icon: "success",
                                    button: "Continuar",
                                });
                            } else {
                                swal({
                                    allowOutsideClick: "true",

                                    title: "Correcto",
                                    text: "Actualizó correctamente la imagen",
                                    icon: "success",
                                });

                            }
                        })
                        .catch(err => {
                            console.error(err);
                        })
                    progreso.getProgress()
                } else {
                    swal({
                        allowOutsideClick: "true",

                        text: "Por favor ingrese una imagen",
                        icon: 'warning'
                    });
                }
            } else {
                swal({
                    title: "Atención",
                    text: "Por favor sube una imagen con un formato valido.",
                    icon: "warning"
                })
            }

        },
        upCover() {
            let self = this
            limit = self.imagesCover.length
            count = 0
            validateFile = []
            self.imagesCover.forEach(dataImages => {
                count++;
                let data = new FormData()
                data.append('setTypeImage', dataImages.type)
                data.append('setSizeImage', dataImages.size)
                data.append('setNameImage', dataImages.name)
                data.append('setImage', dataImages.img.src)
                data.append('setClassImage', 'banner')

                if (dataImages.type == 'image/jpg' || dataImages.type == 'image/png' || dataImages.type == "image/jpeg") {
                    axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                        .then(res => {
                            if (res) {
                                document.querySelector('#idSelectImageCover').value = ''
                            }
                            if (limit == count) {

                                if (validateFile.length > 0) {
                                    let textSwal = ''
                                    validateFile.forEach((dataValidate) => {
                                        if (dataValidate) {
                                            textSwal += "\n" + dataValidate
                                        }
                                    })
                                    swal({
                                        title: "Atención",
                                        text: "Por favor sube imágenes con un formato valido. Los siguientes archivos no se subieron:" + textSwal,
                                        icon: "warning"
                                    }).then(() => {
                                        window.location.reload()
                                    })
                                } else {
                                    if (res.data == 'error_limit') {
                                        swal({
                                            allowOutsideClick: "true",

                                            title: "Se ha revasado el limite de imagenes",
                                            text: "Solo puede ingresar 4 imagenes",
                                            icon: "warning",
                                        });
                                    } else {
                                        swal({
                                            allowOutsideClick: "true",

                                            title: "Correcto",
                                            text: "Las imagenes se han subido satisfactoriamente",
                                            icon: "success",
                                            button: "Continuar",
                                        }).then(() => {
                                            window.location.reload()
                                        })
                                    }
                                }


                            }
                        })
                        .catch(err => {
                            console.error(err);
                        })
                    progreso.getProgress()
                } else {
                    validateFile.push(dataImages.name)
                    if (limit == count && validateFile.length > 0) {
                        let textSwal = ''
                        validateFile.forEach((dataValidate) => {
                            if (dataValidate) {
                                textSwal += "\n" + dataValidate
                            }
                        })
                        swal({
                            title: "Atención",
                            text: "Por favor sube imágenes con un formato valido. Los siguientes archivos no se subieron:" + textSwal,
                            icon: "warning"
                        }).then(() => {
                            window.location.reload()
                        })
                    }
                }
            })
        },
        getImage() {
            let self = this
            let data = new FormData()
            data.append('getImageShield', 'get')
            axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                .then(res => {
                    if (res.data) {
                        if (res.data != 'error_limit') {
                            res.data.forEach(dataRes => {
                                if (dataRes.clase != 'shield') {

                                    self.imagesCover.push(dataRes)
                                }
                            })
                        }
                    }
                })
                .catch(err => {
                    console.error(err);
                })

        },
        selectImageEscudo(event) {
            let self = this
            let res = String.fromCharCode(92)
            this.nameImage = event.srcElement.value.split(res)[2]
            let input = event.target

            if (input.files && input.files[0]) {
                var reader = new FileReader()
                reader.onload = function(e) {
                    $(".contImageEscudo #idImgEscudoSelect").hide()
                    $(".contImageEscudo #idImgEscudo").remove()
                    $(".contImageEscudo #idEscudoPreview").remove()
                    $(".contImageCover #idEscudoPreview").remove()
                    var img = new Image
                    img.src = e.target.result
                    img.id = 'idImgEscudoSelect'
                    $(".contImageEscudoLegend").after(img)
                    var preview = new Image
                    preview.src = e.target.result
                    preview.id = "idEscudoPreview"
                    $(".clPreviewImageSquad").after(preview)
                    $(".contImageEscudoLegend").hide()

                    let objectImage = new Object()
                    objectImage.size = input.files[0].size
                    objectImage.type = input.files[0].type
                    objectImage.name = input.files[0].name

                    preview.onload = () => {
                        const elem = document.createElement('canvas');
                        elem.width = 200;
                        elem.height = 200;
                        const ctx = elem.getContext('2d');
                        // img.width and img.height will contain the original dimensions
                        ctx.drawImage(preview, 0, 0, 200, 200);
                        ctx.canvas.toBlob((blob) => {
                            const file = new File([blob], objectImage.name, {
                                type: objectImage.type,
                                lastModified: Date.now()
                            });
                        }, objectImage.type, 1);

                        objectImage.src = elem.toDataURL(objectImage.type)
                    }
                    self.imageEscudo = objectImage

                }
                reader.readAsDataURL(input.files[0]);
            }
        },
        btnUpImageCover() {
            let self = this
            input = $('#idSelectImageCover')[0].files

            if (input && input[0]) {
                var reader = new FileReader()
                reader.onload = function(e) {
                    $(".contImageCover #idImgEscudoSelect").hide()
                    $(".contImageCover #idImgEscudo").remove()
                    let img = new Image
                    img.src = e.target.result
                    img.id = 'idImgEscudo'
                    $(".contImageCoverLegend").after(img)
                    $(".contImageCoverLegend").hide()
                    let validate = false

                    self.imagesCover.forEach(dataImages => {
                        if (dataImages.img.src[0] == img.src) {
                            validate = true
                        }
                    })

                    if (validate == false && input[0]) {
                        let objectTemp = new Object()
                        objectTemp.img = img
                        objectTemp.name = self.nameCover
                        objectTemp.size = input[0].size
                        objectTemp.type = input[0].type
                        objectTemp.src = e.target.result
                        if (self.imagesCover.length <= 3) {
                            objectTemp.id = (self.imagesCover.length + 1)
                            self.imagesCover.push(objectTemp)
                            $("#idSelectImageCover").val('')
                            self.nameCover = ''
                            $(".contImageCover #idImgEscudo").remove()
                        } else {
                            swal({
                                allowOutsideClick: "true",

                                title: "Atención",
                                text: "Solo están permitidas 4 imagenes",
                                icon: "warning",
                            });
                        }
                    }

                }
                reader.readAsDataURL(input[0])
            }
        },
        selectImageCover(param) {
            let res = String.fromCharCode(92)
            let self = this
            this.nameCover = param.srcElement.value.split(res)[2]
            let input = param.target
            if (input.files && input.files[0]) {
                var reader = new FileReader()
                reader.onload = function(e) {
                    $(".contImageCover #idImgEscudoSelect").hide()
                    $(".contImageCover #idImgEscudo").remove()
                    let img = new Image
                    img.src = e.target.result
                    img.id = 'idImgEscudo'
                    $(".contImageCoverLegend").after(img)
                    $(".contImageCoverLegend").hide()
                }
                reader.readAsDataURL(input.files[0])
            }

        },
        fileDrop() {
            let self = this
            let zone = new FileDrop('zthumbs', { input: false })

            zone.event('upload', function(e) {
                zone.eventFiles(e).images().each(function(fil) {
                    fil.readDataURI(function(uri) {
                        $(".contImageEscudo #idImgEscudoSelect").hide()
                        $(".contImageEscudo #idImgEscudo").remove()
                        $(".contImageEscudo #idEscudoPreview").remove()
                        $(".contImageCover #idEscudoPreview").remove()

                        var img = new Image
                        img.src = uri
                        img.id = 'idImgEscudoSelect'
                        $(".contImageEscudoLegend").after(img)
                        var preview = new Image
                        preview.src = uri
                        preview.id = "idEscudoPreview"
                        $(".clPreviewImageSquad").after(preview)

                        let objectImage = new Object()
                        objectImage.size = fil.size
                        objectImage.type = fil.type
                        objectImage.name = fil.name
                        objectImage.src = uri

                        self.imageEscudo = objectImage

                        self.nameImage = fil.name
                        $(".contImageEscudoLegend").hide()
                    })
                })
            })

            let zoneTwo = new FileDrop('zthumbsTwo', { input: false })
            let messageLimit = false;

            zoneTwo.event('upload', function(e) {
                zoneTwo.eventFiles(e).images().each(function(file) {
                    file.readDataURI(function(uri) {
                        $(".contImageCover #idImgEscudoSelect").hide()
                        $(".contImageCover #idImgEscudo").remove()
                        let img = new Image
                        img.src = uri
                        img.id = 'idImgEscudo'
                        $(".contImageCoverLegend").after(img)
                        self.nameCover = file.name
                        $(".contImageCoverLegend").hide()

                        $("#idAddTempImg").click(function() {
                            let validate = false
                            self.imagesCover.forEach(dataImages => {
                                if (dataImages.img.src == img.src) {
                                    validate = true
                                }
                            })
                            if (self.imagesCover.length >= 4) {
                                validate = true
                            }
                            if (validate == false) {
                                let objectTemp = new Object()
                                objectTemp.img = img
                                objectTemp.name = file.name
                                self.imagesCover.push(objectTemp)

                            }
                            if (messageLimit == false && self.imagesCover.length >= 4) {
                                swal({
                                    allowOutsideClick: "true",

                                    title: "Atención",
                                    text: "Solo están permitidas 4 imagenes",
                                    icon: "warning",
                                });
                                messageLimit = true
                            }
                        })
                    })

                })
            })

        },
        deleteImageTemp(name, id) {
            let self = this

            self.imagesCover.forEach(function(dataImages, index) {
                if (dataImages.id && dataImages.id == id) {
                    self.imagesCover.splice(index, 1)
                    let data = new FormData()
                    data.append('deleteImageBanner', id)
                    axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                        .then(res => {
                            console.log(res.data);
                            
                            swal({
                                allowOutsideClick: "true",
                                title: "Atención",
                                text: "Eliminó satisfactoriamente la imagen",
                                icon: "warning",
                            })
                            $("#carouselBanner").carousel('cycle')

                        })
                } else if (!dataImages.id && dataImages.name == name) {
                    self.imagesCover.splice(index, 1)
                    swal({
                        allowOutsideClick: "true",
                        title: "Atención",
                        text: "Eliminó satisfactoriamente la imagen",
                        icon: "warning",
                    })
                    $("#carouselBanner").carousel('cycle')

                }

            })
        }

    }
})