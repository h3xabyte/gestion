let infoGeneral = new Vue({
    el: "#module-home",
    data: {
        mision: '',
        vision: '',
        misionLength: 0,
        visionLength: 0,
        progresoUsuario: 0
    },
    created() {
        this.getLength()
    },
    mounted: function() {
        this.getProgress()

    },
    methods: {
        autoTour() {
            var intro = introJs();
            intro.start("tab" + this.tabSelected);
        },
        tour() {
            if (this.progresoUsuario == 0 || !this.progresoUsuario) {
                introJs().start("tab1")
            }
        },
        getProgress() {
            var self = this;
            const data = new FormData();
            data.append("getProgressPestana", "get")
            axios.post("./controllers/grados-cursos.ctrl.php", data)
                .then(res => {
                    self.progresoUsuario = res.data.pestana_cuatro
                    self.tour()
                })
                .catch(err => {
                    console.error(err)
                });
        },
        getLength() {
            this.mision = document.getElementById("idMision").value.replace(/\s\s/g, '')
            this.misionLength = document.getElementById("idMision").value.replace(/(<([^>]+)>)/ig, '').replace(/\&nbsp\;/ig, '').replace(/\s\s/g, '').length
            this.vision = document.getElementById("idVision").value.replace(/\s\s/g, '')
            this.visionLength = document.getElementById("idVision").value.replace(/(<([^>]+)>)/ig, '').replace(/\&nbsp\;/ig, '').replace(/\s\s/g, '').length
        },
        countLength(param) {
            let self = this
            if (param === 'mision') {
                this.misionLength = document.getElementById("idMision").value.replace(/(<([^>]+)>)/ig, '').replace(/\&nbsp\;/ig, '').replace(/\s\s/g, '').length
                if (this.misionLength > 600) {
                    document.querySelector("#alertMaxM").style.color = "salmon"
                } else {
                    document.querySelector("#alertMaxM").style.color = "black"

                }
                this.mision = document.getElementById("idMision").value.replace(/\s\s/g, '')
                var elementEditorM = document.querySelector("#trixMision");
                var processedDocumentTextM;

            } else if (param === 'vision') {
                this.visionLength = document.getElementById("idVision").value.replace(/(<([^>]+)>)/ig, '').replace(/\&nbsp\;/ig, '').replace(/\s\s/g, '').length
                if (this.visionLength > 600) {
                    document.querySelector("#alertMaxV").style.color = "salmon"
                } else {
                    document.querySelector("#alertMaxV").style.color = "black"

                }
                this.vision = document.getElementById("idVision").value.replace(/\s\s/g, '')
                let self = this
                var elementEditorV = document.querySelector("#trixVision");

                var processedDocumentTextV;
            }
            document.addEventListener("trix-change", function(event) {
                //debugger
                if (elementEditorM) {
                    var newDocumentTextM = elementEditorM.editor.getDocument().toString();
                    if (!processedDocumentTextM) {
                        processedDocumentTextM = newDocumentTextM;
                    }
                    var length = self.misionLength
                    if (processedDocumentTextM && processedDocumentTextM !== newDocumentTextM) {
                        processedDocumentTextM = newDocumentTextM;
                        if (length >= 600) {
                            elementEditorM.editor.setSelectedRange([600, length])
                        }
                    }
                } else {
                    var newDocumentTextV = elementEditorV.editor.getDocument().toString();
                    if (!processedDocumentTextV) {
                        processedDocumentTextV = newDocumentTextV;
                    }
                    var length = self.visionLength
                    if (processedDocumentTextV && processedDocumentTextV !== newDocumentTextV) {
                        processedDocumentTextV = newDocumentTextV;
                        if (length >= 600) {
                            elementEditorV.editor.setSelectedRange([600, length])
                        }
                    }
                }

            })

            //typography, use replaceHtml.
            // how to get current html? innerHTML?
        },
        setInfo() {
            let self = this
            if (this.misionLength > 600 || this.visionLength > 600) {
                swal({
                    title: 'Atención',
                    text: 'Ha ingresado más caracteres de los permitidos',
                    icon: 'warning'
                })
            } else {
                let data = new FormData()
                let self = this
                data.append('setMision', self.mision)
                data.append('setVision', self.vision)
                axios.post('./controllers/informacion-general.ctrl.php', data)
                    .then(res => {
                        swal({
                            allowOutsideClick: "true",
                            title: "Correcto",
                            text: "¡Cambios realizados satisfactoriamente!",
                            icon: "success"
                        }).then(() => {
                            if (self.progresoUsuario == 0) {
                                window.location = './index.php?module=informacion-contacto'
                            } else {
                                let intro = introJs();
                                intro.exit("tab1")
                            }
                        })

                    })
            }


        }
    },
})