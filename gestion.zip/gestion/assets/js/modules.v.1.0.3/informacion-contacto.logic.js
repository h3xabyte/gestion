let informacionContacto = new Vue({
    el: "#module-informacion-contacto",
    data: {
        setName: '',
        setNit: '',
        setDane: '',
        setCountry: 'CO',
        setDepartment: '',
        setCity: '',
        setPage: '',
        setEmail: '',
        setIcfes: '',
        dataCountries: [],
        dataDepartment: [],
        dataCity: [],
        getCoord: {},
        progresoUsuario: 0


    },
    created() {

    },
    mounted() {
        this.getLocate(),
            this.getInfo(),
            this.getProgress()
    },
    methods: {
        autoTour() {
            var intro = introJs();
            intro.start("tab" + this.tabSelected);
        },
        tour() {
            if (this.progresoUsuario == 0 || !this.progresoUsuario) {
                introJs().start("tab1")
            }
        },
        getProgress() {
            var self = this;
            const data = new FormData();
            data.append("getProgressPestana", "get")
            axios.post("./controllers/grados-cursos.ctrl.php", data)
                .then(res => {
                    self.progresoUsuario = res.data.pestana_cinco
                    self.tour()
                })
                .catch(err => {
                    console.error(err)
                });
        },
        getProgressNoTour() {
            var self = this;
            const data = new FormData();
            data.append("getProgressPestana", "get")
            axios.post("./controllers/grados-cursos.ctrl.php", data)
                .then(res => {
                    self.progresoUsuario = res.data.pestana_cinco
                })
                .catch(err => {
                    console.error(err)
                });
        },
        getLocate() {
            let self = this
            let data = new FormData()
            data.append('getCountries', 'get')
            axios.post('./controllers/informacion-contacto.ctrl.php', data)
                .then(res => {
                    self.dataCountries = res.data
                })
                .catch(err => {
                    console.error(err)
                })

            let dataDepartment = new FormData()
            dataDepartment.append('getDepartment', 'get')
            axios.post('./controllers/informacion-contacto.ctrl.php', dataDepartment)
                .then(res => {
                    self.dataDepartment = res.data
                })

            let dataCity = new FormData()
            dataCity.append('getCities', 'get')
            axios.post('./controllers/informacion-contacto.ctrl.php', dataCity)
                .then(res => {
                    self.dataCity = res.data
                })

        },
        setInfo() {
            let self = this
            if (this.setNit && this.setNit.length > 12) {
                swal({ title: "Atención", text: "Por favor ingrese un NIT valido.", icon: "warning" })
            } else {
                if (this.setDane && this.setDane.length > 12) {
                    swal({ title: "Atención", text: "Por favor ingrese un código DANE valido.", icon: "warning" })
                } else {
                    if (this.setIcfes && this.setIcfes.length > 12) {
                        swal({ title: "Atención", text: "Por favor ingrese un código valido.", icon: "warning" })
                    } else {
                        if (this.setEmail && (!this.setEmail.split("@")[1] || !this.setEmail.split(".")[1])) {
                            swal({ title: "Atención", text: "Por favor ingrese un correo valido.", icon: "warning" })
                        } else {
                            if (this.setName > 500) {
                                swal({ title: "Atención", text: "Por favor ingrese un nombre valido para el colegio.", icon: "warning" })
                            } else {
                                let self = this
                                swal({
                                        allowOutsideClick: "true",
                                        title: "¿Esta seguro de los cambios realizados?",
                                        text: "Cambiaras la información de la institucion ¿Esta seguro de los cambios?",
                                        icon: "warning",
                                        buttons: ['Cancelar', 'Sí, quiero continuar'],
                                        dangerMode: true
                                    })
                                    .then((willDelete) => {
                                        if (willDelete) {
                                            swal({
                                                allowOutsideClick: "true",

                                                title: 'Configurando...',
                                                text: "Se está enviando la información de contacto de su institución. \n Por favor espere.",
                                                icon: "info",
                                                button: false,
                                                closeOnClickOutside: false
                                            });
                                            let data = new FormData()
                                            data.append('setInfoInst', 'set')
                                            data.append('setName', self.setName)
                                            data.append('setNit', self.setNit)
                                            data.append('setDane', self.setDane)
                                            data.append('setIcfes', self.setIcfes)
                                            data.append('setCountry', self.setCountry)
                                            data.append('setDepartment', self.setDepartment)
                                            data.append('setCity', self.setCity)
                                            data.append('setPage', self.setPage)
                                            data.append('setEmail', self.setEmail)
                                            axios.post('./controllers/informacion-contacto.ctrl.php', data)
                                                .then(res => {
                                                    swal("Correcto", "Has realizado los cambios satisfactoriamente.", {
                                                        icon: "success",
                                                    }).then(() => {
                                                        if (self.progresoUsuario == 0) {
                                                            window.location = './index.php?module=gestionar-imagenes'
                                                        } else {
                                                            let intro = introJs();
                                                            intro.exit("tab1")
                                                        }
                                                    })
                                                })


                                        } else {
                                            swal("No has realizado los cambios.", {
                                                icon: "success",
                                                button: 'De acuerdo'
                                            });
                                        }
                                    });
                            }
                        }
                    }
                }
            }

        },
        getInfo() {
            let data = new FormData()
            let self = this
            data.append('getInfoInst', 'get')
            axios.post('./controllers/informacion-contacto.ctrl.php', data)
                .then(res => {
                    if (res.data.nombre != 'null')
                        self.setName = res.data.nombre
                    if (res.data.nit != 'null')
                        self.setNit = res.data.nit
                    if (res.data.dane != 'null')
                        self.setDane = res.data.dane
                    if (res.data.icfes != 'null')
                        self.setIcfes = res.data.icfes
                    if (res.data.correo != 'null')
                        self.setEmail = res.data.correo
                    if (res.data.web != 'null')
                        self.setPage = res.data.web
                    if (res.data.pais && res.data.pais != 'null')
                        self.setCountry = res.data.pais
                    if (res.data.departamento != 'null')
                        self.setDepartment = res.data.departamento
                    if (res.data.municipio != 'null')
                        self.setCity = res.data.municipio
                    if (res.data.coordinador != 'null')
                        self.getCoord = res.data.coordinador
                })
        }
    }
})