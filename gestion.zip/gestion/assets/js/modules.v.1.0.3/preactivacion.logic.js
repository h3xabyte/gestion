let preactivacion = new Vue({
    el: "#module-preactivacion",
    data: {
        infoCourse: [],
        preactive: false,
        seleccionGrados: [{
            Preescolar: [{
                id: 'P',
                name: 'Parvulos',
                check: false,
                preCheck: false
            }, {
                id: 'PJ',
                name: 'Pre Jardín',
                check: false,
                preCheck: false
            }, {
                id: 'J',
                name: 'Jardín',
                check: false,
                preCheck: false
            }, {
                id: 'T',
                name: 'Transición',
                check: false,
                preCheck: false
            }]
        }, {
            Primaria: [{
                    id: 1,
                    name: "Primero",
                    check: false,
                    preCheck: false
                },
                {
                    id: 2,
                    name: "Segundo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 3,
                    name: "Tercero",
                    check: false,
                    preCheck: false
                },
                {
                    id: 4,
                    name: "Cuarto",
                    check: false,
                    preCheck: false
                },
                {
                    id: 5,
                    name: "Quinto",
                    check: false,
                    preCheck: false
                }
            ],
        }, {
            Secundaria: [{
                    id: 6,
                    name: "Sexto",
                    check: false,
                    preCheck: false
                },
                {
                    id: 7,
                    name: "Séptimo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 8,
                    name: "Octavo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 9,
                    name: "Noveno",
                    check: false,
                    preCheck: false
                }
            ],
        }, {
            Media: [{
                    id: 10,
                    name: "Décimo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 11,
                    name: "Once",
                    check: false,
                    preCheck: false
                }
            ]
        }],
        selectTypeCourses: 0,
        tabSelected: 1,
        arrayError: [],
        letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
        temp: [],
        courses: [],
        preSelectType: false,
        progresoUsuario: 0,
        formGrado: '',
        formCurso: '',
        downUsers: false,
        searchStudents: [],
        searchWait: false,
        userChangePass: '',
        pass: '',
        passRep: ''
    },
    created() {
        this.getGradesChecked(),
            localStorage.clear();
    },
    mounted() {},
    methods: {
        getGradesChecked() {
            const self = this;
            var data = new FormData()
            data.append('function', 'get_info')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(function(response) {
                    for (var i in response.data) {
                        self.seleccionGrados.forEach(element => {
                            for (key in element) {
                                element[key].forEach(value => {
                                    if (value.id == response.data[i]) {
                                        value.check = true
                                        value.preCheck = true
                                    }
                                })
                            }
                        })
                    }
                }).then(res => {
                    self.createTab()
                })
        },
        createTab() {
            let self = this;
            data = new FormData()
            data.append('function', 'get_type')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(function(response) {
                    self.selectTypeCourses = response.data
                    self.seleccionGrados.forEach(element => {
                        for (key in element) {
                            element[key].forEach(value => {
                                if (value.check == true) {
                                    self.temp.push(value)
                                }
                            })
                        }
                    })
                }).then(res => {
                    this.getCourses()
                })
        },
        isset(grupo, curso) {
            const tempCourse = this.courses.filter(coursesData => {
                var identifyCourse = curso + '' + grupo
                return identifyCourse == coursesData.id && coursesData.state == 2
            })
            if (tempCourse.length > 0) {
                return true
            } else {
                return false
            }
        },
        getCourses() {
            const self = this
            const data = new FormData()
            data.append('getGroups', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    self.infoCourse = res.data
                    if (res.data.length > 0) {
                        self.preactive = true
                    }
                    res.data.forEach(dataRes => {
                        const newCourse = new Object()
                        newCourse.grupo = dataRes.grupo
                        newCourse.id = dataRes.grado

                        const tempObject = self.temp.find(dataTemp => {
                            return dataTemp.id == dataRes.grado
                        })
                        if (tempObject) {
                            newCourse.curso = tempObject.name
                        }
                        let dataAppend = new FormData
                        dataAppend.append('getCountPreactive', 'get')
                        dataAppend.append('setCourse', dataRes.grado)
                        dataAppend.append('setGroup', dataRes.grupo)
                        axios.post('./controllers/preactivacion.ctrl.php', dataAppend)
                            .then(res => {
                                if (res) {
                                    newCourse.count = res.data
                                    self.courses.push(newCourse)
                                    self.courses.sort(function(a, b) {
                                        if (a.id < b.id) {
                                            return -1
                                        } else {
                                            return 1
                                        }
                                    })
                                }
                            })
                    })
                })
                .catch(err => {
                    console.error(err);
                })

        },
        setStudents() {
            swal({
                title: 'Configurando...',
                text: "La creación de los usuarios puede demorar unos minutos. \n Por favor espere.",
                icon: "info",
                button: false,
                closeOnClickOutside: false
            });
            let self = this
            let contador = 1
            let spinner = document.querySelector('#spinner')
            let spinnerText = document.querySelector('#spinnerText')
            let button = document.querySelector('#btnCreate')
            let maxError = []
            spinner.removeAttribute('hidden')
            spinnerText.removeAttribute('hidden')
            button.setAttribute('hidden', '')
            let comparar = self.courses.length

            self.courses.forEach(dataCourse => {
                let dgrade = dataCourse
                let dgroup = dataCourse.grupo
                let dataGrade = dgrade.id + "-" + dgroup
                let valueData = document.querySelector("#id" + dataGrade)

                if (valueData) {
                    if (valueData.value > 0) {
                        let data = new FormData()
                        data.append('setStudents', 'set')
                        data.append('setGrade', dgrade.id)
                        data.append('setGroup', dgroup)
                        data.append('setValue', valueData.value)
                        data.append('setType', self.selectTypeCourses)
                        axios.post('./controllers/preactivacion.ctrl.php', data)
                            .then(res => {
                                if (res) {
                                    if (res.data) {
                                        if (res.data != 'OK') {
                                            maxError.push(res.data)
                                        }
                                        if (contador == comparar && maxError.length == 0) {
                                            swal("Correcto", "Pre-activación exitosa", "success");
                                            button.removeAttribute('hidden')
                                            spinner.setAttribute('hidden', '')
                                            spinnerText.setAttribute('hidden', '')

                                        } else if (contador == comparar && maxError.length > 0) {
                                            maxError.forEach(dataMax => {
                                                let inputDataMax = document.querySelector("#show-" + dataMax)
                                                inputDataMax.removeAttribute('hidden')
                                            })
                                            swal("¡Atención!", "Se ha completado el proceso, pero se detectó que ya se ha superado el número de pines en uno de los cursos.", "warning");
                                            button.removeAttribute('hidden')
                                            spinner.setAttribute('hidden', '')
                                            spinnerText.setAttribute('hidden', '')
                                        }
                                        contador++;
                                    }

                                }
                            })
                    } else {
                        if (contador == comparar) {
                            swal("Correcto", "Pre-activación exitosa.", "success");
                            button.removeAttribute('hidden')
                            spinner.setAttribute('hidden', '')
                            spinnerText.setAttribute('hidden', '')

                        }
                        contador++
                    }
                }
            })
        },
        sumaVar(local, num1, num2, idError) {
            if (!localStorage.getItem('lc' + local)) {
                localStorage.setItem('lc' + local, num1);
            }
            if (parseInt(localStorage.getItem('lc' + local)) + parseInt(num2) > 60) {
                document.querySelector("#" + idError).removeAttribute('hidden')
            } else {
                document.querySelector("#" + idError).setAttribute('hidden', '')
            }
            return parseInt(localStorage.getItem('lc' + local)) + parseInt(num2)
        },
        searchUsers(param) {
            if (param.length > 3) {
                let self = this
                self.searchStudents = []
                self.searchWait = true
                let data = new FormData
                data.append('getStudentsEdit', param)
                axios.post('controllers/preactivacion.ctrl.php', data)
                    .then(res => {
                        self.searchStudents = res.data
                    }).then(res => {
                        self.searchWait = false
                    })
                    .catch(err => {
                        console.error(err);
                    })
            }

        },
        updatePass(random = false) {
            let data = new FormData
            let self = this
            if (self.pass == self.passRep) {
                if (self.pass.length >= 8 || random) {
                    data.append('updatePassword', 'update')
                    data.append('setPass', self.pass)
                    data.append('setRep', self.passRep)
                    data.append('setRandom', random)
                    data.append('setUser', self.userChangePass)
                    axios.post('controllers/preactivacion.ctrl.php', data)
                        .then(res => {
                            span = document.createElement('span')
                            span.innerHTML = 'La contraseña ha sido generada correctamente.<br> La contraseña es: <b>' + res.data.split('passrand ')[1] + '</b>'
                            if (!res.data.split('passrand ')[1]) {
                                swal({
                                    title: "Correcto",
                                    text: "La contraseña ha sido cambiada satisfactoriamente",
                                    icon: "success"
                                })
                            } else {
                                swal({
                                    title: "Correcto",
                                    content: span,
                                    icon: "success"
                                })
                            }
                        })
                        .catch(err => {
                            console.error(err);
                        })
                } else {
                    swal({
                        title: "Atención",
                        text: "La contraseña debe ser mayor a ocho dígitos",
                        icon: "error"
                    })
                }
            } else {
                swal({
                    title: "Atención",
                    text: "Las contraseñas no coinciden",
                    icon: "error"
                })
            }
        }
    }

})