const gradosCursos = new Vue({
    el: '#module-cursos-grados',
    created: function() {
        this.getProgress()
    },
    mounted() {},
    data: {
        preactive: false,
        seleccionGrados: [{
            Preescolar: [{
                id: 'P',
                name: 'Parvulos',
                check: false,
                preCheck: false
            }, {
                id: 'PJ',
                name: 'Pre Jardín',
                check: false,
                preCheck: false
            }, {
                id: 'J',
                name: 'Jardín',
                check: false,
                preCheck: false
            }, {
                id: 'T',
                name: 'Transición',
                check: false,
                preCheck: false
            }]
        }, {
            Primaria: [{
                    id: 1,
                    name: "Primero",
                    check: false,
                    preCheck: false
                },
                {
                    id: 2,
                    name: "Segundo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 3,
                    name: "Tercero",
                    check: false,
                    preCheck: false
                },
                {
                    id: 4,
                    name: "Cuarto",
                    check: false,
                    preCheck: false
                },
                {
                    id: 5,
                    name: "Quinto",
                    check: false,
                    preCheck: false
                }
            ],
        }, {
            Secundaria: [{
                    id: 6,
                    name: "Sexto",
                    check: false,
                    preCheck: false
                },
                {
                    id: 7,
                    name: "Séptimo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 8,
                    name: "Octavo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 9,
                    name: "Noveno",
                    check: false,
                    preCheck: false
                }
            ],
        }, {
            Media: [{
                    id: 10,
                    name: "Décimo",
                    check: false,
                    preCheck: false
                },
                {
                    id: 11,
                    name: "Once",
                    check: false,
                    preCheck: false
                }
            ]
        }],
        selectTypeCourses: 0,
        tabSelected: 1,
        arrayError: [],
        letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
        temp: [],
        courses: [],
        preSelectType: false,
        progresoUsuario: 0
    },
    methods: {
        autoTour() {
            var intro = introJs();
            intro.start("tab" + this.tabSelected);
        },
        tour() {
            let self = this
            if (this.progresoUsuario < 2 || !this.progresoUsuario) {
                introJs().start('tab1')
            } else if (this.progresoUsuario == 2) {
                self.tabSelected = 2
                var intro = introJs();
                intro.onbeforechange(function() {
                    if (this._currentStep == 1) {
                        if (self.tabSelected != 2) {
                            swal("Presiona la pestaña solicitada en el tour y luego presiona el botón siguiente.");
                            return false;
                        }
                    }
                });
                intro.exit("tab1");
                intro.start("tab2");
            }
        },
        getProgress() {
            var self = this
            const data = new FormData()
            data.append('getProgressPestana', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    if (res) {
                        console.log(res.data.pestana_uno);

                        self.progresoUsuario = res.data.pestana_uno
                    }
                }).then(() => {
                    self.tour()
                    self.getGradesChecked()
                })
                .catch(err => {
                    console.error(err)
                })
        },
        setGrades(confirm) {
            const data = new FormData()
            data.append('grado', confirm)
            const self = this;
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .catch(error => {
                    self.arrayError.push(error.response);
                })

        },
        activeGrades() {
            const self = this
            this.seleccionGrados.forEach(element => {
                for (key in element) {
                    element[key].forEach(value => {
                        if (value.check === true) {
                            self.setGrades(value.id)
                        }
                    })
                }
            })

            const data = new FormData()
            data.append('tipoGrupo', this.selectTypeCourses)
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(function(response) {
                    console.log(response);

                    var valError = self.arrayError.length
                    if (valError > 0) {
                        var stringError
                        self.arrayError.forEach(error => {
                            stringError = stringError + error + "\n"
                        })
                        swal({
                            allowOutsideClick: "true",

                            title: "Han habido algunos errorres",
                            text: stringError,
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                        })
                    } else {
                        swal({
                                allowOutsideClick: "true",

                                title: "Correcto",
                                text: "Has registrado los cursos satisfactoriamente.",
                                icon: "success",
                                buttons: true,
                            })
                            .then(() => {
                                self.getProgress()
                            }).then(() => {
                                let intro = introJs()
                                intro.exit('tab1')
                                if (self.progresoUsuario == 2) {
                                    self.tabSelected = 2
                                    progreso.getProgress()
                                }
                            })

                    }
                })
                .then(() => {
                    self.temp = []
                    self.createTab()
                })
        },
        alertGrades() {
            let self = this
            swal({
                    allowOutsideClick: "true",

                    title: "¿Esta seguro de los cambios realizados?",
                    text: "Una vez guardados los cambios no se podrán revertir las configuraciones ¿Quieres continuar con la configuración actual?",
                    icon: "warning",
                    buttons: ['Cancelar', 'Sí, quiero continuar'],
                    dangerMode: true
                })
                .then((willDelete) => {
                    if (willDelete) {
                        self.temp = []
                        self.activeGrades()
                    } else {
                        swal("No haz realizado los cambios.", {
                            icon: "success",
                            button: 'De acuerdo'
                        });
                    }
                });
        },
        getGradesChecked() {
            const self = this;
            var data = new FormData()
            data.append('function', 'get_info')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(function(response) {
                    for (var i in response.data) {
                        self.seleccionGrados.forEach(element => {
                            for (key in element) {
                                element[key].forEach(value => {
                                    if (value.id == response.data[i]) {
                                        value.check = true
                                        value.preCheck = true
                                    }
                                })
                            }
                        })
                    }
                    self.createTab()
                });
        },
        createTab() {
            let self = this;
            self.temp = []
            data = new FormData()
            data.append('function', 'get_type')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(function(response) {

                    if (response.data == 1 || response.data == 2) {
                        self.preSelectType = true
                    }
                    self.selectTypeCourses = response.data

                    self.seleccionGrados.forEach(element => {
                        for (key in element) {
                            element[key].forEach(value => {
                                if (value.check == true) {
                                    self.temp.push(value)
                                }
                            })
                        }
                    })
                })
            this.getCourses()
        },
        addCourse(grupo, curso, check) {
            const self = this
            if (check.srcElement.checked == true) {
                const newCourse = new Object()
                newCourse.id = grupo + curso
                newCourse.grupo = grupo
                newCourse.curso = curso
                newCourse.state = 1
                this.courses.push(newCourse)
            } else {
                const self = this
                this.courses.forEach(courseData => {
                    if (courseData.id == grupo + curso) {
                        var i = self.courses.indexOf(courseData)
                        self.courses.splice(i, 1)
                    }
                })
            }
        },
        setCourse() {
            let self = this
            swal({
                    allowOutsideClick: "true",

                    title: "¿Esta seguro de los cambios realizados?",
                    text: "Una vez guardados los cambios no se podrán eliminar los cursos ¿Quieres continuar con la configuración actual?",
                    icon: "warning",
                    buttons: ['Cancelar', 'Sí, quiero continuar'],
                    dangerMode: true
                })
                .then((willDelete) => {
                    if (willDelete) {
                        self.courses.forEach(courseData => {
                            const data = new FormData()
                            data.append('setGroupe', courseData.grupo)
                            data.append('setCourses', courseData.curso)
                            axios.post('./controllers/grados-cursos.ctrl.php', data)
                                .then(res => {
                                    if (res) {
                                        swal({
                                                allowOutsideClick: "true",
                                                title: "Correcto",
                                                text: "Ha registrado satisfactoriamente los cursos",
                                                icon: "success",
                                            })
                                            .then(() => {
                                                self.getProgress()
                                                if (self.progresoUsuario == 2) {
                                                    window.location.href = "./index.php?module=carga-academica"
                                                } else {
                                                    let intro = introJs();
                                                    intro.exit("tab2")
                                                }
                                            })
                                    }

                                })
                        })
                    } else {
                        swal("No haz realizado los cambios.", {
                            icon: "success",
                            button: 'De acuerdo'
                        });
                    }
                });
        },
        isset(grupo, curso) {

            const tempCourse = this.courses.filter(coursesData => {
                var identifyCourse = grupo + '' + curso
                return identifyCourse == coursesData.id && coursesData.state == 2
            })
            if (tempCourse.length > 0) {
                return true
            } else {
                return false
            }
        },
        getCourses() {
            const self = this
            const data = new FormData()
            data.append('getGroups', 'get')
            axios.post('./controllers/grados-cursos.ctrl.php', data)
                .then(res => {
                    if (res.data.length > 0) {
                        self.preactive = true
                    }

                    res.data.forEach(dataRes => {
                        const newCourse = new Object()
                        newCourse.id = dataRes.grado + dataRes.grupo
                        newCourse.grupo = dataRes.grupo
                        newCourse.curso = dataRes.grado
                        newCourse.state = 2
                        this.courses.push(newCourse)
                    })

                })
                .catch(err => {
                    console.error(err);
                })

        }
    }

})