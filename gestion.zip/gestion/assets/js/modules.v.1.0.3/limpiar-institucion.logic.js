var limpiarInstitucion = new Vue({
    el: "#module-clean",
    methods: {
      clean(){
        swal({
            title: "¿Está seguro de realizar la limpieza de esta institución?",
            text: "Tenga en cuenta que para realizar esta limpieza se tomará la información de su terminal y su usuario por concepto de seguridad de la información.",
            buttons: ['Cancelar', 'Sí, estoy seguro']
        }).then((ok)=>{
            if(ok){
                let load  = swal({
                    allowOutsideClick: "true",
                    title: 'Configurando...',
                    text: "La limpieza de la institución puede demorar unos minutos. \n Por favor espere.",
                    icon: "info",
                    button: false,
                    closeOnClickOutside: false
                })
                axios.post('controllers/limpiar-institucion.ctrl.php',true)
                .then(res => {      
                    swal({
                        allowOutsideClick: "true",
                        title: "Correcto",
                        text: "Has realizado los cambios satisfactoriamente.",
                        icon: "success",
                        buttons: false,
                    })          
                    console.log(res.data)
                    if (res.data) {
                        // window.location = 'http://sie.educar.com.co/gestion-institucional'
                    }
                })
                .catch(err => {
                    console.error(err); 
                })
            }
        })
      }  
    },
})