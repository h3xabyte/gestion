const agregarCoordinador = new Vue({
    el: '#module-agregar-coordinadores',
    created: function() {
        this.getTypeCourse(),
            this.getSubjects(),
            this.getGrades(),
            this.getTeachs()
    },
    data: {
        tabSelected: 1,
        setName: '',
        setLastName: '',
        setEmail: '',
        dataImport: [],
        setMovil: '',
        subjects: [],
        groupesEdit: [],
        asignEdits: [],
        selectTypeCourses: 1,
        deleteArrayEdits: [],
        groupes: [],
        grades: [],
        formAsign: '',
        formAsignName: '',
        formGrade: '',
        asignSelect: [],
        tempGroup: [],
        listTeach: [],
        editTeach: {},
        fileLoad: false,
        progresoUsuario: 0,
        dataUserData: '',
        groupesEditSubject: [],
        editAsign: '',
        editGrade: '',
        loadComplete: 0,
        coursesLetters: [{
            1: 'Primero',
            2: 'Segundo',
            3: 'Tercero',
            4: 'Cuarto',
            5: 'Quinto',
            6: 'Sexto',
            7: 'Septimo',
            8: 'Octavo',
            9: 'Noveno',
            10: 'Decimo',
            11: 'Once',
            P: 'Párvulos',
            PJ: 'PreJardín',
            J: 'Jardín',
            T: 'Transición'
        }],
        letters: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P'],
        reload: false
    },
    mounted: function() {
        this.getReload(),
            this.getProgress(),
            this.listenToInput()

    },
    methods: {
        getReload() {
            var url = new URL(location.href)
            var c = url.searchParams.get("reload");
            if (c) {
                this.tabSelected = 2
                this.reload = true
            }
        },
        autoTour() {
            var intro = introJs();
            intro.start("tab" + this.tabSelected);
        },
        tour() {
            let self = this
            if (this.reload && this.progresoUsuario == 1) {
                this.tabSelected = 2
                let intro = introJs()
                intro._currentStep = 0
                intro.start("tab2")
                console.log(intro);

            } else {
                if (this.progresoUsuario == 0 || !this.progresoUsuario) {
                    let intro = introJs();
                    intro.onbeforechange(function() {
                        if (this._currentStep === 2 && (!self.setName || !self.setLastName || !self.setEmail || !self.setMovil)) {
                            swal("Ingresa todos los datos del coordinador y luego presiona el botón siguiente.");
                            return false;
                        } else if (this._currentStep === 2 && (self.isNumber(self.setMovil))) {
                            swal("Ingresa un número de celular valido y luego presiona el botón siguiente.")
                            return false
                        } else if (this._currentStep === 2 && (!self.setEmail.split('@')[1] || !self.setEmail.split('.')[1])) {
                            swal("Ingresa un correo valido y luego presiona el botón siguiente.")
                            return false
                        }
                    });
                    intro.start("tab1");

                } else if (this.progresoUsuario == 1) {
                    self.tabSelected = 2
                    let intro = introJs();
                    intro.onbeforechange(function() {
                        if (this._currentStep === 1 && self.tabSelected != 2) {
                            swal("Presiona la pestaña solicitada en el tour.")
                            return false
                        }
                    });
                    intro.exit("tab1")
                    intro.start("tab2")
                } else {
                    let intro = introJs();
                    intro.exit("tab1")
                    intro.exit("tab2")
                }
            }
        },
        getProgress() {
            var self = this;
            const data = new FormData();
            data.append("getProgressPestana", "get")
            axios
                .post("./controllers/grados-cursos.ctrl.php", data)
                .then(res => {
                    self.progresoUsuario = res.data.pestana_tres
                    self.tour()
                })
                .catch(err => {
                    console.error(err)
                });
        },
        setTeach() {
            if (
                /^[a-zA-Z0-9][a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,3}(?:\.[a-zA-Z]{2})?$/.test(this.setEmail) &&
                /^[a-zA-ZáéíóúÁÉÍÓÚ ]+$/.test(this.setName) &&
                /^[a-zA-ZáéíóúÁÉÍÓÚ ]+$/.test(this.setLastName)) {
                if (!this.isNumber(this.setMovil)) {
                    let self = this;
                    let span = document.createElement("div")
                    span.className = "container_name"
                    let text = "Ingresarás al docente ";
                    text += "<b>" + self.setName + " " + self.setLastName + "</b>";
                    text += ". ¿Quieres continuar con la gestión?";
                    span.innerHTML = text;

                    if (
                        self.setName &&
                        self.setLastName &&
                        self.setMovil &&
                        self.setEmail
                    ) {
                        swal({
                            allowOutsideClick: "true",

                            title: "Correcto",
                            content: span,
                            allowOutsideClick: "true",
                            icon: "success",
                            buttons: ["Cancelar", "Sí, quiero continuar"],
                            dangerMode: true
                        }).then(willDelete => {
                            if (willDelete) {
                                self.setUsers()
                            } else {
                                swal("No has realizado cambios")
                            }
                        })
                    }

                } else {
                    swal({
                        title: 'Atención',
                        text: 'Por favor ingrese un celular valido.',
                        icon: 'warning'
                    })
                }
            }


        },
        //
        setUsers() {
            swal({
                allowOutsideClick: "true",
                title: 'Configurando...',
                text: "La creación de los usuarios puede demorar unos minutos. \n Por favor espere.",
                icon: "info",
                button: false,
                closeOnClickOutside: false
            });

            if (this.setEmail.split('@')[1] && this.setEmail.split('.')[1]) {
                if (!this.isNumber(this.setMovil)) {
                    let self = this
                    let data = new FormData()
                    data.append("setUser", 'set')
                    data.append("setName", this.setName)
                    data.append("setLastName", this.setLastName)
                    data.append("setEmail", this.setEmail)
                    data.append("setMovil", this.setMovil)
                    axios.post("./controllers/agregar-coordinador.ctrl.php", data)
                        .then(res => {
                            // this is a Node object
                            if (res.data == "error_exist") {
                                swal(
                                    "Error en el registro",
                                    "Este usuario no está disponible ingrese uno nuevo"
                                )
                            } else if (res.data == "error_email") {
                                swal(
                                    "Error en el registro",
                                    "Este correo no está disponible ingrese uno nuevo"
                                )
                            } else if (res.data == "error_alll_data") {
                                swa1("Error en el registro, por favor ingrese todos los datos")
                            } else {

                                passData = res.data.split('u-')[0]
                                userData = res.data.split('u-')[1]
                                self.dataUserData = userData
                                self.setUserSubject(userData)
                            }
                        })
                } else {
                    swal({
                        title: 'Atención',
                        text: 'Por favor ingrese un celular valido.',
                        icon: 'warning'
                    })
                }
            } else {
                swal({
                    title: 'Atención',
                    text: 'Por favor ingrese un correo valido.',
                    icon: 'warning'
                })
            }
        },

        getGroupesEdit(asignID, gradeID, asignName) {
            if (asignName == null) {
                this.subjects.forEach(dataSubject => {
                    if (dataSubject.id == asignID) {
                        asignName = dataSubject.value;
                    }
                })
            }
            let self = this;
            let data = new FormData()
            data.append("getGroups", "get")
            axios.post("./controllers/agregar-coordinador.ctrl.php", data).then(res => {
                let objetosGroup = [];
                res.data.forEach(dataRes => {
                    if (dataRes.grado == gradeID) {
                        let newGroupe = new Object()
                        newGroupe.asign = asignName;
                        newGroupe.grade = gradeID;
                        newGroupe.value = dataRes.grupo;
                        newGroupe.idGroup = dataRes.idGroup;
                        newGroupe.idCourse = dataRes.idCourse;
                        newGroupe.check = false;
                        let gradeName = "";

                        self.coursesLetters.forEach(dataCourse => {
                            for (data in dataCourse) {
                                if (data == gradeID) {
                                    gradeName = dataCourse[data];
                                }
                            }
                        })
                        objetosGroup.push(newGroupe)
                    }
                })

                objetosGroup.forEach(dataObjeto => {
                    self.letters.forEach(function(data, index) {
                        if (data == dataObjeto.value) {
                            dataObjeto.number = index + 1;
                        }
                    })

                    let validate = false;
                    self.groupesEdit.forEach(dataGroupe => {
                        if (
                            dataObjeto.asign + dataObjeto.value + dataObjeto.grade ==
                            dataGroupe.asign + dataGroupe.value + dataGroupe.grade
                        ) {
                            validate = true;
                        }
                    })

                    if (!validate) {
                        self.groupesEdit.push(dataObjeto)
                    }
                })
            })
        },

        setUserSubject(user) {
            let countAsign = 0
            let countDataAsign = 0
            let self = this
            let limit = 0
            this.asignSelect.forEach(function(dataAsign) {
                dataAsign.groups.forEach(function(dataGroups) {
                    if (dataGroups.check == true) {
                        limit++
                    }
                })
            })
            if (this.asignSelect.length == 0) {

                let span = document.createElement("div")
                span.className = "container_name"
                span.innerHTML =
                    "Se ha creado satisfactoriamente al coordinador <b>" +
                    self.setName + " " + self.setLastName + "</b>, sus datos de acceso son: <br> Usuario: <b>" + self.dataUserData + "</b><br> Contraseña: <b>" +
                    passData +
                    "</b>";
                swal({
                    allowOutsideClick: "true",

                    title: "Correcto",
                    content: span,
                    confirmButtonText: "V redu",
                    allowOutsideClick: "true",
                    icon: "success",
                    closeOnClickOutside: false
                }).then(() => {
                    self.setName = ""
                    self.setLastName = ""
                    self.setEmail = ""
                    self.setMovil = ""
                    self.asignSelect = []
                    self.formAsign = ''
                    self.formGrade = ''
                    self.getTeachs()
                    self.getProgress()
                })

            } else {

                this.asignSelect.forEach(function(dataAsign) {
                    countAsign++
                    dataAsign.groups.forEach(function(dataGroups) {
                        if (dataGroups.check == true) {
                            let data = new FormData()
                            data.append("setUserSubject", "set")
                            data.append("setSubjectID", dataAsign.id)
                            data.append("setGroup", dataGroups.idGroup)
                            data.append("setCourse", dataGroups.idCourse)
                            data.append("setTeach", user)
                            axios
                                .post("./controllers/agregar-coordinador.ctrl.php", data)
                                .then(res => {

                                    if (res.data) {
                                        progreso.getProgress()
                                    }
                                    countDataAsign++
                                    if (countAsign == self.asignSelect.length && countDataAsign == limit) {
                                        let span = document.createElement("div")
                                        span.className = "container_name"
                                        span.innerHTML =
                                            "Se ha creado satisfactoriamente al coordinador <b>" +
                                            self.setName + " " + self.setLastName + "</b>, sus datos de acceso son: <br> Usuario: <b>" + self.dataUserData + "</b><br> Contraseña: <b>" +
                                            passData +
                                            "</b>";
                                        swal({
                                            allowOutsideClick: "true",



                                            title: "Correcto",
                                            content: span,
                                            confirmButtonText: "V redu",

                                            icon: "success",
                                            closeOnClickOutside: false
                                        }).then(() => {
                                            self.setName = ""
                                            self.setLastName = ""
                                            self.setEmail = ""
                                            self.setMovil = ""
                                            self.asignSelect = []
                                            self.formAsign = ''
                                            self.formGrade = ''
                                            self.getTeachs()
                                            self.getProgress()
                                        })
                                    }

                                })
                        }
                    })

                })
            }
        },
        // 
        getTypeCourse() {
            let self = this;
            data = new FormData()
            data.append('function', 'get_type')
            axios.post('./controllers/agregar-coordinador.ctrl.php', data)
                .then(function(response) {
                    self.selectTypeCourses = response.data
                })
        },
        getSubjects() {
            let self = this
            let data = new FormData()
            data.append('getSubject', 'get')
            axios.post('./controllers/agregar-coordinador.ctrl.php', data)
                .then(res => {
                    let validateSubject = []
                    for (value in res.data) {
                        validateSubject.push(res.data[value])
                    }
                    validateSubject = validateSubject.filter(function(valor, indiceActual, arreglo) {
                        let indiceAlBuscar = arreglo.indexOf(valor);
                        if (indiceActual === indiceAlBuscar) {
                            return true;
                        } else {
                            return false;
                        }
                    })

                    validateSubject.forEach(dataValidate => {
                        let validate = false
                        self.subjects.forEach(dataSubject => {
                            if (dataSubject.value == dataValidate.nombre) {
                                validate = true
                            }
                        })

                        if (validate == false) {
                            let newSubject = new Object()
                            newSubject.id = dataValidate.id
                            newSubject.value = dataValidate.nombre
                            newSubject.check = true
                            newSubject.preCheck = true
                            newSubject.newValue = ''
                            newSubject.edit = false
                            self.subjects.push(newSubject)
                        }
                    })
                })
                .catch(err => {
                    console.error(err)
                })
        },
        // 
        getGroupes() {
            let self = this;
            let asign = self.subjects.find(dataSubject => {
                return dataSubject.id == self.formAsign;
            })
            asignName = asign.value;
            let data = new FormData()
            data.append("getGroups", "get")
            axios.post("./controllers/agregar-coordinador.ctrl.php", data).then(res => {
                let objetosGroup = [];
                res.data.forEach(dataRes => {
                    if (dataRes.grado == this.formGrade) {
                        let newGroupe = new Object()
                        newGroupe.asign = asign.value;
                        newGroupe.grade = this.formGrade;
                        newGroupe.value = dataRes.grupo;
                        newGroupe.idGroup = dataRes.idGroup;
                        newGroupe.idCourse = dataRes.idCourse;
                        newGroupe.check = false;

                        let gradeName = "";

                        self.coursesLetters.forEach(dataCourse => {
                            for (data in dataCourse) {
                                if (data == this.formGrade) {
                                    gradeName = dataCourse[data];
                                }
                            }
                        })
                        objetosGroup.push(newGroupe)
                    }
                })

                objetosGroup.forEach(dataObjeto => {
                    self.letters.forEach(function(data, index) {
                        if (data == dataObjeto.value) {
                            dataObjeto.number = index + 1;
                        }
                    })

                    let validate = false;
                    self.groupes.forEach(dataGroupe => {
                        if (
                            dataObjeto.asign + dataObjeto.value + dataObjeto.grade ==
                            dataGroupe.asign + dataGroupe.value + dataGroupe.grade
                        ) {
                            validate = true;
                        }
                    })


                    if (!validate) {
                        self.groupes.push(dataObjeto)
                    }


                })
            })
        },
        // 
        getGrades() {
            let self = this;
            let data = new FormData()
            data.append("getGroups", "get")
            axios
                .post("./controllers/agregar-coordinador.ctrl.php", data)
                .then(res => {
                    let temp = [];
                    let arrData = [];

                    res.data.forEach(dataRes => {
                        arrData.push(dataRes)
                        temp.push(dataRes.grado)
                    })

                    self.tempGroup = arrData;

                    temp = temp.filter(function(valor, indiceActual, arreglo) {
                        let indiceAlBuscar = arreglo.indexOf(valor)
                        if (indiceActual === indiceAlBuscar) {
                            return true;
                        } else {
                            return false;
                        }
                    })

                    temp.forEach(dataTemp => {
                        self.coursesLetters.forEach(dataCourse => {
                            let objetoGrupo = new Object()
                            objetoGrupo.number = dataTemp;
                            objetoGrupo.letter = dataCourse[dataTemp];
                            self.grades.push(objetoGrupo)
                        })
                    })
                })
                .catch(err => {
                    console.error(err)
                })
        },
        // 
        editTeachSubject() {
            swal({
                allowOutsideClick: "true",
                title: 'Configurando...',
                text: "La edición de los usuarios puede demorar unos minutos. \n Por favor espere.",
                icon: "info",
                button: false,
                closeOnClickOutside: false
            })
            let self = this;
            let asignGroupSearch = [];
            let asignGroupDelete = [];
            let editState = self.asignEdits.find(dataAsign => {
                return dataAsign.edit
            })
            self.loadComplete = 0
            if (editState) {
                swal("Atención", "Termine de editar los grupos para guardar cambios", "warning")
            } else {
                new Promise((resolve, reject) => {
                    if (self.deleteArrayEdits.length == 0) {
                        resolve()
                    } else {
                        let lengthDelArray = self.deleteArrayEdits.length
                        let countDelArray = 0
                        self.deleteArrayEdits.forEach(dataDelete => {
                            let lengthDataDel = dataDelete.groups.length
                            let countDataDel = 0
                            let countValidate = 0
                            dataDelete.groups.forEach(dataGroups => {
                                countDataDel++
                                if (
                                    dataGroups.idGroup > 0 &&
                                    dataDelete.asign == dataGroups.asign &&
                                    dataDelete.grade == dataGroups.grade
                                ) {
                                    dataGroups.groupsLetter = dataDelete.groupsLetter;
                                    asignGroupDelete.push(dataGroups)

                                    let data = new FormData()
                                    data.append("delUserSubject", "setDel")
                                    data.append("setSubjectID", dataDelete.id)
                                    data.append("setGroup", dataGroups.idGroup)
                                    data.append("setCourse", dataGroups.idCourse)
                                    data.append("setTeach", self.editTeach.id)
                                    data.append("setCheck", "false")
                                    axios
                                        .post("./controllers/agregar-coordinador.ctrl.php", data)
                                        .then(res => {
                                            if (res) {
                                                console.log(res.data);

                                                countValidate++
                                                if (countDataDel == lengthDataDel) {
                                                    countDelArray++
                                                }
                                                if (countDelArray == lengthDelArray && countDataDel == lengthDataDel) {
                                                    resolve()
                                                }
                                            }
                                        })
                                }
                            })
                        })
                    }
                }).then(() => {
                    if (self.asignEdits.length != 0) {
                        let lengthAsign = self.asignEdits.length
                        let countAsign = 0
                        self.asignEdits.forEach(dataAsign => {
                            let lengthDataAsign = dataAsign.groups.length
                            let countDataAsign = 0
                            dataAsign.groups.forEach(dataGroups => {
                                countDataAsign++
                                if (
                                    dataGroups.idGroup > 0 &&
                                    dataAsign.asign == dataGroups.asign &&
                                    dataAsign.grade == dataGroups.grade
                                ) {
                                    dataGroups.groupsLetter = dataAsign.groupsLetter;
                                    asignGroupSearch.push(dataGroups)
                                    if (!dataGroups.check) {
                                        asignGroupDelete.push(dataGroups)
                                    }
                                    let data = new FormData()
                                    data.append("editUserSubject", "set")
                                    data.append("setSubjectID", dataAsign.id)
                                    data.append("setGroup", dataGroups.idGroup)
                                    data.append("setCourse", dataGroups.idCourse)
                                    data.append("setTeach", self.editTeach.id)
                                    data.append("setCheck", dataGroups.check)
                                    axios.post("./controllers/agregar-coordinador.ctrl.php", data)
                                        .then((res) => {
                                            if (res) {
                                                if (countDataAsign == lengthDataAsign) {
                                                    countAsign++
                                                }
                                                if (countDataAsign == lengthDataAsign && countAsign == lengthAsign) {
                                                    // self.editSData(asignGroupDelete, asignGroupSearch)
                                                    self.listTeach = []

                                                    self.getTeachs(true)
                                                }
                                            }
                                        })
                                }
                            })
                        })

                    } else {
                        // self.editSData(asignGroupDelete, asignGroupSearch)
                        self.listTeach = []
                        self.getTeachs(true)
                    }
                })


            }

        },
        getTeachs(alert) {
            this.listTeach = []
            let data = new FormData()
            let self = this;
            data.append("getInfoTeachs", "get")
            axios
                .post("./controllers/agregar-coordinador.ctrl.php", data)
                .then(res => {
                    if (res.data) {
                        res.data.forEach(dataRes => {

                            if (dataRes.curso == "******") {
                                dataRes.curso = "";
                            }
                            let duplicate = false
                            let limit = (dataRes.curso.split(' ').length) - 1

                            if (self.selectTypeCourses == 1) {
                                let limitLetter = dataRes.curso.split('').length
                                self.letters.forEach(element => {
                                    letterData = dataRes.curso.split('')[(limitLetter - 1)]
                                    if (letterData == element) {
                                        dataRes.curso = dataRes.curso.slice(0, limitLetter - 1) + " " + dataRes.curso.slice(limitLetter - 1);
                                    }

                                });

                            } else {
                                courseNumber = dataRes.curso.split(' ')[limit]
                                if (courseNumber.split('00').length > 1) {
                                    dataRes.curso = dataRes.curso.replace("00", "0 0")
                                } else {
                                    dataRes.curso = dataRes.curso.replace("0", " 0")
                                }
                            }

                            self.coursesLetters.forEach(dataCourse => {
                                for (var variable in dataCourse) {
                                    let separador = dataRes.curso.split(' ')[limit]
                                    if (dataRes.curso.split(' ')[limit] == variable) {
                                        dataRes.curso = dataRes.curso.split(" " + separador)[0] + " " + dataCourse[variable] + dataRes.curso.split(" " + separador)[1]
                                    }
                                }
                            })

                            self.listTeach.forEach(dataList => {
                                if (dataList.id == dataRes.id) {
                                    let data = dataList.grupos.find(dataGrupos => {
                                        return dataGrupos === dataRes.curso;
                                    })

                                    if (data == undefined) {
                                        if (dataRes.curso != '') {
                                            dataList.grupos.push(dataRes.curso)
                                            dataList.sData += dataRes.curso + ", ";
                                        }

                                    }
                                    dataList.preCheck = true;
                                    duplicate = true;
                                }
                            })

                            if (!duplicate) {
                                dataRes.preCheck = true;
                                dataRes.grupos = [];
                                if (dataRes.curso != "" && !dataRes.grupos.includes(dataRes.curso)) {
                                    dataRes.grupos.push(dataRes.curso)
                                    dataRes.sData = dataRes.curso + ", ";
                                } else {
                                    dataRes.sData = "";
                                }
                                dataRes.edit = false;

                                self.listTeach.push(dataRes)
                            }
                        })
                    }
                }).then(() => {
                    if (alert) {
                        self.listTeach = []
                        swal({
                            allowOutsideClick: "true",
                            title: "Correcto",
                            text: "Has modificado satisfactoriamente las asignaturas del coordinador " +
                                self.editTeach.nombre,
                            icon: "success"
                        }).then(() => {
                            window.location.href = "http://sie.educar.com.co/gestion-institucional/index.php?module=agregar-coordinador&reload=1"
                        })
                    }
                })
        },
        // 
        addAsign(paramID, paramAsign, paramGrade, paramGroup, array, paramMsj = false) {
            let objectAsign = new Object()
            let self = this;
            let asign
            if (!paramAsign) {
                asign = self.subjects.find(dataSubject => {
                    return dataSubject.id == self.formAsign;
                })

            } else {
                asign = paramAsign
            }
            if (array == "edit") {
                this.subjects.forEach(dataSubject => {
                    if (dataSubject.id == paramID) {
                        paramAsign = dataSubject.value;
                    }
                })
                self.coursesLetters.forEach(dataCourses => {
                    for (course in dataCourses) {
                        if (paramGrade == course) {
                            paramGroup = dataCourses[course];
                        }
                    }
                })
            }

            const tempGroups = [];

            if (array == "select") {
                this.groupes.forEach(dataGroupe => {
                    for (data in dataGroupe) {
                        if (
                            dataGroupe.grade == this.formGrade &&
                            dataGroupe.asign == asign.value
                        ) {
                            dataGroupe.groupsLetter = paramGroup;
                            tempGroups.push(dataGroupe)
                        }
                    }
                })
            } else {
                this.groupesEdit.forEach(dataGroupe => {
                    if (
                        dataGroupe.grade == paramGrade &&
                        dataGroupe.asign == paramAsign
                    ) {
                        dataGroupe.groupsLetter = paramGroup;
                        tempGroups.push(dataGroupe)
                    }
                })
            }

            newTempGroups = this.cleanArray(tempGroups)

            if (array == "edit") {
                objectAsign.id = paramID;
                objectAsign.asign = paramAsign;
                objectAsign.grade = paramGrade;
            } else {
                if (asign) {
                    objectAsign.id = this.formAsign;
                    objectAsign.asign = asign.value;
                    objectAsign.grade = this.formGrade;
                } else {
                    swal({
                        allowOutsideClick: "true",
                        text: "Ingrese una asignatura, un curso y un grupo para agregarlo al usuario",
                        icon: "warning"
                    })
                }
            }
            objectAsign.groups = newTempGroups;
            objectAsign.edit = false;

            self.coursesLetters.forEach(dataCourses => {
                for (data in dataCourses) {
                    if (data == objectAsign.grade) {
                        objectAsign.groupsLetter = dataCourses[data];
                    }
                }
            })

            let validate = false;

            if (array == "select") {
                this.asignSelect.forEach(dataAsign => {
                    if (
                        dataAsign.asign == asign.value &&
                        dataAsign.grade == this.formGrade
                    ) {
                        validate = true;
                    }
                    if (
                        dataAsign.asign == paramAsign &&
                        dataAsign.groupsLetter == paramGroup
                    ) {
                        dataAsign.edit = false;
                    }
                })
            } else {
                this.asignEdits.forEach(dataAsign => {
                    if (dataAsign.asign == paramAsign && dataAsign.grade == paramGrade) {
                        validate = true;
                    }
                    if (
                        dataAsign.asign == paramAsign &&
                        dataAsign.groupsLetter == paramGroup
                    ) {
                        dataAsign.edit = false;
                    }
                })
            }

            if (validate == false) {
                if (newTempGroups.length > 0) {
                    if (array == "select") {
                        this.asignSelect.push(objectAsign)
                    } else {
                        let newData = [];
                        for (var data in objectAsign.groups) {

                            if (objectAsign.groups[data].check) {
                                if (condition) {

                                }
                                newData.push(
                                    objectAsign.asign +
                                    " " +
                                    objectAsign.groupsLetter +
                                    " " +
                                    objectAsign.groups[data].value
                                )
                            }

                        }

                        self.listTeach.forEach(dataList => {
                            if (dataList.id == self.editTeach.id) {
                                newData.forEach(dataNew => {
                                    dataList.preCheck = false;
                                    dataList.grupos.push(dataNew)
                                    dataList.sData += dataNew + ", "
                                })
                            }
                        })
                        this.asignEdits.push(objectAsign)
                    }
                } else {
                    if (!paramMsj) {
                        swal(
                            "Por favor ingrese la asignatura, grado y los cursos que desea agregar a este coordinador"
                        )
                    }
                }
            } else {
                if (array == "select") {
                    this.asignSelect.forEach(dataAsign => {
                        if (
                            (dataAsign.grade == this.formGrade && dataAsign.asign == asign) ||
                            (dataAsign.grade == paramGrade &&
                                dataAsign.asign == paramAsign &&
                                dataAsign.check == true)
                        ) {
                            dataAsign.groups = newTempGroups;
                            swal("Actualizaste la asignatura correctamente")
                        }
                    })
                } else {
                    let tempSData = ''
                    this.asignEdits.forEach(dataAsign => {
                        if (
                            (dataAsign.grade == this.formGrade && dataAsign.asign == asign) ||
                            (dataAsign.grade == paramGrade &&
                                dataAsign.asign == paramAsign &&
                                dataAsign.check == true)
                        ) {
                            dataAsign.groups = newTempGroups;
                            swal("Actualizaste la asignatura correctamente")
                        }
                    })

                    newTempGroups.forEach(dataNewTemp => {
                        if (dataNewTemp.check) {
                            let newData = dataNewTemp.asign + " " + dataNewTemp.groupsLetter + " " + dataNewTemp.value
                            self.listTeach.forEach(dataList => {
                                if (dataList.id == self.editTeach.id && dataList.sData.split(newData).length == 1) {
                                    dataList.grupos.push(newData)
                                    dataList.sData += newData + ", "
                                }
                            })
                        }
                    })

                }
            }
        },
        addAsignEdit(paramID, paramAsign, paramGrade, paramGroup, array, modal) {

            let objectAsign = new Object()
            let self = this;
            let asign

            if (!paramAsign) {
                asign = self.subjects.find(dataSubject => {
                    return dataSubject.id == self.editAsign;
                })
            } else {
                asign = paramAsign
            }
            if (array == "edit") {
                this.subjects.forEach(dataSubject => {
                    if (dataSubject.id == paramID) {
                        paramAsign = dataSubject.value;
                    }
                })
                self.coursesLetters.forEach(dataCourses => {
                    for (course in dataCourses) {
                        if (paramGrade == course) {
                            paramGroup = dataCourses[course];
                        }
                    }
                })
            }
            const tempGroups = [];
            this.groupesEdit.forEach(dataGroupe => {
                if (
                    dataGroupe.grade == paramGrade &&
                    dataGroupe.asign == paramAsign
                ) {
                    dataGroupe.groupsLetter = paramGroup;
                    tempGroups.push(dataGroupe)
                }
            })
            newTempGroups = this.cleanArray(tempGroups)
            if (array == "edit") {
                objectAsign.id = paramID;
                objectAsign.asign = paramAsign;
                objectAsign.grade = paramGrade;
            } else {
                if (asign) {
                    objectAsign.id = this.editAsign;
                    objectAsign.asign = asign.value;
                    objectAsign.grade = this.editGrade;
                }
            }
            objectAsign.groups = newTempGroups;
            objectAsign.edit = false;
            self.coursesLetters.forEach(dataCourses => {
                for (data in dataCourses) {
                    if (data == objectAsign.grade) {
                        objectAsign.groupsLetter = dataCourses[data];
                    }
                }
            })
            let validate = false;
            let validateTrue = newTempGroups.find(datafind => {
                return datafind.check
            })

            if (validateTrue || modal) {

                if (modal) {
                    swal({
                        title: "Atención",
                        text: "Estimado usuario recuerda que al editar o eliminar las asociasiones de los cursos de este profesor no se podrá recuperar la información. \n ¿Quieres continuar?",
                        icon: "warning",
                        buttons: ['Cancelar', 'Continuar']
                    }).then((res) => {
                        if (res) {
                            this.asignEdits.forEach(dataAsign => {
                                if (!asign) {
                                    swal({
                                        title: "Atención",
                                        text: "Por favor ingrese una materia, un grado y un curso",
                                        icon: "warning"
                                    })
                                } else {
                                    if ((dataAsign.asign == paramAsign && dataAsign.grade == paramGrade) ||
                                        (dataAsign.asign == asign.value && dataAsign.grade == this.editGrade)) {
                                        validate = true;
                                    }
                                    if (
                                        dataAsign.asign == paramAsign &&
                                        dataAsign.groupsLetter == paramGroup
                                    ) {
                                        dataAsign.edit = false;
                                    }
                                }
                            })
                            if (validate == false) {
                                if (newTempGroups.length > 0) {
                                    if (array == "select") {
                                        this.asignSelect.push(objectAsign)
                                    } else {
                                        let newData = [];
                                        for (var variable in objectAsign) {
                                            for (var data in objectAsign.groups) {
                                                if (objectAsign.groups[data].check) {
                                                    newData.push(
                                                        objectAsign.asign +
                                                        " " +
                                                        objectAsign.groupsLetter +
                                                        " " +
                                                        objectAsign.groups[data].value
                                                    )
                                                }
                                            }
                                            break;
                                        }
                                        self.listTeach.forEach(dataList => {
                                            if (dataList.id == self.editTeach.id) {
                                                newData.forEach(dataNew => {
                                                    dataList.preCheck = false;
                                                    dataList.grupos.push(dataNew)
                                                    dataList.sData += dataNew + ", "
                                                })
                                            }
                                        })
                                        this.asignEdits.push(objectAsign)

                                        self.deleteArrayEdits.forEach((dataDelete, index) => {
                                            if (dataDelete.asign == objectAsign.asign && dataDelete.grade == objectAsign.grade) {
                                                dataDelete.asign = null
                                                dataDelete.grade = null
                                                self.deleteArrayEdits.slice(index, 1)
                                            }
                                        })
                                    }
                                } else {
                                    swal(
                                        "Por favor ingrese la asignatura, grado y los cursos que desea agregar a este profesor"
                                    )
                                }
                            } else {

                                if (array == "select") {
                                    this.asignSelect.forEach(dataAsign => {
                                        if (
                                            (dataAsign.grade == this.editGrade && dataAsign.asign == asign) ||
                                            (dataAsign.grade == paramGrade &&
                                                dataAsign.asign == paramAsign &&
                                                dataAsign.check == true)
                                        ) {
                                            dataAsign.groups = newTempGroups;
                                            swal("Actualizaste la asignatura correctamente")
                                        }
                                    })
                                } else {
                                    let tempSData = ''
                                    this.asignEdits.forEach(dataAsign => {
                                        if (
                                            (dataAsign.grade == this.editGrade && dataAsign.asign == asign) ||
                                            (dataAsign.grade == paramGrade &&
                                                dataAsign.asign == paramAsign &&
                                                dataAsign.check == true)
                                        ) {
                                            dataAsign.groups = newTempGroups;
                                            swal("Actualizaste la asignatura correctamente")
                                        }
                                    })

                                    newTempGroups.forEach(dataNewTemp => {
                                        if (dataNewTemp.check) {
                                            let newData = dataNewTemp.asign + " " + dataNewTemp.groupsLetter + " " + dataNewTemp.value
                                            self.listTeach.forEach(dataList => {
                                                if (dataList.id == self.editTeach.id && dataList.sData.split(newData).length == 1) {
                                                    dataList.grupos.push(newData)
                                                    dataList.sData += newData + ", "
                                                }
                                            })
                                        }
                                    })

                                }
                            }
                        }
                    })
                } else {
                    this.asignEdits.forEach(dataAsign => {
                        if (!asign) {
                            swal({
                                title: "Atención",
                                text: "Por favor ingrese una materia, un grado y un curso",
                                icon: "warning"
                            })
                        } else {
                            if ((dataAsign.asign == paramAsign && dataAsign.grade == paramGrade) ||
                                (dataAsign.asign == asign.value && dataAsign.grade == this.editGrade)) {
                                validate = true;
                            }
                            if (
                                dataAsign.asign == paramAsign &&
                                dataAsign.groupsLetter == paramGroup
                            ) {
                                dataAsign.edit = false;
                            }
                        }
                    })
                    if (validate == false) {
                        if (newTempGroups.length > 0) {
                            if (array == "select") {
                                this.asignSelect.push(objectAsign)
                            } else {
                                let newData = [];
                                for (var variable in objectAsign) {
                                    for (var data in objectAsign.groups) {
                                        if (objectAsign.groups[data].check) {
                                            newData.push(
                                                objectAsign.asign +
                                                " " +
                                                objectAsign.groupsLetter +
                                                " " +
                                                objectAsign.groups[data].value
                                            )
                                        }
                                    }
                                    break;
                                }
                                self.listTeach.forEach(dataList => {
                                    if (dataList.id == self.editTeach.id) {
                                        newData.forEach(dataNew => {
                                            dataList.preCheck = false;
                                            dataList.grupos.push(dataNew)
                                            dataList.sData += dataNew + ", "
                                        })
                                    }
                                })
                                this.asignEdits.push(objectAsign)

                                self.deleteArrayEdits.forEach((dataDelete, index) => {
                                    if (dataDelete.asign == objectAsign.asign && dataDelete.grade == objectAsign.grade) {
                                        dataDelete.asign = null
                                        dataDelete.grade = null
                                        self.deleteArrayEdits.slice(index, 1)
                                    }
                                })
                            }
                        } else {
                            swal(
                                "Por favor ingrese la asignatura, grado y los cursos que desea agregar a este profesor"
                            )
                        }
                    } else {

                        if (array == "select") {
                            this.asignSelect.forEach(dataAsign => {
                                if (
                                    (dataAsign.grade == this.editGrade && dataAsign.asign == asign) ||
                                    (dataAsign.grade == paramGrade &&
                                        dataAsign.asign == paramAsign &&
                                        dataAsign.check == true)
                                ) {
                                    dataAsign.groups = newTempGroups;
                                    swal("Actualizaste la asignatura correctamente")
                                }
                            })
                        } else {
                            let tempSData = ''
                            this.asignEdits.forEach(dataAsign => {
                                if (
                                    (dataAsign.grade == this.editGrade && dataAsign.asign == asign) ||
                                    (dataAsign.grade == paramGrade &&
                                        dataAsign.asign == paramAsign &&
                                        dataAsign.check == true)
                                ) {
                                    dataAsign.groups = newTempGroups;
                                    swal("Actualizaste la asignatura correctamente")
                                }
                            })

                            newTempGroups.forEach(dataNewTemp => {
                                if (dataNewTemp.check) {
                                    let newData = dataNewTemp.asign + " " + dataNewTemp.groupsLetter + " " + dataNewTemp.value
                                    self.listTeach.forEach(dataList => {
                                        if (dataList.id == self.editTeach.id && dataList.sData.split(newData).length == 1) {
                                            dataList.grupos.push(newData)
                                            dataList.sData += newData + ", "
                                        }
                                    })
                                }
                            })

                        }
                        swal({
                            title: "Atención",
                            text: "Estimado usuario ya se ha agregado previamente los cursos pertenecientes a esta materia y grado, puede editarlo en la parte inferior.",
                            icon: "info"
                        })
                    }
                }


            } else {
                swal({
                    title: "Atención",
                    text: "Estimado usuario por favor ingrese los cursos que desea asignarles a este usuario.",
                    icon: "info"
                })
            }


        },
        // 
        cleanArray(param) {
            return param.filter(function(valor, indiceActual, arreglo) {
                let indiceAlBuscar = arreglo.indexOf(valor)
                if (indiceActual === indiceAlBuscar) {
                    return true;
                } else {
                    return false;
                }
            })
        },
        // 
        activeGroup(paramGrade, form = false, edit = false) {
            if (paramGrade == this.formGrade && form || paramGrade == this.editGrade && edit) {
                return true;
            }
        },
        // 

        // 
        closeModal() {
            let self = this
            self.listTeach.forEach(dataList => {
                if (dataList.id == self.editTeach.id) {
                    dataList.edit = false
                }
            })
            self.asignEdits = []
        },
        addEditTeach(id, nombre, usuario, clave) {
            this.editAsign = "";
            this.editGrade = "";
            let newEdit = new Object()
            let self = this;
            newEdit.id = id;
            newEdit.nombre = nombre;
            newEdit.usuario = usuario;
            newEdit.clave = clave
            newEdit.show = false
            self.editTeach = newEdit;

            let tempAsign = self.listTeach.find(dataList => {
                return dataList.id == id;
            })
            tempAsign.grupos.forEach(dataTemp => {
                let oldSub = new Object()
                dataTemp = dataTemp.replace(/\s\s/g, " ")
                let limit = (dataTemp.split(' ').length) - 2
                let separador = dataTemp.split(' ')[limit]


                oldSub.usuario = usuario
                oldSub.asign = dataTemp.split(" " + separador)[0]
                oldSub.groupsLetter = separador;
                oldSub.edit = false
                oldSub.groups = []

                self.subjects.forEach(dataSubject => {
                    if (dataSubject.check && dataSubject.value == dataTemp.split(" " + separador)[0]) {
                        oldSub.id = dataSubject.id;
                    }
                })
                oldSub.grade = Object.keys(self.coursesLetters[0]).find(
                    key => self.coursesLetters[0][key] == oldSub.groupsLetter
                )
                let data = new FormData()
                data.append("getGroups", "get")
                axios.post("./controllers/agregar-coordinador.ctrl.php", data)
                    .then(res => {
                        let objetosGroup = [];
                        res.data.forEach(dataRes => {
                            if (dataRes.grado == oldSub.grade) {
                                let newGroupe = new Object()
                                newGroupe.asign = oldSub.asign
                                newGroupe.grade = oldSub.grade
                                newGroupe.value = dataRes.grupo;
                                newGroupe.idGroup = dataRes.idGroup;
                                newGroupe.idCourse = dataRes.idCourse;
                                newGroupe.check = false;
                                self.listTeach.forEach(dataList => {
                                    dataList.sData = dataList.sData.replace(/\s\s/g, " ")
                                    cursoActivo = dataList.sData.split(", ")
                                    for (var i = 0; i < cursoActivo.length; i++) {
                                        let limit = (cursoActivo[i].split(' ').length) - 1
                                        if (limit > 0) {
                                            let separador = cursoActivo[i].split(' ')[limit]
                                            let LimitTwo = (cursoActivo[i].split(" " + separador)[0].split(' ').length) - 1
                                            let sepGroupsLetter = cursoActivo[i].split(" " + separador)[0].split(' ')[LimitTwo]
                                            let sepAsign = cursoActivo[i].split(" " + separador)[0].split(sepGroupsLetter)[0]
                                            let sepGroup = separador.split(" " + separador)[0];

                                            if (oldSub.asign + " " == sepAsign &&
                                                oldSub.groupsLetter == sepGroupsLetter &&
                                                dataRes.grupo == sepGroup &&
                                                dataList.usuario == usuario) {
                                                newGroupe.check = true;
                                            }
                                        }
                                    }
                                })
                                objetosGroup.push(newGroupe)
                            }

                        })

                        objetosGroup.forEach(dataObjeto => {
                            self.letters.forEach(function(data, index) {
                                if (data == dataObjeto.value) {
                                    dataObjeto.number = index + 1;
                                }
                            })

                            let validate = false;
                            oldSub.groups.forEach(dataGroupe => {
                                if (
                                    dataObjeto.asign + dataObjeto.value + dataObjeto.grade ==
                                    dataGroupe.asign + dataGroupe.value + dataGroupe.grade
                                ) {
                                    validate = true;
                                }
                            })

                            if (!validate) {
                                oldSub.groups.push(dataObjeto)
                            }
                        })


                    })

                let validate = false;

                self.asignEdits.forEach(dataAsign => {
                    if (
                        dataAsign.grade == oldSub.grade &&
                        dataAsign.asign == oldSub.asign
                    ) {
                        validate = true;
                    }
                })
                if (!validate) {

                    self.asignEdits.push(oldSub)
                }

            })
        },
        // 
        deleteAsign(asign, curso) {
            this.asignSelect.forEach(dataAsign => {
                if (dataAsign.asign == asign && dataAsign.groupsLetter == curso) {
                    dataDelete = this.asignSelect.indexOf(dataAsign)
                    this.asignSelect.splice(dataDelete, 1)
                }
            })
        },
        deleteAsignEdit(param) {
            let self = this;
            swal({
                text: "Estimado usuario recuerda que al editar o eliminar las asociasiones de los cursos de este profesor no se podrá recuperar la información. \n ¿Quieres continuar?",
                icon: "warning",
                buttons: ['Cancelar', 'Continuar']
            }).then((res) => {
                if (res) {
                    const tempAsignatureMe = self.listTeach.find(item => {
                        return item.id == self.editTeach.id;
                    })
                    this.asignEdits.forEach(dataAsign => {
                        if (
                            dataAsign.asign == param.asign &&
                            dataAsign.groupsLetter == param.groupsLetter
                        ) {
                            self.deleteArrayEdits.push(param)
                            dataDelete = this.asignEdits.indexOf(dataAsign)
                            this.asignEdits.splice(dataDelete, 1)
                        }
                    })
                    tempAsignatureMe.preCheck = false;
                }
            })

        },
        // 
        listenToInput() {
            let self = this
            let inputExcel = document.querySelector('#fileExcel')
            let inputButtom = document.querySelector('.clButtonInputFIle')
            let imgProgress = document.querySelector('#imgProgress')
            inputExcel.addEventListener('change', (event) => {
                inputButtom.setAttribute('hidden', '')
                imgProgress.removeAttribute('hidden')
                    //Validate whether File is valid Excel file.
                if (typeof(FileReader) != "undefined") {
                    var reader = new FileReader();
                    //For Browsers other than IE.
                    if (reader.readAsBinaryString) {
                        reader.onload = function(e) {
                            self.ProcessExcel(e.target.result);
                        };
                        reader.readAsBinaryString(inputExcel.files[0]);
                    } else {
                        //For IE Browser.
                        reader.onload = function(e) {
                            var data = "";
                            var bytes = new Uint8Array(e.target.result);
                            for (var i = 0; i < bytes.byteLength; i++) {
                                data += String.fromCharCode(bytes[i]);
                            }
                            self.ProcessExcel(data);
                        };
                        reader.readAsArrayBuffer(inputExcel.files[0]);

                    }
                } else {
                    alert("This browser does not support HTML5.");
                }
            });
        },
        validateDuplicateExcel() {
            let self = this
            this.dataImport.forEach(valExcel => {
                let duplicate = 0
                self.dataImport.forEach(key => {
                    if (key.Correo == valExcel.Correo) {
                        duplicate++
                    }
                })
                if (!valExcel.Celular || self.isNumber(valExcel.Celular)) {
                    valExcel.numberLength = true
                } else {
                    valExcel.numberLength = false

                }
                if (duplicate > 1) {
                    valExcel.duplicateEmail = true
                } else {
                    valExcel.duplicateEmail = false
                }
                if (valExcel.Correo != undefined) {
                    if (!valExcel.Correo.split('@')[1] || !valExcel.Correo.split('.')[1]) {
                        valExcel.duplicateEmail = true
                    }
                }
            })
        },
        ProcessExcel(data) {
            let inputExcel = document.querySelector('#fileExcel')
            let inputButtom = document.querySelector('.clButtonInputFIle')
            let self = this
            let imgProgress = document.querySelector('#imgProgress')
            var workbook = XLSX.read(data, {
                type: 'binary'
            });
            var firstSheet = workbook.SheetNames[0];
            var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[firstSheet]);
            let contador = 1
            let validInfo = 0
            excelRows.forEach(dataExcel => {
                if (dataExcel.Nombres && dataExcel.Apellidos) {
                    validInfo++
                }
                dataExcel.id = contador
                dataExcel.asign = ''
                dataExcel.grade = ''
                dataExcel.groupes = []
                dataExcel.selects = []
                dataExcel.duplicateEmail = false
                dataExcel.numberLength = false
                contador++
            })
            excelRows.forEach(valExcel => {
                let duplicate = 0
                valExcel.changeEmail
                valExcel.changeMovil
                excelRows.forEach(key => {
                    if (key.Correo == valExcel.Correo) {
                        duplicate++
                    }
                })
                if (!valExcel.Celular || self.isNumber(valExcel.Celular)) {
                    valExcel.numberLength = true
                }
                if (duplicate > 1) {
                    valExcel.duplicateEmail = true
                }

                if (valExcel.Correo != undefined) {
                    if (!valExcel.Correo.split('@')[1] || !valExcel.Correo.split('.')[1]) {
                        valExcel.duplicateEmail = true
                    }
                }
            })

            this.dataImport = excelRows

            imgProgress.setAttribute('hidden', '')
            inputButtom.removeAttribute('hidden')

            inputExcel.value = null;
            if (validInfo == 0) {
                let span = document.createElement("div")
                span.className = "container_name"
                span.innerHTML = "El archivo escogido no tiene el formato requerido.<br> Por favor escoga un archivo compatible."
                swal({
                    title: 'Atención',
                    content: span,
                    icon: 'warning'
                })
                this.dataImport = []
            }


        },
        getGroupesImport(item) {
            item.groupes = []
            let self = this
            let asign = self.subjects.find(dataSubject => {
                return dataSubject.id == item.asign
            })
            asignName = asign.value;
            let data = new FormData()
            data.append("getGroups", "get")
            axios.post("./controllers/agregar-coordinador.ctrl.php", data).then(res => {
                let objetosGroup = [];
                res.data.forEach(dataRes => {
                    if (dataRes.grado == item.grade) {
                        let newGroupe = new Object()
                        newGroupe.idAsign = item.asign
                        newGroupe.asign = asign.value
                        newGroupe.grade = item.grade
                        newGroupe.value = dataRes.grupo
                        newGroupe.idGroup = dataRes.idGroup
                        newGroupe.idCourse = dataRes.idCourse
                        newGroupe.check = false;

                        let gradeName = "";
                        self.coursesLetters.forEach(dataCourse => {
                            for (data in dataCourse) {
                                if (data == item.grade) {
                                    gradeName = dataCourse[data];
                                }
                            }
                        })
                        objetosGroup.push(newGroupe)
                    }
                })

                objetosGroup.forEach(dataObjeto => {
                    self.letters.forEach(function(data, index) {
                        if (data == dataObjeto.value) {
                            dataObjeto.number = index + 1;
                        }
                    })
                    self.dataImport.forEach(key => {
                        if (key.id == item.id) {
                            key.groupes.push(dataObjeto)
                        }
                    })
                })
            })

        },
        addAsignImport(item) {
            let objectAsign = new Object()
            let self = this;
            let asign = self.subjects.find(dataSubject => {
                return dataSubject.id == item.asign;
            })
            for (const key in self.coursesLetters[0]) {
                if (key == item.grade) {
                    item.gradeLetter = self.coursesLetters[0][key]
                    break
                }
            }
            if (item.gradeLetter) {
                item.groupes.forEach(dataGroupes => {
                    if (dataGroupes.check) {

                        let newCourse = new Object
                        newCourse.asign = dataGroupes.asign
                        newCourse.grade = item.grade
                        newCourse.groupsLetter = item.gradeLetter
                        newCourse.groups = item.groupes
                        newCourse.edit = false
                        let validate = false

                        item.selects.forEach(dataSelects => {
                            if (dataSelects.asign == dataGroupes.asign && dataSelects.grade == dataGroupes.grade) {
                                validate = true
                            }
                        })

                        if (!validate) {
                            item.selects.push(newCourse)
                        }

                    }
                })
            }

        },
        deleteSelects(index) {
            let self = this
            let inputExcel = document.querySelector('#fileExcel')
            let inputButtom = document.querySelector('.clButtonInputFIle')
            swal({
                    allowOutsideClick: "true",



                    title: "Atención",
                    text: "¿Desea descartar el usuario de este coordinador?",
                    icon: "warning",
                    buttons: ["Cancelar", "Sí, deseo descartar el usuario"],
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        swal({
                            allowOutsideClick: "true",



                            title: "Correcto",
                            text: "Has descartado este usuario",
                            icon: "success",
                        });
                        this.dataImport.splice(index, 1)
                        let duplicateInfo = self.dataImport.filter(dataFind => { return (dataFind.duplicateEmail || dataFind.numberLength) && (dataFind.Apellidos != null && dataFind.Nombres) })
                        if (duplicateInfo.length == 0) {
                            self.dataImport = []
                        }
                    } else {
                        swal({
                            allowOutsideClick: "true",
                            title: "Correcto",
                            text: "Aún no has descartado el usuario",
                            icon: "success"
                        });
                    }
                });

        },
        addImportInd(item, index) {
            let btnEdit = document.querySelector('.clBtnUser' + index)
            let imageProgress = document.querySelector('#progress' + index)
            let self = this
            btnEdit.setAttribute('hidden', '')
            imageProgress.removeAttribute('hidden')
            let data = new FormData
            data.append('setUsersAsign', 'set')
            data.append('setName', item.Nombres)
            data.append('setLastName', item.Apellidos)
            data.append('setEmail', item.Correo)
            data.append('setDuplicate', item.duplicateEmail)
            data.append('setNumberLength', item.numberLength)
            data.append('setType', 'coordinador')
            data.append('setMovil', item.Celular)
            data.append('setCourses', JSON.stringify(item.selects))
            axios.post('controllers/importar-usuarios.ctrl.php', data)
                .then(res => {
                    if (res.data == 'complete') {
                        btnEdit.removeAttribute('hidden')
                        imageProgress.setAttribute('hidden', '')
                        swal({
                            allowOutsideClick: "true",


                            title: "Correcto",
                            text: "Has creado al coordinador " + item.Nombres + " " + item.Apellidos,
                            icon: "success",
                        });
                        let duplicateInfo = self.dataImport.filter(dataFind => { return (dataFind.duplicateEmail || dataFind.numberLength) && (dataFind.Apellidos != null && dataFind.Nombres) })
                        if (duplicateInfo.length == 0 && self.dataImport.length <= 2) {
                            self.dataImport = []
                        }
                        self.dataImport.splice(index, 1)
                        self.getTeachs()
                    }

                })
                .catch(err => {
                    console.error(err);
                })
        },
        cleanImport() {
            let self = this
            this.dataImport.forEach(dataData => {
                if (dataData.duplicateEmail == false && dataData.numberLength == false) {
                    dataData.Nombres = null
                    dataData.Correo = null
                    dataData.Apellidos = null
                }
            })

        },
        addImportAll() {
            let intro = introJs()
            intro.exit('tab1')
            intro.exit('tab2')
            intro.exit('tab3')
            this.validateDuplicateExcel()
            let imgProgress = document.querySelector('#allImgProgress')
            let btnImportAll = document.querySelector('#importAll')
            imgProgress.removeAttribute('hidden')
            btnImportAll.setAttribute('hidden', '')
            let contador = 0
            let self = this
            this.dataImport.forEach(function(values, index, array) {
                let data = new FormData()
                data.append('setUsersAsign', 'set')
                data.append('setName', values.Nombres)
                data.append('setLastName', values.Apellidos)
                data.append('setEmail', values.Correo)
                data.append('setType', 'coordinador')
                data.append('setDuplicate', values.duplicateEmail)
                data.append('setNumberLength', values.numberLength)
                data.append('setMovil', values.Celular)
                data.append('setCourses', JSON.stringify(values.selects))
                axios.post('controllers/importar-usuarios.ctrl.php', data)
                    .then(res => {
                        if (res) {
                            contador++
                        }
                        if (contador === self.dataImport.length) {
                            let duplicateInfo = self.dataImport.filter(dataFind => { return (dataFind.duplicateEmail || dataFind.numberLength) && (dataFind.Apellidos != null && dataFind.Nombres) })
                            if (duplicateInfo.length == 0) {
                                swal({
                                    allowOutsideClick: "true",
                                    title: "Correcto",
                                    text: "Los docentes se crearon satisfactoriamente.",
                                    icon: "success",
                                });
                            } else {
                                swal({
                                    allowOutsideClick: "true",
                                    title: "Atención",
                                    text: "Aún hay docentes por crear. Sin embargo los que tenían la información correcta han sido creados.",
                                    icon: "warning",
                                });
                            }
                            let intro = introJs()
                            btnImportAll.removeAttribute('hidden')
                            imgProgress.setAttribute('hidden', '')
                            self.getTeachs()
                            self.cleanImport()
                            if (duplicateInfo.length == 0) {
                                self.dataImport = []
                            }

                        }
                    })

            })
        },
        deleteAsignImport(data, item) {
            item.selects.forEach(dataSelect => {
                if (dataSelect.asign == data.asign && dataSelect.grade == data.grade) {
                    dataDelete = item.selects.indexOf(dataSelect)
                    item.selects.splice(dataDelete, 1)
                    let duplicateInfo = self.dataImport.filter(dataFind => { return (dataFind.duplicateEmail || dataFind.numberLength) && (dataFind.Apellidos != null && dataFind.Nombres) })

                    if (duplicateInfo.length == 0) {
                        self.dataImport = []
                    }
                }
            })

        },
        changeEmail(res) {
            if (!res.changeEmail || res.changeEmail.indexOf('@') == -1 || res.changeEmail.indexOf('.') == -1) {
                swal("¡Atención!", "Ingresa un correo valido", "warning")
            } else {
                res.Correo = res.changeEmail
                this.validateDuplicateExcel()
            }
        },
        changeMovil(res) {
            if (!res.changeMovil || (res.changeMovil == undefined) || !(res.changeMovil.length <= 10) || !res.changeMovil || !(res.changeMovil.length > 7) || !res.changeMovil > 2000000 || res.changeMovil.split('E').length > 1 || res.changeMovil.split('.').length > 1 || res.changeMovil.split('+').length > 1) {
                swal("¡Atención!", "Ingresa un celular valido", "warning")
            } else {
                res.Celular = res.changeMovil
                this.validateDuplicateExcel()
            }
        },
        isNumber(param) {
            if (param) {
                if (!(param.length <= 10) || !(param.length >= 7) || !(param > 2000000) || param.split('E').length > 1 || param.split('.').length > 1 || param.split('+').length > 1) {
                    return true
                } else {
                    return false
                }
            }

        },
        downUsers() {
            let self = this
            self.fileLoad = true
            setTimeout(() => {
                self.fileLoad = false
                self.getProgress()
                if (self.progresoUsuario == 1) {
                    window.location = './index.php?module=informacion-general'
                } else {
                    let intro = introJs();
                    intro.exit("tab3")
                }
            }, 1000)
        }
    }

})