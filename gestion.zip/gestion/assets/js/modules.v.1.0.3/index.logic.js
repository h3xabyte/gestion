const home = new Vue({
    el: "#module-index",
    data: {

    },
    created() {},
    mounted() {

    },
    methods: {

    }
})