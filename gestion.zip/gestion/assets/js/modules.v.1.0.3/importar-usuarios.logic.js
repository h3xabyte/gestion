let importUsers = new Vue({
    el: "#module-importar-usuarios",
    data: {
        dataImport: [],
        formAsign: '',
        formGrade: '',
        subjects: [],
        grades: [],
        groupes: []
    },
    mounted() {
        this.getSubjects(),
            this.getGrades(),
            this.listenToInput()
    },
    created() {

    },
    methods: {
        listenToInput() {
            let self = this
            let inputExcel = document.querySelector('#fileExcel')
            let imgProgress = document.querySelector('#imgProgress')
            inputExcel.addEventListener('change', (event) => {
                inputExcel.setAttribute('hidden', '')
                imgProgress.removeAttribute('hidden')
                    //Validate whether File is valid Excel file.
                if (typeof(FileReader) != "undefined") {
                    var reader = new FileReader();
                    //For Browsers other than IE.
                    if (reader.readAsBinaryString) {
                        reader.onload = function(e) {
                            self.ProcessExcel(e.target.result);
                        };
                        reader.readAsBinaryString(inputExcel.files[0]);
                    } else {
                        //For IE Browser.
                        reader.onload = function(e) {
                            var data = "";
                            var bytes = new Uint8Array(e.target.result);
                            for (var i = 0; i < bytes.byteLength; i++) {
                                data += String.fromCharCode(bytes[i]);
                            }
                            self.ProcessExcel(data);
                        };
                        reader.readAsArrayBuffer(inputExcel.files[0]);

                    }
                } else {
                    alert("This browser does not support HTML5.");
                }
            });
        },
        ProcessExcel(data) {
            let inputExcel = document.querySelector('#fileExcel')
            let imgProgress = document.querySelector('#imgProgress')
            var workbook = XLSX.read(data, {
                type: 'binary'
            });
            var firstSheet = workbook.SheetNames[0];
            var excelRows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[firstSheet]);
            this.dataImport = excelRows


            imgProgress.setAttribute('hidden', '')
            inputExcel.removeAttribute('hidden')
        },
        getGroupes() {
            let self = this;
            let asign = self.subjects.find(dataSubject => {
                return dataSubject.id == self.formAsign;
            })
            asignName = asign.value;
            let data = new FormData()
            data.append("getGroups", "get")
            axios.post("./controllers/carga-academica.ctrl.php", data).then(res => {
                let objetosGroup = [];
                res.data.forEach(dataRes => {
                    if (dataRes.grado == this.formGrade) {
                        let newGroupe = new Object()
                        newGroupe.asign = asign.value;
                        newGroupe.grade = this.formGrade;
                        newGroupe.value = dataRes.grupo;
                        newGroupe.idGroup = dataRes.idGroup;
                        newGroupe.idCourse = dataRes.idCourse;
                        newGroupe.check = false;

                        let gradeName = "";

                        app.coursesLetters.forEach(dataCourse => {
                            for (data in dataCourse) {
                                if (data == this.formGrade) {
                                    gradeName = dataCourse[data];
                                }
                            }
                        })
                        objetosGroup.push(newGroupe)
                    }
                })

                objetosGroup.forEach(dataObjeto => {
                    app.letters.forEach(function(data, index) {
                        if (data == dataObjeto.value) {
                            dataObjeto.number = index + 1;
                        }
                    })

                    let validate = false;
                    self.groupesEdit.forEach(dataGroupe => {
                        if (
                            dataObjeto.asign + dataObjeto.value + dataObjeto.grade ==
                            dataGroupe.asign + dataGroupe.value + dataGroupe.grade
                        ) {
                            validate = true;
                        }
                    })

                    self.groupes.forEach(dataGroupe => {
                        if (
                            dataObjeto.asign + dataObjeto.value + dataObjeto.grade ==
                            dataGroupe.asign + dataGroupe.value + dataGroupe.grade
                        ) {
                            validate = true;
                        }
                    })


                    if (!validate) {
                        self.groupes.push(dataObjeto)
                    }


                })
            })

        },
        getGrades() {
            let self = this;
            let data = new FormData()
            data.append("getGroups", "get")
            axios
                .post("./controllers/carga-academica.ctrl.php", data)
                .then(res => {
                    let temp = [];
                    let arrData = [];

                    res.data.forEach(dataRes => {
                        arrData.push(dataRes)
                        temp.push(dataRes.grado)
                    })

                    self.tempGroup = arrData;

                    temp = temp.filter(function(valor, indiceActual, arreglo) {
                        let indiceAlBuscar = arreglo.indexOf(valor)
                        if (indiceActual === indiceAlBuscar) {
                            return true;
                        } else {
                            return false;
                        }
                    })

                    temp.forEach(dataTemp => {
                        app.coursesLetters.forEach(dataCourse => {
                            let objetoGrupo = new Object()
                            objetoGrupo.number = dataTemp;
                            objetoGrupo.letter = dataCourse[dataTemp];
                            self.grades.push(objetoGrupo)
                        })
                    })
                })
                .catch(err => {
                    console.error(err)
                })
        },
        getSubjects() {
            let self = this;
            let data = new FormData()
            data.append("getSubject", "get")
            axios
                .post("./controllers/carga-academica.ctrl.php", data)
                .then(res => {
                    let validateSubject = [];
                    for (value in res.data) {
                        self.subjects.forEach(dataSubject => {
                            if (res.data[value].nombre == dataSubject.value) {
                                dataSubject.id = res.data[value].id;
                                dataSubject.check = true;
                                dataSubject.preCheck = true;
                            } else {
                                validateSubject.push(res.data[value])
                            }
                        })
                    }

                    validateSubject = validateSubject.filter(function(
                        valor,
                        indiceActual,
                        arreglo
                    ) {
                        let indiceAlBuscar = arreglo.indexOf(valor)
                        if (indiceActual === indiceAlBuscar) {
                            return true;
                        } else {
                            return false;
                        }
                    })

                    validateSubject.forEach(dataValidate => {
                        let validate = false;
                        self.subjects.forEach(dataSubject => {
                            if (dataSubject.value == dataValidate.nombre) {
                                validate = true;
                            }
                        })

                        if (validate == false) {
                            let newSubject = new Object()
                            newSubject.id = dataValidate.id;
                            newSubject.value = dataValidate.nombre;
                            newSubject.check = true;
                            newSubject.preCheck = true;
                            newSubject.newValue = "";
                            newSubject.edit = false;
                            self.subjects.push(newSubject)
                        }
                    })
                })
                .catch(err => {
                    console.error(err)
                })
        },
    }

})