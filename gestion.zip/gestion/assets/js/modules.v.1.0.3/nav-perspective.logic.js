let navPerspective = new Vue({
    el: "#navPerspective",
    data: {
        imageEscudo: []
    },
    methods: {
        getImage() {
            let self = this
            let data = new FormData()
            data.append('getImageShield', 'get')
            axios.post('./controllers/gestionar-imagenes.ctrl.php', data)
                .then(res => {
                    res.data.forEach(dataRes => {
                        if (dataRes.clase == 'shield') {
                            self.imageEscudo = dataRes
                        }
                    })
                })
                .catch(err => {
                    console.error(err);
                })
        }
    },
    created() {
        this.getImage
    }
})