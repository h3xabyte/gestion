<?php
$BASE_DN = "dc=educar,dc=com";
$LDAP_URI = "ldap://192.168.79.76";
$DN_ADM = "cn=admin,$BASE_DN";
$PASS_ADM = "FP7nkyvIlPP9gclwxS3n";
$BASE_BUSQ_ADM ="cn=Administradores,$BASE_DN";

$DB_HOST = "educar2020db.c6r9vkodxz44.us-east-1.rds.amazonaws.com";//"educar2015db.c6r9vkodxz44.us-east-1.rds.amazonaws.com";
$DB_USER = "sie";
$DB_PASS = "3tCaxMU3ZLK8DwIU";
$DB_DB = "global_sie";

$USER_CONSULTA = 'consultainformes';
$PASS_CONSULTA = 'SZ9veCrNVLp4dMf8';

$USER_RECOLECTOR = 'recolectores';
$PASS_RECOLECTOR = 'wBlhmdM1nmTjf7oN';
$DB_RECOLECTOR = 'recolectores';

$USER_NOTIFICACIONES = 'envionotificaciones';
$PASS_NOTIFICACIONES = 'E0y2kGOGFmd9LoDF';

$USER_EDUCAR_VIRTUAL = 'educarvirtualsie';
$PASS_EDUCAR_VIRTUAL = 'p5GOOOquFNDyFO9r';
$DB_EDUCAR_VIRTUAL = 'mdl_ev';
$DB_DIARIO_LECTURA = 'appdiariolectura';

$SIE_PREFIX = "/var/www/";

$ADODB_PATH = $SIE_PREFIX."virtual/lib/adodb/";
$ADODB_TYPE = "mysqli";

$PORTADAS_DIR = $SIE_PREFIX."Front/images/portadas/";
$PORTADAS_URL = "//sie.educar.com.co/images/portadas/";

$LOGOS_DIR = $SIE_PREFIX."Front/images/logos/";
$LOGOS_URL = "//sie.educar.com.co/images/logos/";

$BOTONES_URL = "//sie.educar.com.co/images/botones/";

// REFERENCE BUG 1
$CHML_CONFIG = $SIE_PREFIX."mi_aula_2020/LMS/app/config/configuration.php";
$MDL_CONFIG = $SIE_PREFIX."virtual/config.php";
$MDL_DB = $SIE_PREFIX."virtual/lib/dml/moodle_database.php";
$MDL_SABER_CONFIG = $SIE_PREFIX."PruebasSaber/config.php";
$MDL_SABER_DB = $SIE_PREFIX."PruebasSaber/lib/dml/moodle_database.php";
$DRPL_CONFIG = $SIE_PREFIX."planlector/sites/default/settings.php";
$DRPL_GALERIA_CONFIG = $SIE_PREFIX."Galeria/sites/default/settings.php";
$DRPL_GALERIA_PRESCHOOL_CONFIG = $SIE_PREFIX."GaleriaPreschool/sites/default/settings.php";
$DRPL_BIBLIOTECA_CONFIG = $SIE_PREFIX."planlector/sites/default/settings.php";
$DRPL_AUTOR_CONFIG = $SIE_PREFIX."DrpAutor/sites/default/settings.php";
$DRPL_CONSULTOR_CONFIG = $SIE_PREFIX."Consultor/sites/default/settings.php";

$CHML_COUR = $SIE_PREFIX."LMS_1_11_2/LMS/app/courses/";
$CHML_COUR_MODEL = "CURSOBASE";

$CUOTA_LMS_CURSO = 536870912;

$BTN_planlector = 'btn-plan-lector-new.png';
$BTN_planlector_plus = 'digital_plus.png';
$BTN_planlector_EDUCLASS = 'btn-plan-lector-educlass2017.png';
$BTN_galeria = 'btn-galeria-objetos-new.png';
$BTN_galeria_EDUCLASS = 'btn-educar-virtual-educlass2017.png';
$BTN_meli = 'btn-meli-PI.png';
$BTN_pruebas = 'btn-pruebas-saber-new.png';
$BTN_pruebas_EDUCLASS = 'btn-pruebas-saber-educlass2017.png';
$BTN_lms = 'btn-lms-new.png';
$BTN_lms_EDUCLASS = 'btn-lms-educlass2017.png';
$BTN_zrecursos = 'btn-zrecursos.png';
$BTN_zlectura = 'btn-zlectura.png';
$BTN_zcomunicativa = 'btn-zcomunicativa.png';
$BTN_consultor = 'btn_consultor.png';
$BTN_comunidad = 'btn_comunidad.png';
$BTN_creador = 'btn_constructor.png';
$BTN_digitales = 'digital_books.png';
$BTN_digitales_EDUCLASS = 'digital_books_educlass.png';
$BTN_nuevo_saber = "btn-nuevo-saber.png";

$BTN_zaprendizaje_aprende = 'btn_aprende_aprendizaje.png';
$BTN_zlectura_aprende = 'btn_aprende_lectura.png';

$BTN_saber_3 = 'btn-saber-3.png';
$BTN_saber_5 = 'btn-saber-5.png';
$BTN_saber_7 = 'btn-saber-7.png';
$BTN_saber_9 = 'btn-saber-9.png';
$BTN_saber_11 = 'btn-saber-11.png';

$CAT_GALERIA = 2;
$CAT_COMPRENDE = 12;
$CAT_EDUCLASS = 11;
$CAT_MELI = 3;
$CAT_PSABER = 1;
$CAT_PRESCHOOL = 7;
$CAT_NUEVO_SABER = 4;

$ID_SABER_3 = 20;
$ID_SABER_5 = 19;
$ID_SABER_7 = 86;
$ID_SABER_9 = 6;
$ID_SABER_11 = 3;

$ROL_PROFE_MDL = 'profesor';

$AÑO_ACTIVO = 2020;

$smtp_params = array();

/*$smtp_params['host'] = 'email-smtp.us-east-1.amazonaws.com';
$smtp_params["auth"] = "tls";
$smtp_params["username"] = 'AKIAIXMISX22OPRBLVUQ';
$smtp_params["password"] = 'Are8pvYZEqktZAjLX7tnL59kB+Dv5i+XDrvYzysolicitudesit@educar.com.cogXNgAU';*/
/*$smtp_params["username"] = 'sie';
$smtp_params["password"] = '&T4g1bL#8!j3zz$';*/

$smtp_params['host'] = 'mail.educar.com.co';
$smtp_params['port'] = '465';
$smtp_params["auth"] = "ssl";
$smtp_params["username"] = 'notificaciones';
$smtp_params["password"] = 'Notificaciones.2019*';

?>
