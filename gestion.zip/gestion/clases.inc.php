<?php
require 'config.inc.php';
include('adodb/adodb.inc.php');

//require '/var/www/Front/PHPSessions.php';
session_start();

$BaseD = NewADOConnection($ADODB_TYPE);
$BaseD->debug = false;
$BaseD->Connect($DB_HOST, $DB_USER, $DB_PASS, $DB_DB);
$BaseD->SetCharSet('utf8');

if (isset($_SESSION['phpCAS']) && isset($_SESSION['phpCAS']['user'])) {
    $user = $_SESSION['phpCAS']['user'];
}

class Institucion
{
    protected $nombre;
    protected $id;
    protected $ciudad;
    protected $web;
    protected $es_antigua;
    protected $calendario;
    protected $cod_icfes;
    protected $cod_dane;
    protected $nit;
    protected $pais;
    protected $departamento;
    protected $municipio;
    protected $coordinador;
    protected $correo;

    function __construct($params)
    {
        global $DB_HOST, $DB_USER, $DB_PASS, $DB_DB, $ADODB_TYPE;

        if (!isset($DB_HOST)) {
            include 'config.inc.php';
        }
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($DB_HOST, $DB_USER, $DB_PASS, $DB_DB);
        $BaseD->SetCharSet('utf8');
        $BaseD->debug = false;

        if (is_numeric($params)) {
            $res = $BaseD->Execute("SELECT nombre, ciudad, web, correo, DATEDIFF(NOW(), fecha_creacion) diferencia, calendario, cod_icfes, cod_dane, nit, pais, departamento, municipio, coordinador FROM instituciones WHERE id = ?", array($params));
            if ($res->RecordCount() > 0) {
                $this->id = $params;
                $this->nombre = $res->fields['nombre'];
                $this->ciudad = $res->fields['ciudad'];
                $this->web = $res->fields['web'];
                $this->correo = $res->fields['correo'];
                $this->es_antigua = ($res->fields['diferencia'] <= 180 ? false : true);
                $this->calendario = $res->fields['calendario'];
                $this->cod_icfes = $res->fields['cod_icfes'];
                $this->cod_dane = $res->fields['cod_dane'];
                $this->nit = $res->fields['nit'];
                $this->pais = $res->fields['pais'];
                $this->departamento = $res->fields['departamento'];
                $this->municipio = $res->fields['municipio'];
                $this->coordinador = $res->fields['coordinador'];
            } else {
                $this->nombre = null;
            }
        } elseif (is_array($params)) {
            $nombre = $params[0];
            $ciudad = $params[1];

            //$BaseD->debug = true;

            if ($BaseD->Execute("INSERT INTO instituciones (nombre, ciudad, web, creado_por, id_plataforma, calendario) VALUES (?, ?, ?, ?, ?, ?)", array($nombre, $ciudad, $params[2], $params[3], $params[4], $params[5])) === false) {
                $this->nombre = "";
            } else {
                $this->id = $BaseD->Insert_ID();
                $this->nombre = $params[0];
                $this->ciudad = $params[1];
                $this->es_antigua = false;
                $this->crear_categoria_lms();
            }
            //$BaseD->debug = false;
        }
    }

    function cambiar_coordinador($coordinador, $institucion){
        global $BaseD;
        $sql = $BaseD->Execute("UPDATE instituciones SET coordinador= ? WHERE id = ?", array($coordinador, $institucion));
        if($sql){
            return true;
        }else{
            return false;
        }
    }

    function eliminar_institucion()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $BaseD;

        registro(__METHOD__, func_get_args(), $this);
        include "$CHML_CONFIG";

        $BaseDCHML = NewADOConnection($ADODB_TYPE);
        $BaseDCHML->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseDCHML->SetCharSet('utf8');
        $this->eliminar_usuarios_x_institucion();
        $grados = $this->listar_grados();
        foreach ($grados as $idg => $g) {
            $grado = new Grado($idg);
            $cursos = $grado->listar_cursos();
            foreach ($cursos as $idc => $c) {
                $BaseD->Execute("DELETE FROM grupos_estudiantes WHERE grupo = ?", array($idc));
                $BaseD->Execute("DELETE FROM grupos_materias WHERE grupo = ?", array($idc));
                $BaseD->Execute("DELETE FROM grupos WHERE id = ?", array($idc));
            }
            $BaseD->Execute("DELETE FROM pines WHERE curso = ?", array($idg));
            $BaseD->Execute("DELETE FROM cursos WHERE id = ?", array($idg));
        }
        $BaseD->Execute("DELETE FROM materias WHERE institucion = ?", array($this->id));
        $BaseDCHML->Execute("UPDATE course SET visibility = 4 WHERE category_code = ?", array($this->id));
        $res1 = $BaseD->Execute("SELECT id FROM p_planeaciones WHERE institucion = ?", array($this->id));
        while (!$res1->EOF) {
            $BaseD->Execute("DELETE FROM p_posiciones WHERE planeacion = ?", array($res1->fields['id']));
            $res2 = $BaseD->Execute("SELECT id FROM p_periodos WHERE planeacion = ?", array($res1->fields['id']));
            while (!$res2->EOF) {
                $res3 = $BaseD->Execute("SELECT id FROM p_campos WHERE periodo = ?", array($res2->fields['id']));
                while (!$res3->EOF) {
                    $BaseD->Execute("DELETE FROM p_recursos WHERE campo = ?", array($res3->fields['id']));
                    $res3->MoveNext();
                }
                $BaseD->Execute("DELETE FROM p_campos WHERE periodo = ?", array($res2->fields['id']));
                $BaseD->Execute("DELETE FROM p_periodos_contenidos WHERE periodo = ?", array($res2->fields['id']));
                $BaseD->Execute("DELETE FROM p_periodos_dbas WHERE periodo = ?", array($res2->fields['id']));
                $BaseD->Execute("DELETE FROM p_periodos_estandares WHERE periodo = ?", array($res2->fields['id']));
                $BaseD->Execute("DELETE FROM p_periodos_evidencias WHERE periodo = ?", array($res2->fields['id']));
                $BaseD->Execute("DELETE FROM p_periodos_subprocesos WHERE periodo = ?", array($res2->fields['id']));
                $res2->MoveNext();
            }
            $BaseD->Execute("DELETE FROM p_periodos WHERE planeacion = ?", array($res1->fields['id']));
            $BaseD->Execute("DELETE FROM p_planeaciones_materias WHERE planeacion = ?", array($res1->fields['id']));
            $res1->MoveNext();
        }
        $BaseD->Execute("DELETE FROM p_planeaciones WHERE institucion = ?", array($this->id));
        $BaseD->Execute("DELETE FROM instituciones_libros WHERE institucion = ?", array($this->id));
        $BaseD->Execute("DELETE FROM permisos_libros WHERE institucion = ?", array($this->id));
        if ($BaseD->Execute("DELETE FROM instituciones WHERE id = ?", array($this->id))) {
            return (true);
        } else {
            return (false);
        }
    }

    function eliminar_usuarios_x_institucion()
    {
        registro(__METHOD__, func_get_args(), $this);
        $profes = $this->listar_profesores(false);
        $coordinadores = $this->listar_coordinadores(false);
        $estudiantes = $this->listar_estudiantes(false);
        $yo = new Usuario();

        if (is_array($estudiantes)) {
            foreach ($estudiantes as $estudiante) {
                $yo->borrar($estudiante["usuario"]);
            }
        }

        if (is_array($profes)) {
            foreach ($profes as $profe) {
                $yo->borrar($profe["usuario"]);
            }
        }

        if (is_array($coordinadores)) {
            foreach ($coordinadores as $profe) {
                $yo->borrar($profe["usuario"]);
            }
        }
    }

    function crear_categoria_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_CSS;

        registro(__METHOD__, func_get_args(), $this);
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        $BaseD->Execute("INSERT INTO course_category (id, name, code, tree_pos, children_count, auth_course_child, auth_cat_child) VALUES (?, ?, ?, ?, ?, ?, ?)", array($this->id, $this->nombre . " / " . $this->ciudad, $this->id, $this->id, 0, "TRUE", "TRUE"));
        $BaseD->Execute("INSERT INTO access_url_rel_course_category (access_url_id, course_category_id) VALUES (?, ?)", array(1, $this->id));
        $BaseD->Close();
    }

    function nombre($html = false)
    {
        return ($html ? $this->nombre : addslashes($this->nombre));
    }

    function ciudad()
    {

        return $this->ciudad;
    }

    function id()
    {
        return $this->id;
    }

    function calendario()
    {
        return $this->calendario;
    }

    function codigo_icfes()
    {
        return $this->cod_icfes;
    }

    function codigo_dane()
    {
        return $this->cod_dane;
    }

    function nit()
    {
        return $this->nit;
    }

    function pais()
    {
        return $this->pais;
    }

    function departamento()
    {
        return $this->departamento;
    }

    function municipio()
    {
        return $this->municipio;
    }

    function coordinador()
    {
        return $this->coordinador;
    }

    function web()
    {
        return $this->web;
    }

    function correo()
    {
        return $this->correo;
    }

    function mision($html = false)
    {
        global $BaseD;

        $reg = $BaseD->GetRow("SELECT mision FROM instituciones WHERE id = " . $this->id);

        return ($html ? str_replace(array("\r", "\n"), array('', "\\n"), addslashes($reg['mision'])) : str_replace(array("\r", "\n"), array('', "<BR>"), $reg['mision']));
    }

    function vision($html = false)
    {
        global $BaseD;

        $reg = $BaseD->GetRow("SELECT vision FROM instituciones WHERE id = " . $this->id);

        return ($html ? str_replace(array("\r", "\n"), array('', "\\n"), addslashes($reg['vision'])) : str_replace(array("\r", "\n"), array('', "<BR>"), $reg['vision']));
    }

    function plataforma($nombre = false)
    {
        global $BaseD;
        if ($nombre == false) {
            $reg = $BaseD->GetRow("SELECT id_plataforma FROM instituciones WHERE id = ?", array($this->id));
            return ($reg['id_plataforma']);
        } else {
            $reg = $BaseD->GetRow("SELECT p.nombre FROM instituciones i INNER JOIN plataformas p on(i.id_plataforma = p.id)  WHERE i.id = ?", array($this->id));
            return ($reg['nombre']);
        }
    }

    function editar_plataforma($value = '')
    {
        global $BaseD;
        registro(__METHOD__, func_get_args(), $this);
        if (!empty($value) && is_numeric($value)) {
            if ($BaseD->Execute("UPDATE instituciones SET id_plataforma= ? WHERE id = ?", array($value, $this->id))) {
                echo "Modificado con éxito";
            } else {
                echo "No se realizó ninguna modificación";
            }
        } else {
            echo "No se realizó ninguna modificación";
        }
    }

    function listar_pines($json = true)
    {
        global $BaseD;
        $lista = array();
        $res = $BaseD->Execute("SELECT p.*  FROM pines p INNER JOIN cursos c ON(p.curso = c.id) INNER JOIN instituciones i ON(c.institucion = i.id) WHERE i.id = ? ORDER BY p.creado_en DESC", array($this->id));
        if ($res) {
            $lista = array();
            while (!$res->EOF) {
                $p = new stdClass();
                $p->pin = $res->fields['pin'];
                $p->activado_en = $res->fields['activado_en'];
                $p->activado_por = $res->fields['activado_por'];
                $lista[] = $p;
                $res->MoveNext();
            }
            $res->Close();
        }
        return (!$json) ? $lista : json_encode($lista);
    }

    function listar_pines_consecutivo($json = true, $con = 0)
    {
        global $BaseD;
        $lista = array();
        if ($con == 0)
            $res = $BaseD->Execute("SELECT p.*  FROM pines p INNER JOIN cursos c ON(p.curso = c.id) WHERE c.institucion = ? AND p.consecutivo > ? ORDER BY p.consecutivo ASC", array($this->id, 0));
        else
            $res = $BaseD->Execute("SELECT p.*  FROM pines p INNER JOIN cursos c ON(p.curso = c.id) WHERE c.institucion = ? AND p.consecutivo = ? ORDER BY p.consecutivo ASC", array($this->id, $con));
        if ($res) {
            $lista = array();
            while (!$res->EOF) {
                $p = new stdClass();
                $p->consecutivo = $res->fields['consecutivo'];
                $p->pin = $res->fields['pin'];
                $p->activado_en = $res->fields['activado_en'];
                $p->activado_por = $res->fields['activado_por'];
                $lista[] = $p;
                $res->MoveNext();
            }
            $res->Close();
        }
        return (!$json) ? $lista : json_encode($lista);
    }

    function cantidad_pines()
    {
        global $BaseD;
        $lista = array();
        $res = $BaseD->GetRow("SELECT COUNT(p.pin) n  FROM pines p INNER JOIN cursos c ON(p.curso = c.id) INNER JOIN instituciones i ON(c.institucion = i.id) WHERE i.id = ? AND p.consecutivo > ?", array($this->id, 0));
        return ($res["n"]);
    }

    function editar_ciudad($value = '')
    {
        global $BaseD, $ADODB_TYPE, $CHML_CONFIG;
        registro(__METHOD__, func_get_args(), $this);
        if (!empty($value)) {
            if ($BaseD->Execute("UPDATE instituciones SET ciudad= ? WHERE id = ?", array($value, $this->id))) {

                include "$CHML_CONFIG";

                $baseDC = NewADOConnection($ADODB_TYPE);
                $baseDC->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
                $baseDC->SetCharSet('utf8');
                if ($baseDC->Execute("UPDATE course_category SET name = ? WHERE code = ?", array($this->nombre . " / " . $this->ciudad, $this->id()))) {
                    $rs = $baseDC->Execute("SELECT id, description FROM course WHERE category_code = ?", array($this->id()));
                    $ok = true;
                    while (!$rs->EOF) {

                        $desc = str_replace($this->ciudad, $value, $rs->fields[1]);
                        $baseDC->Execute("UPDATE course SET description = ? WHERE id = ? ", array($desc, $rs->fields[0]));
                        $baseDC->Execute("UPDATE c_tool_intro SET intro_text = ? WHERE c_id = ? and id = ? ", array('<h2 style="text-align: center;">Bienvenidos al ' . $desc . '</h2>', $rs->fields[0], "course_homepage"));
                        $rs->MoveNext();
                    }
                }
                $this->ciudad = $value;
                echo "Modificado con éxito";
            } else {
                echo "No se realizó ninguna modificación";
            }
        } else {
            echo "No se realizó ninguna modificación";
        }
    }

    function editar_codigo_icfes($codigo_dane)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET cod_icfes = ? WHERE id = ?", array($codigo_dane, $this->id))) {
            $this->cod_icfes = $codigo_dane;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_codigo_dane($codigo_dane)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET cod_dane = ? WHERE id = ?", array($codigo_dane, $this->id))) {
            $this->cod_dane = $codigo_dane;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_nit($nit)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET nit = ? WHERE id = ?", array($nit, $this->id))) {
            $this->nit = $nit;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_pais($pais)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET pais = ? WHERE id = ?", array($pais, $this->id))) {
            $this->pais = $pais;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_departamento($departamento)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET departamento = ? WHERE id = ?", array($departamento, $this->id))) {
            $this->departamento = $departamento;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_municipio($municipio)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET municipio = ? WHERE id = ?", array($municipio, $this->id))) {
            $this->municipio = $municipio;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_web($web)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET web = ? WHERE id = ?", array($web, $this->id))) {
            $this->web = $web;
            return (true);
        } else {
            return (false);
        }
    }

    function editar_correo($correo)
    {
        global $BaseD;

        if ($BaseD->Execute("UPDATE instituciones SET correo = ? WHERE id = ?", array($correo, $this->id))) {
            $this->correo = $correo;
            return (true);
        } else {
            return (false);
        }
    }

    function genera_pines($grado, $cantidad, $quien, $activacion = null, $fechaUsuario = null)
    {
        global $BaseD;
        registro(__METHOD__, func_get_args(), $this, $quien);
        $listado = array();

        for ($i = 0; $i < $cantidad; $i++) {
            $j = 0;
            do {
                $pin = new Pin($grado, $quien);
                if ($pin->pin() != null) {
                    $listado[] = $pin->pin();
                }

                $j++;
            } while ($pin->pin() === null && $j < 5);
        }
        return $listado;
    }

    function genera_pines_fechas($grado, $cantidad, $quien, $maximaActivacion = null, $fechaUsuario = null)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $this, $quien);
        $listado = array();

        for ($i = 0; $i < $cantidad; $i++) {
            $j = 0;
            do {
                $pin = new Pin($grado, $quien, $maximaActivacion, $fechaUsuario);
                if ($pin->pin() != null) {
                    $pin_n = new stdClass();
                    $pin_n->consecutivo = $pin->consecutivo();
                    $pin_n->pin = $pin->pin();
                    $listado[] = $pin_n;
                }

                $j++;
            } while ($pin->pin() === null && $j < 5);
        }

        return $listado;
    }

    function inserta_myv($mision, $vision)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $this);
        $res = $BaseD->Execute("UPDATE instituciones SET mision = ?, vision = ? WHERE id = ?", array($mision, $vision, $this->id));

        return $res;
    }

    function inserta_plataforma($posicion, $boton, $url = '', $texto = '')
    {
        global $BaseD;

        /* OJO: MODIFICAR PARA REFLEJAR CAMBIO EN ENLACES DONDE SE AGREGA COLUMNAS target y opcional */

        registro(__METHOD__, func_get_args(), $this);
        $res = $BaseD->Execute("SELECT posicion FROM instituciones_plataformas WHERE institucion = ? AND posicion = ?", array($this->id, $posicion));
        if (empty($url)) {
            if ($res->RecordCount() > 0) {
                $SQL = "UPDATE instituciones_plataformas SET boton = ? WHERE institucion = ? AND posicion = ?";
            } else {
                $SQL = "INSERT INTO instituciones_plataformas (boton, institucion, posicion) VALUES (?,?,?)";
            }
            $res = $BaseD->Execute($SQL, array($boton, $this->id, $posicion));
        } else {
            if ($res->RecordCount() > 0) {
                $SQL = "UPDATE instituciones_plataformas SET boton = ?, url = ?, texto = ? WHERE institucion = ? AND posicion = ?";
            } else {
                $SQL = "INSERT INTO instituciones_plataformas (boton, institucion, posicion, url, texto) VALUES (?,?,?, ?, ?)";
            }
            $res = $BaseD->Execute($SQL, array($boton, $this->id, $posicion, $url, $texto));
        }

        if ($res) {
            return true;
        } else {
            return false;
        }
    }

    function imagenes_portada()
    {
        global $PORTADAS_DIR;

        $images = array();

        $dir = $PORTADAS_DIR . $this->nombre;
        if (!file_exists($dir)) {
            return $images;
        }

        $d = dir($dir);
        if ($d) {
            while (false !== ($arch = $d->read())) {
                if (is_file("$dir/$arch")) {
                    $images[] = $arch;
                }
            }
            $d->close();
        }
        sort($images);
        return $images;
    }

    function logo()
    {
        global $LOGOS_DIR, $LOGOS_URL;
        //Por el LMS
        if (!isset($LOGOS_DIR)) {
            include '/var/www/Front/config.inc.php';
        }

        $logo = '';
        $dir = $LOGOS_DIR . $this->nombre;
        $d = @dir($dir);
        if ($d) {
            while (false !== ($arch = $d->read()) && empty($logo)) {
                if (is_file("$dir/$arch")) {
                    $logo = $arch;
                }
            }
            $d->close();
        }
        return (empty($logo) ? null : $LOGOS_URL . rawurlencode($this->nombre) . "/$logo");
    }

    function enlaces_plataformas($usuario = null)
    {
        global $BaseD, $BTN_planlector, $BTN_digitales, $BTN_digitales_EDUCLASS, $BTN_planlector_EDUCLASS, $BTN_galeria, $BTN_galeria_EDUCLASS, $BTN_pruebas, $BTN_nuevo_saber, $BTN_pruebas_EDUCLASS, $BTN_lms, $BTN_lms_EDUCLASS, $CAT_GALERIA, $CAT_EDUCLASS, $CAT_PSABER, $CAT_PRESCHOOL, $BTN_zrecursos, $BTN_zlectura, $BTN_zcomunicativa, $ID_SABER_3, $ID_SABER_5, $ID_SABER_7, $ID_SABER_9, $ID_SABER_11, $BTN_saber_3, $BTN_saber_5, $BTN_saber_9, $BTN_saber_7, $BTN_saber_11, $BTN_planlector_plus, $BTN_consultor, $BTN_comunidad, $BTN_creador, $BTN_zlectura_aprende, $BTN_zaprendizaje_aprende, $SIE_PREFIX;

        $enlaces = array();
        $cole = new Institucion($_SESSION['idCol']);
        $plataforma = new Plataforma($cole->plataforma());
        $educaline = array('btn-educaline.png', '//colombia.educaline.com/', 'Educaline', '_blank');
        $zrecursos = array($BTN_zrecursos, '/GaleriaPreschool/', 'Ingresa a la zona de recursos', '_self');
        $zlectura = array($BTN_zlectura, '/planlectorPS/', 'Ingresa a la zona de lectura', '_self');
        $zcomunicativa = array($BTN_zcomunicativa, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2Findex.php%2Fgateway=true', 'Ingresa a la zona comunicativa', '_self');
        $lms = array($BTN_lms, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2Findex.php%2Fgateway=true', 'Ingreso a la plataforma educativa (LMS)', '_self');

        $planlector = array($BTN_planlector, '/planlector/', 'Ingresa a la biblioteca digital', '_self');
        $galeria = array($BTN_galeria, '/Galeria/', 'Ingresa a la galería de objetos digitales', '_self');
        // $pruebas = array($BTN_pruebas, '/virtual/course/index.php?categoryid=' . $CAT_PSABER, 'Ingresa al simulador de pruebas Saber Interactivas', '_self');
        $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
        $consultor = array($BTN_consultor, '/Consultor/', 'Ingresa al consultor', '_self');
        $comunidad = array($BTN_comunidad, '/RedSocial/', 'Ingresa a sala de profesores', '_self');
        $constructor = array($BTN_creador, '/DrpAutor/', 'Ingresa al arquitecto', '_self');
        // $plus = array($BTN_planlector_plus, '/bibliosieplus/', 'Ingresa a la biblioteca digital plus', '_self');
        $plus = array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self');

        if ($plataforma->es_educlass()) {
            if ($usuario->soy_preescolar() || $plataforma->es_preschool()) {
                $enlaces[] = $this->enlace($zlectura);
                $enlaces[] = $this->enlace($zrecursos);
                $enlaces[] = $this->enlace($zcomunicativa);
            } else {
                $planlector = array($BTN_planlector_EDUCLASS, '/planlector/', 'Ingresa a la biblioteca digital', '_self');
                $galeria = array($BTN_galeria_EDUCLASS, 'Galeria/', 'Ingresa a la galería de objetos digitales', '_self');
                // $pruebas = array($BTN_pruebas_EDUCLASS, '/virtual/course/index.php?categoryid=' . $CAT_PSABER, 'Ingresa al simulador de pruebas Saber Interactivas', '_self');
                $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
                $lms = array($BTN_lms_EDUCLASS, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2Findex.php%2Fgateway=true', 'Ingreso a la plataforma educativa (LMS)', '_self');
                $enlaces[] = $this->enlace($lms);
                $enlaces[] = $this->enlace($pruebas);
                $enlaces[] = $this->enlace($galeria);
                $enlaces[] = $this->enlace($planlector);
            }
        } else if ($plataforma->es_saber()) {
            $enlaces[] = $this->enlace(array($BTN_saber_3, 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_3, 'Ingresa a las pruebas saber de 3', '_self'));
            $enlaces[] = $this->enlace(array($BTN_saber_5, 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_5, 'Ingresa a las pruebas saber de 5', '_self'));
            $enlaces[] = $this->enlace(array($BTN_saber_7, 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_7, 'Ingresa a las pruebas saber de 7', '_self'));
            $enlaces[] = $this->enlace(array($BTN_saber_9, 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_9, 'Ingresa a las pruebas saber de 9', '_self'));
            $enlaces[] = $this->enlace(array($BTN_saber_11, 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_11, 'Ingresa a las pruebas saber de 11', '_self'));


            $galeria = array("saber/" . $BTN_galeria, '/Galeria/', 'Ingresa a la galería de objetos digitales', '_self');
            $consultor = array("saber/" . $BTN_consultor, '/Consultor/', 'Ingresa al consultor', '_self');
            $enlaces[] = $this->enlace($galeria);
            $enlaces[] = $this->enlace($consultor);
        } else if ($plataforma->es_nuevo_saber()) {
            $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
            $enlaces[] = $this->enlace($pruebas);
        } elseif ($plataforma->es_biblioteca()) {
            $enlaces[] = $this->enlace($planlector);
        } else if ($plataforma->es_comprende()) {
            $enlaces[] = $this->enlace(array("comprende/" . $BTN_planlector, '/planlector/', 'Ingresa a la biblioteca digital', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-lectura.png", 'http://localhost/virtual/course/view.php?id=77&section=1', 'Ingresa lectura integral', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-fichas.png", 'http://localhost/virtual/course/view.php?id=77&section=2', 'Ingresa a fichas', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-guias.png", 'http://localhost/virtual/course/view.php?id=77&section=3', 'Ingresa a guías', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-pruebas.png", 'http://localhost/virtual/course/view.php?id=77&section=4', 'Ingresa a pruebas', '_self'));
        } else if ($plataforma->es_guiandote()) {
            $enlaces[] = $this->enlace(array("guiandote/guias.png", 'http://localhost/Guiandote/lista.php', 'Ingresa a las guías', '_self'));
            $enlaces[] = $this->enlace($galeria);
            $enlaces[] = $this->enlace($pruebas);
            $enlaces[] = $this->enlace($lms);
        } else if ($plataforma->es_diveraprende()) {
            $enlaces[] = $this->enlace(array("aprende/exploradores.png", 'http://localhost/virtual/course/view.php?id=56', 'Ingresa a exploradoes', '_self'));
            $enlaces[] = $this->enlace(array("aprende/creadores.png", 'http://localhost/virtual/course/view.php?id=42', 'Ingresa a creadores', '_self'));
            $enlaces[] = $this->enlace(array("aprende/viajeros.png", 'http://localhost/virtual/course/view.php?id=43', 'Ingresa a viajeros', '_self'));
            $enlaces[] = $this->enlace(array("aprende/aventuretos.png", 'http://localhost/virtual/course/view.php?id=44', 'Ingresa a aventureros', '_self'));
            $enlaces[] = $this->enlace(array("aprende/leer.png", '/planlectorPS/', 'Ingresa a la biblioteca', '_self'));
        } else if ($plataforma->es_sie() || $plataforma->es_sieplus()) {
            if ($usuario->soy_preescolar() || $plataforma->es_preschool()) {
                $enlaces[] = $this->enlace($zlectura);
                $enlaces[] = $this->enlace($zrecursos);
                $enlaces[] = $this->enlace($zcomunicativa);
            } else {

                $enlaces[] = $this->enlace($lms);
                $enlaces[] = $this->enlace($pruebas);
                $enlaces[] = $this->enlace($galeria);
                $enlaces[] = $this->enlace($planlector);
                $enlaces[] = $this->enlace($consultor);
                $enlaces[] = $this->enlace($constructor);
            }

            if ($plataforma->es_sieplus()) {
                // $enlaces[] = $this->enlace(array($BTN_planlector_plus, '/bibliosieplus/', 'Ingresa a la biblioteca digital plus', '_self'));
                $enlaces[] = $this->enlace(array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
            }
        }

        if (is_null($usuario) || !$usuario->soy_preescolar()) {
            $recordSet = $BaseD->Execute("SELECT boton, url, texto, target, opcional FROM instituciones_plataformas WHERE institucion = " . $this->id . " ORDER BY posicion");
            if ($recordSet->RecordCount() > 0) {
                $enlaces = array();
                while (!$recordSet->EOF) {
                    switch ($recordSet->fields['boton']) {
                        case $BTN_lms:
                            $enlaces[] = $this->enlace($lms);
                            break;
                        case $BTN_pruebas:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        case $BTN_galeria:
                            $enlaces[] = $this->enlace($galeria);
                            break;
                        case $BTN_planlector:
                            $enlaces[] = $this->enlace($planlector);
                            break;
                        case $BTN_consultor:
                            $enlaces[] = $this->enlace($consultor);
                            break;
                        case 'btn-educaline.png':
                            $enlaces[] = $this->enlace($educaline);
                            break;
                        case $BTN_comunidad:
                            $enlaces[] = $this->enlace($comunidad);
                            break;
                        case $BTN_creador:
                            $enlaces[] = $this->enlace($constructor);
                            break;
                        case $BTN_planlector_EDUCLASS:
                            $enlaces[] = $this->enlace($planlector);
                            break;
                        case $BTN_galeria_EDUCLASS:
                            $enlaces[] = $this->enlace($galeria);
                            break;
                        case $BTN_pruebas_EDUCLASS:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        case $BTN_lms_EDUCLASS:
                            $enlaces[] = $this->enlace($lms);
                            break;
                        case $BTN_planlector_plus:
                            $enlaces[] = $this->enlace($plus);
                            break;
                        case $BTN_digitales:
                            $enlaces[] = $this->enlace(array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
                            break;
                        case $BTN_digitales_EDUCLASS:
                            $enlaces[] = $this->enlace(array($BTN_digitales_EDUCLASS, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
                            break;
                        case $BTN_nuevo_saber:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        default:
                            $enlaces[] = $this->enlace($recordSet->fields);
                            break;
                    }
                    $recordSet->MoveNext();
                }
                $recordSet->Close();
            }
        }
        return $enlaces;
    }

    function enlaces_plataformas_sie($usuario = null)
    {
        global $BaseD, $BTN_planlector, $BTN_digitales, $BTN_digitales_EDUCLASS, $BTN_planlector_EDUCLASS, $BTN_galeria, $BTN_galeria_EDUCLASS, $BTN_pruebas, $BTN_nuevo_saber, $BTN_pruebas_EDUCLASS, $BTN_lms, $BTN_lms_EDUCLASS, $CAT_GALERIA, $CAT_EDUCLASS, $CAT_PSABER, $CAT_PRESCHOOL, $BTN_zrecursos, $BTN_zlectura, $BTN_zcomunicativa, $ID_SABER_3, $ID_SABER_5, $ID_SABER_7, $ID_SABER_9, $ID_SABER_11, $BTN_saber_3, $BTN_saber_5, $BTN_saber_7, $BTN_saber_9, $BTN_saber_11, $BTN_planlector_plus, $BTN_consultor, $BTN_comunidad, $BTN_creador, $BTN_zlectura_aprende, $BTN_zaprendizaje_aprende, $SIE_PREFIX;
        $_planlector = $_planlector_EDUCLASS = 'planlector';
        $_galeria = $_galeria_EDUCLASS = 'galeria';
        $_pruebas = $_pruebas_EDUCLASS = 'saber';
        $_lms = $_lms_EDUCLASS = 'aula';
        $_planlector_plus = 'bibliosieplus';
        $_consultor = 'consultor';
        $_comunidad = 'redsocial';
        $_creador = 'arquitecto';
        $enlaces = array();
        $consultor = array();
        $constructor = array();
        $cole = new Institucion($_SESSION['idCol']);
        $plataforma = new Plataforma($cole->plataforma());
        if ($plataforma->es_educlass()) {
            $planlector = array($_planlector_EDUCLASS, '/planlector/', 'Biblioteca', '_self');
            $galeria = array($_galeria_EDUCLASS, '/Galeria/', 'Galeria', '_self');
            // $pruebas = array($_pruebas_EDUCLASS, '/virtual/course/index.php?categoryid=1', 'Saber', '_self');
            $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
            //no $pruebas = array ($_pruebas_EDUCLASS, '/virtual/course/index.php?categoryid='.$CAT_PSABER, 'Pruebas Saber Interactivas', '_self');
            $lms = array($_lms_EDUCLASS, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2F&gateway=true', 'Aula', '_self');
        } else {
            $planlector = array($_planlector, '/planlector/', 'Biblioteca', '_self');
            $galeria = array($_galeria, '/Galeria/', 'Galeria', '_self');
            // $pruebas = array($_pruebas, '/virtual/course/index.php?categoryid=1', 'Saber', '_self');
            $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
            //  $pruebas = array ($_pruebas, '/virtual/course/index.php?categoryid='.$CAT_PSABER, 'Pruebas Saber Interactivas', '_self');
            $lms = array($_lms, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2F&gateway=true', 'Aula', '_self');
            $consultor = array($_consultor, '/Consultor/', 'Consultor', '_self');
            $comunidad = array($_comunidad, '/RedSocial/', 'Sala de profesores', '_self');
            $constructor = array($_creador, '/DrpAutor/', 'Arquitecto', '_self');
            // $plus = array($_planlector_plus, '/bibliosieplus/', 'Textos', '_self');
            $plus = array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self');
        }

        $educaline = array('btn-educaline.png', '//colombia.educaline.com/', 'Educaline', '_blank');
        $zrecursos = array($BTN_zrecursos, '/GaleriaPreschool/', 'Aprendizaje', '_self');
        $zlectura = array($BTN_zlectura, '/planlectorPS/', 'Lectura', '_self');
        $zcomunicativa = array($BTN_zcomunicativa, 'https://sie.educar.com.co/cas/login?service=http%3A%2F%2Fsie.educar.com.co:8080%2FLMS%2F&gateway=true', 'Comunicacion', '_self');

        if ($plataforma->es_saber()) {
            $enlaces[] = $this->enlace(array('saber3', 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_3, 'Pruebas saber de 3', '_self'));
            $enlaces[] = $this->enlace(array('saber5', 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_5, 'Pruebas saber de 5', '_self'));
            $enlaces[] = $this->enlace(array('saber7', 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_7, 'Pruebas saber de 7', '_self'));
            $enlaces[] = $this->enlace(array('saber9', 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_9, 'Pruebas saber de 9', '_self'));
            $enlaces[] = $this->enlace(array('saber11', 'http://localhost/virtual/course/view.php?id=' . $ID_SABER_11, 'Pruebas saber de 11', '_self'));
            $galeria = array("saber/" . $BTN_galeria, '/Galeria/', 'Ingresa a la galería de objetos digitales', '_self');
            $consultor = array("saber/" . $BTN_consultor, '/Consultor/', 'Ingresa al consultor', '_self');
        } else if ($plataforma->es_nuevo_saber()) {
            $pruebas = array($BTN_nuevo_saber, 'http://localhost/PruebasSaber/login', 'Saber y PISA', '_self');
            $enlaces[] = $this->enlace($pruebas);
        } else if ($plataforma->es_biblioteca()) {
            $enlaces[] = $this->enlace($planlector);
        } else if ($plataforma->es_comprende()) {
            $enlaces[] = $this->enlace(array("comprende/" . $_planlector, '/planlector/', '' . $_planlector, '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-lectura.png", 'http://localhost/virtual/course/view.php?id=77&section=1', 'Lectura', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-fichas.png", 'http://localhost/virtual/course/view.php?id=77&section=2', 'Fichas', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-guias.png", 'http://localhost/virtual/course/view.php?id=77&section=3', 'Guías', '_self'));
            $enlaces[] = $this->enlace(array("comprende/btn-pruebas.png", 'http://localhost/virtual/course/view.php?id=77&section=4', 'Pruebas', '_self'));
        } else if ($plataforma->es_guiandote()) {
            $enlaces[] = $this->enlace(array("guiandote/guias.png", 'http://localhost/Guiandote/lista.php', 'Guías', '_self'));
            $enlaces[] = $this->enlace($galeria);
            $enlaces[] = $this->enlace($pruebas);
            $enlaces[] = $this->enlace($lms);
        } else if ($plataforma->es_diveraprende()) {
            $enlaces[] = $this->enlace(array("aprende/exploradores.png", 'http://localhost/virtual/course/view.php?id=56', 'Exploradoes', '_self'));
            $enlaces[] = $this->enlace(array("aprende/creadores.png", 'http://localhost/virtual/course/view.php?id=42', 'Creadores', '_self'));
            $enlaces[] = $this->enlace(array("aprende/viajeros.png", 'http://localhost/virtual/course/view.php?id=43', 'Viajeros', '_self'));
            $enlaces[] = $this->enlace(array("aprende/aventuretos.png", 'http://localhost/virtual/course/view.php?id=44', 'Aventureros', '_self'));
            $enlaces[] = $this->enlace(array("aprende/leer.png", '/planlectorPS/', 'Biblioteca', '_self'));
        } else if (is_null($usuario) || !$usuario->soy_preescolar()) {
            $recordSet = $BaseD->Execute("SELECT boton, url, texto, target, opcional FROM instituciones_plataformas WHERE institucion = " . $this->id . " ORDER BY posicion");
            if (!$recordSet || $recordSet->RecordCount() == 0) {
                if ($plataforma->es_sieplus()) {
                    // $enlaces[] = $this->enlace(array($_planlector_plus, '/bibliosieplus/', 'Textos', '_self'));
                    $enlaces[] = $this->enlace(array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
                }

                $enlaces[] = $this->enlace($lms);
                $enlaces[] = $this->enlace($pruebas);
                $enlaces[] = $this->enlace($galeria);
                $enlaces[] = $this->enlace($planlector);
                $enlaces[] = $this->enlace($consultor);
                if (!$usuario->soy_estudiante()) {
                    $enlaces[] = $this->enlace($constructor);
                }
            } else {
                while (!$recordSet->EOF) {
                    switch ($recordSet->fields['boton']) {
                        case $BTN_lms:
                            $enlaces[] = $this->enlace($lms);
                            break;
                        case $BTN_pruebas:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        case $BTN_galeria:
                            $enlaces[] = $this->enlace($galeria);
                            break;
                        case $BTN_planlector:
                            $enlaces[] = $this->enlace($planlector);
                            break;
                        case $BTN_consultor:
                            $enlaces[] = $this->enlace($consultor);
                            break;
                        case 'btn-educaline.png':
                            $enlaces[] = $this->enlace($educaline);
                            break;
                        case $BTN_comunidad:
                            $enlaces[] = $this->enlace($comunidad);
                            break;
                        case $BTN_creador:
                            if (!$usuario->soy_estudiante()) {
                                $enlaces[] = $this->enlace($constructor);
                            }
                            break;
                        case $BTN_planlector_EDUCLASS:
                            $enlaces[] = $this->enlace($planlector);
                            break;
                        case $BTN_galeria_EDUCLASS:
                            $enlaces[] = $this->enlace($galeria);
                            break;
                        case $BTN_pruebas_EDUCLASS:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        case $BTN_lms_EDUCLASS:
                            $enlaces[] = $this->enlace($lms);
                            break;
                        case $BTN_planlector_plus:
                            $enlaces[] = $this->enlace($plus);
                            break;
                        case $BTN_digitales:
                            $enlaces[] = $this->enlace(array($BTN_digitales, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
                            break;
                        case $BTN_digitales_EDUCLASS:
                            $enlaces[] = $this->enlace(array($BTN_digitales_EDUCLASS, '/resources/ProyectosSIE/Textos/', 'Libros_digitales', '_self'));
                            break;
                        case $BTN_nuevo_saber:
                            $enlaces[] = $this->enlace($pruebas);
                            break;
                        default:
                            $enlaces[] = $this->enlace($recordSet->fields);
                            break;
                    }
                    $recordSet->MoveNext();
                }
                $recordSet->Close();
            }
        } else {
            $enlaces[] = $this->enlace($zlectura);
            $enlaces[] = $this->enlace($zrecursos);
            $enlaces[] = $this->enlace($zcomunicativa);
        }

        return $enlaces;
    }

    function enlace($datos)
    {
        $enlace = new stdClass();
        $enlace->boton = isset($datos[0]) ? $datos[0] : "";
        $enlace->url = isset($datos[1]) ? $datos[1] : "";
        $enlace->texto = isset($datos[2]) ? $datos[2] : "";
        $enlace->target = (empty($datos[3]) ? (strpos($enlace->url, 'educar') === false ? '_blank' : '_self') : $datos[3]);
        $enlace->opcional = isset($datos[4]) ? $datos[4] : "";
        return $enlace;
    }

    function registra_materia($materia)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $this);
        $sql = "INSERT INTO materias (materia, institucion) VALUES ('" . $materia . "', " . $this->id . " )";
        if ($res = $BaseD->Execute($sql) !== false) {
            return true;
        } else {
            return false;
        }
    }

    function listar_materias()
    {
        global $BaseD;
        $lista = array();

        $recordSet = $BaseD->Execute("SELECT id, materia FROM materias WHERE institucion = " . $this->id . " ORDER BY materia");
        while (!$recordSet->EOF) {
            $lista[$recordSet->fields['id']] = $recordSet->fields['materia'];
            $recordSet->MoveNext();
        }
        $recordSet->Close();
        @asort($lista);
        return $lista;
    }

    function listar_institucioines($habilitado = 0)
    {
        global $BaseD;
        $lista = array();

        $res = $BaseD->Execute("SELECT id, nombre FROM instituciones WHERE habilitado = ? ORDER BY nombre DESC", array($habilitado));
        while (!$res->EOF) {
            $lista[$res->fields['id']] = $res->fields['nombre'];
            $res->MoveNext();
        }
        $res->Close();

        @asort($lista);

        return $lista;
    }

    function listar_grupos_materias()
    {
        global $BaseD;
        $lista = array();
        //	$BaseD->debug = true;
        $res = $BaseD->Execute("SELECT g.id, g.grupo, g.materia FROM grupos_materias as g INNER JOIN materias as m on (g.materia = m.id) where m.institucion = ?", array($this->id()));
        while (!$res->EOF) {

            $gm = new stdClass();
            $gm->id = $res->fields['id'];
            $gm->grupo = $res->fields['grupo'];
            $gm->materia = $res->fields['materia'];
            $lista[] = $gm;
            $res->MoveNext();
        }

        $res->Close();

        return $lista;
    }


    function registra_grados($grados)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $this);

        //$BaseD->debug = true;
        $cantidad = 0;
        foreach ($grados as $grado) {
            if ($BaseD->Execute("INSERT INTO cursos (institucion, grado) VALUES (?, ?)", array($this->id(), $grado)) !== false) {
                $cantidad++;
            }
        }

        //$BaseD->debug = false;
        return $cantidad;
    }
    /**
     * [listar_cursos description]
     *
     * @param  boolean $ConCurso           [description]
     * @param  boolean $json               [Retorna un json si es true]
     * @param  boolean $TieneGrupoAsociado [description]
     * @param  boolean $ConPreescolar      [description]
     * @param  boolean $ConPrimaria        [description]
     * @param  boolean $ConBachillerato    [description]
     * @return [type]                      [description]
     */
    function listar_cursos($ConCurso = false, $json = true, $TieneGrupoAsociado = false, $ConPreescolar = true, $ConPrimaria = true, $ConBachillerato = true)
    {
        global $BaseD;
        $listado = array();
        $CondGrados = ($ConPreescolar ? '' : ' AND grado >= 1');
        $CondGrados .= ($ConPrimaria ? '' : ' AND (grado < 1 OR grado > 5)');
        $CondGrados .= ($ConBachillerato ? '' : ' AND grado < 6');
        //$BaseD->debug= true;
        $sql = ($ConCurso ? ($TieneGrupoAsociado ?
            "SELECT G.id, C.id AS id_grado, G.grupo
			FROM cursos C
			RIGHT JOIN grupos G
			ON C.id = G.curso
			RIGHT JOIN grupos_materias GM
			ON G.id = GM.grupo
			WHERE institucion = ? $CondGrados
			GROUP BY G.id
			ORDER BY CAST(grado AS UNSIGNED), G.grupo"
            : "SELECT G.id, C.id AS id_grado, grupo
			FROM grupos G
			LEFT JOIN cursos C
			ON G.curso = C.id
			WHERE institucion = ? $CondGrados
			ORDER BY CAST(grado AS UNSIGNED)")
            : "SELECT id, grado
			FROM cursos WHERE institucion = ? $CondGrados
			ORDER BY CAST(grado AS UNSIGNED)");
        $recordSet = $BaseD->Execute($sql, array($this->id));
        if (!$recordSet) {
            $listado = null;
        } else {
            while (!$recordSet->EOF) {
                $grado = new Grado($recordSet->fields['id_grado']);
                $listado[$recordSet->fields['id']] = ($ConCurso ? $grado->gradoL() . $recordSet->fields['grupo'] : $grado->gradoL());
                $recordSet->MoveNext();
            }
            $recordSet->Close();
        }
        //$BaseD->debug= false;
        return ($json ? json_encode($listado) : $listado);
    }

    function listar_cursos_lms_x_colegio()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        registro(__METHOD__, func_get_args(), $this);
        include $CHML_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $lista = array();
        $y = $BaseD->Execute("SELECT c.code, c.id, c.title FROM " . $CFG->prefix . "course AS c  WHERE c.category_code= ? AND c.visibility = ? ORDER BY c.title ASC", array($this->id, 1));
        while (!$y->EOF) {
            $curso = new stdClass();
            $curso->id = $y->fields['id'];
            $curso->nombre = $y->fields['title'];
            $curso->codigo = $y->fields['code'];
            $lista[] = $curso;
            $y->MoveNext();
        }
        $y->Close();
        return $lista;
    }

    function listar_grados($json = false)
    {
        global $BaseD;
        //$BaseD->debug= true;
        $listado = array();
        $sql = "SELECT id FROM cursos C WHERE institucion = ? ORDER BY CAST(grado AS UNSIGNED)";
        $recordSet = $BaseD->Execute($sql, array($this->id()));
        if (!$recordSet) {
            $listado = null;
        } else {
            while (!$recordSet->EOF) {
                $grado = new Grado($recordSet->fields['id']);
                $listado[$recordSet->fields['id']] = $grado->gradoL();
                $recordSet->MoveNext();
            }
            $recordSet->Close();
        }
        //$BaseD->debug= false;
        return ($json ? json_encode($listado) : $listado);
    }

    function grupos($grado)
    {
        global $BaseD;
        //$BaseD->debug = true;
        $grupos = array();
        $recordSet = $BaseD->Execute("SELECT id FROM grupos WHERE curso = $grado ORDER BY grupo");
        while (!$recordSet->EOF) {
            $grupos[] = $recordSet->fields['id'];
            $recordSet->MoveNext();
        }
        return $grupos;
    }

    function eliminar_grupo($grupo)
    {
        global $BaseD;
        //$BaseD->debug = true;
        registro(__METHOD__, func_get_args(), $this);
        $grupos = array();
        $recordSet = $BaseD->Execute("DELETE FROM grupos WHERE id = $grupo");
        if ($recordSet) {
            return (true);
        } else {
            return (false);
        }
    }

    function desasociar_materia($grado, $materia, $grupo = 0)
    {
        global $BaseD;
        //$BaseD->debug = true;
        registro(__METHOD__, func_get_args(), $this);
        if ($grupo == 0) {
            $grupos = $this->grupos($grado);
            $bien = true;

            foreach ($grupos as $grupo) {
                $curso = new Curso((int) $grupo);
                $asignatura = new Materia($materia);
                $reg = $BaseD->Execute("SELECT * FROM grupos_materias WHERE grupo = ? AND materia = ?", array($grupo, $materia));
                if ($reg->RecordCount() > 0) {
                    if ($this->existe_curso_lms($grupo . "-" . $materia)) {
                        $curso->curso_lms_invisible($materia);
                    }
                    $reg = $BaseD->Execute("DELETE FROM grupos_materias WHERE grupo = ? AND materia = ?", array($grupo, $materia));
                } else {
                    $bien &= $reg;
                }
            }
        } else {
            $curso = new Curso((int) $grupo);
            $asignatura = new Materia($materia);
            $reg = $BaseD->Execute("SELECT * FROM grupos_materias WHERE grupo = ? AND materia = ?", array($grupo, $materia));
            if ($reg->RecordCount() > 0) {
                if ($this->existe_curso_lms($grupo . "-" . $materia)) {
                    $curso->curso_lms_invisible($materia);
                }
                $reg = $BaseD->Execute("DELETE FROM grupos_materias WHERE grupo = ? AND materia = ?", array($grupo, $materia));
            } else {
                $bien &= $reg;
            }

            $this->eliminar_grupo($grupo);
        }

        return $bien;
    }

    function asociar_materia($grado, $materia)
    {
        global $BaseD;
        //$BaseD->debug = true;
        registro(__METHOD__, func_get_args(), $this);
        $grupos = $this->grupos($grado);
        $bien = true;

        foreach ($grupos as $grupo) {
            $curso = new Curso((int) $grupo);
            $asignatura = new Materia($materia);
            $reg = $BaseD->Execute("SELECT * FROM grupos_materias WHERE grupo = ? AND materia = ?", array($grupo, $materia));
            if ($reg->RecordCount() == 0) {
                $reg = $BaseD->Execute("INSERT INTO grupos_materias (grupo, materia) VALUES (?, ?)", array($grupo, $materia));
            }
            $e = ADODB_Pear_Error();

            if ($reg || $e->code == 1062) {
                if ($this->tiene_lms()) {
                    if (!$this->existe_curso_lms($grupo . "-" . $materia)) {
                        $bien &= $this->crear_curso_en_LMS($grupo . "-" . $materia, $asignatura->nombre() . " " . $curso->curso());
                        //matricular estudiantes ya asociados a materias nuevas
                        foreach ($curso->matriculados(false, false, $materia, true) as $est) {
                            if (!$curso->existe_matricula_lms($materia, $est)) {
                                $curso->matricular_lms($materia, $est);
                            }
                        }
                    } else {
                        $curso->curso_lms_invisible($materia, 1);
                    }
                }
            } else {
                $bien &= $reg;
            }
        }

        return $bien;
    }

    function copiar($fuente, $destino)
    {
        if (is_dir($fuente)) {
            $dir = opendir($fuente);
            while ($archivo = readdir($dir)) {
                if ($archivo != "." && $archivo != "..") {
                    if (is_dir($fuente . "/" . $archivo)) {
                        if (!is_dir($destino . "/" . $archivo)) {
                            mkdir($destino . "/" . $archivo);
                        }
                        copiar($fuente . "/" . $archivo, $destino . "/" . $archivo);
                    } else {
                        copy($fuente . "/" . $archivo, $destino . "/" . $archivo);
                    }
                }
            }
            closedir($dir);
        } else {
            copy($fuente, $destino);
        }
    }

    function crear_curso_en_LMS($id, $nombre)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR, $CHML_COUR_MODEL, $CUOTA_LMS_CURSO;

        registro(__METHOD__, func_get_args(), $this);
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');

        //$BaseD->debug = true;

        $fallo = false;
        $sql_course = "INSERT INTO course (code, directory, course_language, title, description, category_code, visibility, show_score, tutor_name, visual_code, department_name, department_url, disk_quota, last_visit, last_edit, creation_date, expiration_date, subscribe, unsubscribe, registration_code, legal, activate_legal, course_type_id) VALUES
		(?, ?, 'spanish', ?, ?, ?, 1, 1, '', ?, '', '', ?, NULL, NOW(), NOW(), DATE_ADD(NOW(), INTERVAL 14 MONTH), 0, 0, '', '', 0, 1)";

        $reg = $BaseD->Execute($sql_course, array($id, $id, $nombre, "Curso " . $nombre . " en " . $this->nombre . " de " . $this->ciudad, $this->id, $id, $CUOTA_LMS_CURSO));
        $e = ADODB_Pear_Error();
        if (!$reg) {
            if ($e->code != 1062) {
                echo '<p>' . $e->message . '</p>';
                return false;
            } else {
                $x = $BaseD->GetRow("SELECT id FROM course WHERE code = ?", array($id));
                $Ncurso = $x['id'];
            }
        } else {
            $Ncurso = $BaseD->Insert_ID();
        }

        if (stristr($nombre, 'Párvulos') === false && stristr($nombre, 'PreJard') === false && stristr($nombre, 'Jard') === false && stristr($nombre, 'Transici') === false) {

            $insti = new Institucion($this->id);
            $plataforma = new Plataforma($insti->plataforma());
            if ($plataforma->es_educlass()) {
                $theme = 'educlasstheme';
                $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
				(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 7, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 8, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 9, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 10, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
                $array_tools = array($Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso);
            } else {
                $theme = '';
                $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
				(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 7, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 8, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 9, 'dropbox', 'dropbox/index.php', 'dropbox.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 10, 'group', 'group/group.php', 'group.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 11, 'chat', 'chat/chat.php', 'chat.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 12, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
				(?, 13, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 14, 'glossary', 'glossary/index.php', 'glossary.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
				(?, 15, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
                $array_tools = array($Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso);
            }
        } else {
            $theme = 'siepresschool';
            $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
			(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
			(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 4, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 5, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 6, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
			(?, 7, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 8, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 9, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
			(?, 10, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0);";
            $array_tools = array($Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso);

            // 			INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) SELECT c_id, 9, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0 FROM `c_tool` GROUP BY c_id HAVING MAX(id) <= 8;
        }

        // 		$BaseD->StartTrans();
        $BaseD->Execute("INSERT INTO access_url_rel_course (access_url_id, c_id) VALUES (1, ?)", array($Ncurso));

        $BaseD->Execute(
            "INSERT INTO c_course_setting (c_id, id, variable, subkey, type, category, value, title, comment, subkeytext) VALUES
		(?, 1, 'email_alert_manager_on_new_doc', NULL, NULL, 'work', '0', '', NULL, NULL),
		(?, 2, 'email_alert_on_new_doc_dropbox', NULL, NULL, 'dropbox', '0', '', NULL, NULL),
		(?, 3, 'allow_user_edit_agenda', NULL, NULL, 'agenda', '0', '', NULL, NULL),
		(?, 4, 'allow_user_edit_announcement', NULL, NULL, 'announcement', '0', '', NULL, NULL),
		(?, 5, 'email_alert_manager_on_new_quiz', NULL, NULL, 'quiz', '1', '', NULL, NULL),
		(?, 6, 'allow_user_image_forum', NULL, NULL, 'forum', '1', '', NULL, NULL),
		(?, 7, 'course_theme', NULL, NULL, 'theme', '" . $theme . "', '', NULL, NULL),
		(?, 8, 'allow_learning_path_theme', NULL, NULL, 'theme', '1', '', NULL, NULL),
		(?, 9, 'allow_open_chat_window', NULL, NULL, 'chat', '1', '', NULL, NULL),
		(?, 10, 'email_alert_to_teacher_on_new_user_in_course', NULL, NULL, 'registration', '0', '', NULL, NULL),
		(?, 11, 'allow_user_view_user_list', NULL, NULL, 'user', '1', '', NULL, NULL),
		(?, 12, 'display_info_advance_inside_homecourse', NULL, NULL, 'thematic_advance', '1', '', NULL, NULL),
		(?, 13, 'email_alert_students_on_new_homework', NULL, NULL, 'work', '0', '', NULL, NULL),
		(?, 14, 'enable_lp_auto_launch', NULL, NULL, 'learning_path', '0', '', NULL, NULL),
		(?, 15, 'pdf_export_watermark_text', NULL, NULL, 'learning_path', '', '', NULL, NULL),
		(?, 16, 'allow_public_certificates', NULL, NULL, 'certificates', '', '', NULL, NULL)",
            array($Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso, $Ncurso)
        );

        $BaseD->Execute(
            "INSERT INTO c_document (c_id, id, path, comment, title, filetype, size, readonly, session_id) VALUES
		(?, 1, '/shared_folder', NULL, 'Carpetas de los usuarios', 'folder', 0, 0, 0),
		(?, 2, '/chat_files', NULL, 'Historial de conversaciones en el chat', 'folder', 0, 0, 0)",
            array($Ncurso, $Ncurso)
        );

        $BaseD->Execute("INSERT INTO c_group_category (c_id, id, title, description, doc_state, calendar_state, work_state, announcements_state, forum_state, wiki_state, chat_state, max_student, self_reg_allowed, self_unreg_allowed, groups_per_user, display_order) VALUES (?, 2, 'Grupos por defecto', '', 1, 1, 1, 1, 1, 1, 1, 8, 0, 0, 0, 0)", array($Ncurso));

        $BaseD->Execute(
            "INSERT INTO c_item_property (c_id, id, tool, insert_user_id, insert_date, lastedit_date, ref, lastedit_type, lastedit_user_id, to_group_id, to_user_id, visibility, start_visible, end_visible) VALUES
		(?, 2, 'document', 1, NOW(), NOW(), 2, 'DocumentAdded', 1, NULL, NULL, 0, NULL, NULL)",
            array($Ncurso)
        );

        if ($reg) {
            $BaseD->Execute($sql_tools, $array_tools);
        }

        $BaseD->Execute(
            "INSERT INTO c_tool_intro (c_id, id, intro_text, session_id) VALUES
		(?, 'course_homepage', ?, 0)",
            array($Ncurso, '<h2 style="text-align: center;">Bienvenidos al curso ' . $nombre . ' en ' . $this->nombre . ' de ' . $this->ciudad . '</h2>')
        );

        if ($BaseD->HasFailedTrans() && $e->code != 1062) {

            $fallo = true;
            $e = ADODB_Pear_Error();

            echo '<p>' . $e->message . '</p>';
        }
        /* //copiar($CHML_COUR.$CHML_COUR_MODEL, $CHML_COUR.$id);
        if (!xcopy($CHML_COUR."CURSOBASE", $CHML_COUR.$id)) {
            $fallo = true;
        }

        $contenido_index = file_get_contents($CHML_COUR."MODELO/index.php");
        $archivo_dest = fopen($CHML_COUR.$id."/index.php", "w+");
        fwrite($archivo_dest, str_replace("MODELO", $id, $contenido_index));*/

        //	$BaseD->debug = true;
        // 		$BaseD->CompleteTrans();
        return !$fallo;
    }

    function tiene_lms()
    {
        global $BaseD, $BTN_lms, $BTN_zrecursos, $BTN_lms_EDUCLASS;

        $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE institucion = ?", array($this->id));
        if ($reg->RecordCount() == 0) {
            return true;
        } else {
            $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE (boton = ? OR boton = ? OR boton = ?) AND institucion = ?", array($BTN_lms, $BTN_zrecursos, $BTN_lms_EDUCLASS, $this->id));
            if ($reg->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function tiene_plan_lector()
    {
        global $BaseD, $BTN_planlector, $BTN_planlector_EDUCLASS;

        $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE institucion = ?", array($this->id));
        if ($reg->RecordCount() == 0) {
            return true;
        } else {
            $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE (boton = ? OR boton = ?) AND institucion = ?", array($BTN_planlector, $BTN_planlector_EDUCLASS, $this->id));
            if ($reg->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function tiene_galeria()
    {
        global $BaseD, $BTN_galeria, $BTN_galeria_EDUCLASS;

        $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE institucion = ?", array($this->id));
        if ($reg->RecordCount() == 0) {
            return true;
        } else {
            $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE (boton = ? OR boton = ?) AND institucion = ?", array($BTN_galeria, $BTN_galeria_EDUCLASS, $this->id));
            if ($reg->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function tiene_meli()
    {
        global $BaseD, $BTN_meli;

        $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE institucion = ?", array($this->id));
        if ($reg->RecordCount() == 0) {
            return true;
        } else {
            $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE boton = ? AND institucion = ?", array($BTN_meli, $this->id));
            if ($reg->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function tiene_pruebas()
    {
        global $BaseD, $BTN_pruebas, $BTN_pruebas_EDUCLASS;
        $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE institucion = ?", array($this->id));

        if ($reg->RecordCount() == 0) {
            return true;
        } else {
            $reg = $BaseD->Execute("SELECT id FROM instituciones I LEFT JOIN instituciones_plataformas P ON I.id = P.institucion WHERE (boton = ? OR boton = ?) AND institucion = ?", array($BTN_pruebas, $BTN_pruebas_EDUCLASS, $this->id));
            if ($reg->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function listar_estudiantes($Fjson = true, $habilitados = 1)
    {
        if ($Fjson) {
            return json_encode(listar($this->id, 'estudiante', $habilitados));
        } else {
            return listar($this->id, 'estudiante', $habilitados);
        }
    }

    function listar_profesores($Fjson = true)
    {
        if ($Fjson) {
            return json_encode(listar($this->id, "profesor"));
        } else {
            return listar($this->id, "profesor");
        }
    }

    function listar_estudiantes_all($Fjson = true, $habilitados = 1)
    {
        if ($Fjson) {
            return json_encode(listar_all('estudiante', $habilitados));
        } else {
            return listar_all('estudiante', $habilitados);
        }
    }

    function listar_profesores_all($Fjson = true)
    {

        if ($Fjson) {
            return json_encode(listar_all("profesor"));
        } else {
            return listar_all("profesor");
        }
    }

    function listar_carga_profesores()
    {

        return json_encode(listar_carga_usuarios($this->id, "profesor"));
    }

    function listar_carga_coordinadores()
    {

        return json_encode(listar_carga_usuarios($this->id, "coordinador"));
    }

    function listar_coordinadores($Fjson = true)
    {
        if ($Fjson) {
            return json_encode(listar($this->id, "coordinador"));
        } else {
            return listar($this->id, "coordinador");
        }
    }

    function listar_restringidos($Fjson = true)
    {
        if ($Fjson) {
            return json_encode(listar($this->id, "restringido"));
        } else {
            return listar($this->id, "restringido");
        }
    }

    function listar_administradores($Fjson = true)
    {
        if ($Fjson) {
            return json_encode(listar($this->id, "administrador"));
        } else {
            return listar($this->id, "administrador");
        }
    }

    function cantidad_activado()
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT COUNT(pin) cantidad FROM pines P LEFT JOIN cursos C ON P.curso = C.id WHERE institucion = ? AND año = 2020", array($this->id));
        return $reg['cantidad'];
    }

    function personalizacion($propiedad, $usuario = null)
    {
        global $BaseD;
        if (is_null($usuario)) {
            switch ($propiedad) {
                case 'css':
                    $valor = '/css/theme2017.css';
                    break;
                case 'logo_sie':
                    $valor = 'images/logosie2016.png';
                    break;
                case 'bandera':
                    $valor = 'images/bandera-texto-newsie.png';
                    break;
                case 'clase_body':
                    $valor = 'sie2016';
                    break;
                case 'nombre':
                    $valor = $this->nombre();
                    break;
                case 'titulo':
                    $valor = 'SIE - ' . $this->nombre();
                    break;
                case 'correo-soporte':
                    $valor = 'solicitudesit@educar.com.co';
                    break;
                case 'favicon':
                    $valor = '/images/favicon.ico';
                    break;
                case 'logout':
                    $valor = 'http://localhost/sie';
                    break;
                case 'plataforma':
                    $valor = 'SIE';
                    break;
            }

            $reg = $BaseD->GetRow("SELECT valor FROM personalizacion WHERE propiedad = '$propiedad' AND institucion = ?", array($this->id));
            if (count($reg)) {
                $valor = $reg['valor'];
            }
        } else {
            $cole = new Institucion($_SESSION['idCol']);
            $plataforma = new Plataforma($cole->plataforma());

            if ($plataforma->es_saber()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_saber.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-saber.png';
                        break;
                    case 'clase_body':
                        $valor = 'bg_saber';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'Pruebas Saber - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/saber.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Saber';
                        break;
                    case 'plataforma':
                        $valor = 'TU SABER';
                        break;
                }
            } else if ($plataforma->es_comprende()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_comprende.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-newsie.png';
                        break;
                    case 'clase_body':
                        $valor = 'comprende';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'COMPRENDE - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Comprende';
                        break;
                    case 'plataforma':
                        $valor = 'SIE2017';
                        break;
                }
            } else if ($plataforma->es_guiandote()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_guiandote.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-newsie.png';
                        break;
                    case 'clase_body':
                        $valor = 'guiandote';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'GUIANDOTE - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Guiandote';
                        break;
                    case 'plataforma':
                        $valor = 'GUIANDOTE';
                        break;
                }
            } else if ($plataforma->es_diveraprende()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_diver_aprende.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-newsie.png';
                        break;
                    case 'clase_body':
                        $valor = 'd_aprende';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'DIVER APRENDE - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Aprende';
                        break;
                    case 'plataforma':
                        $valor = 'DIVERAPRENDE';
                        break;
                }
            } else if ($plataforma->es_newsie()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/newsietheme.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logosie2016.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-newsie.png';
                        break;
                    case 'clase_body':
                        $valor = 'newsie';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'NEW SIE - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Newsie';
                        break;
                    case 'plataforma':
                        $valor = 'NEWSIE';
                        break;
                }
            } else if ($plataforma->es_biblioteca()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_biblioteca.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-biblioteca.png';
                        break;
                    case 'clase_body':
                        $valor = 'bg_biblioteca';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'Biblioteca Digital - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/saber.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/bibliotecadigital';
                        break;
                    case 'plataforma':
                        $valor = 'Biblioteca Digital';
                        break;
                }
            } else if ($plataforma->es_educlass() && !$usuario->soy_preescolar()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_educlass.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-educlass.png';
                        break;
                    case 'clase_body':
                        $valor = 'educlass';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'EDUCLASS - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/educlass.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Educlass';
                        break;
                    case 'plataforma':
                        $valor = 'EDUCLASS';
                        break; /*
                 case 'css':
                 $valor = '/css/theme2017.css';
                 break;
                 case 'logo_sie':
                 $valor = 'images/logo_newsie.png';
                 break;
                 case 'bandera':
                 $valor = 'images/bandera-texto-newsie.png';
                 break;
                 case 'clase_body':
                 $valor = 'newsie';
                 break;
                 case 'nombre':
                 $valor = $this->nombre();
                 break;
                 case 'titulo':
                 $valor = 'SIE - '.$this->nombre();
                 break;
                 case 'correo-soporte':
                 $valor = 'solicitudesit@educar.com.co';
                 break;
                 case 'favicon':
                 $valor = '/images/favicon.ico';
                 break;
                 case 'logout':
                 $valor = 'http://sie.educar.com.co';
                 break;
                 case 'plataforma':
                 $valor = 'SIE';
                 break;*/
                }
            } else if (!$usuario->soy_preescolar()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/theme2017.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logosie2016.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-newsie.png';
                        break;
                    case 'clase_body':
                        $valor = 'sie2016';
                        break;
                    case 'nombre':
                        $valor = $this->nombre();
                        break;
                    case 'titulo':
                        $valor = 'SIE - ' . $this->nombre();
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/sie';
                        break;
                    case 'plataforma':
                        $valor = 'SIE';
                        break;
                }

                $reg = $BaseD->GetRow("SELECT valor FROM personalizacion WHERE propiedad = '$propiedad' AND institucion = ?", array($this->id));
                if (count($reg)) {
                    $valor = $reg['valor'];
                }
            } else if ($usuario->soy_preescolar()) {
                switch ($propiedad) {
                    case 'css':
                        $valor = '/css/template-pre.css';
                        break;
                    case 'logo_sie':
                        $valor = 'images/logo_sie-pre.png';
                        break;
                    case 'bandera':
                        $valor = 'images/bandera-texto-pre.png';
                        break;
                    case 'nombre':
                        $valor = $this->nombre;
                        break;
                    case 'titulo':
                        $valor = 'SIE Preschool - ' . $this->nombre;
                        break;
                    case 'correo-soporte':
                        $valor = 'solicitudesit@educar.com.co';
                        break;
                    case 'favicon':
                        $valor = '/images/favicon.ico';
                        break;
                    case 'logout':
                        $valor = 'http://localhost/Preschool';
                        break;
                    case 'plataforma':
                        $valor = 'SIE Preschool';
                        break;
                }
            }
        }
        return $valor;
    }

    function es_antigua()
    {
        return $this->es_antigua;
    }

    function tiene_preescolar()
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT id FROM cursos WHERE (grado = 'P' OR grado = 'PJ' OR grado = 'J'  OR grado = 'T' ) AND institucion = ?", array($this->id));
        if (count($reg)) {
            return true;
        } else {
            return false;
        }
    }

    function tiene_primaria()
    {
        global $BaseD;
        //$BaseD->debug = true;
        $reg = $BaseD->GetRow("SELECT id FROM cursos WHERE (grado >= 1 AND grado <= 5) AND institucion = ?", array($this->id));
        if (count($reg)) {
            return true;
        } else {
            return false;
        }
    }

    function tiene_bachillerato()
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT id FROM cursos WHERE grado >= 6 AND institucion = ?", array($this->id));
        if (count($reg)) {
            return true;
        } else {
            return false;
        }
    }

    function cambiar_nombre($nuevo)
    {
        global $BaseD, $PORTADAS_DIR;
        registro(__METHOD__, func_get_args(), $this);
        if ($BaseD->Execute("UPDATE instituciones SET nombre = ? WHERE id = ?", array($nuevo, $this->id()))) {
            if ($this->tiene_lms()) {
                $this->cambiar_nombre_lms($nuevo);
            } else {
                $ok = true;
            }
            $ok &= rename($PORTADAS_DIR . $this->nombre(), $PORTADAS_DIR . $nuevo);
            $this->nombre = $nuevo;
            $ok = true;

            return $ok;
        } else {
            return false;
        }
    }

    function cambiar_nombre_lms($nuevo)
    {
        global $ADODB_TYPE, $CHML_CONFIG;
        registro(__METHOD__, func_get_args(), $this);
        include "$CHML_CONFIG";
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');

        if ($BaseD->Execute("UPDATE course_category SET name = ? WHERE code = ?", array($nuevo . " / " . $this->ciudad, $this->id()))) {
            $rs = $BaseD->Execute("SELECT id, description FROM course WHERE category_code = ?", array($this->id()));
            $ok = true;
            while (!$rs->EOF) {

                $desc = str_replace($this->nombre(), $nuevo, $rs->fields[1]);
                $BaseD->Execute("UPDATE course SET description = ? WHERE id = ? ", array($desc, $rs->fields[0]));
                $BaseD->Execute("UPDATE c_tool_intro SET intro_text = ? WHERE c_id = ? and id = ? ", array('<h2 style="text-align: center;">Bienvenidos al ' . $desc . '</h2>', $rs->fields[0], "course_homepage"));
                $rs->MoveNext();
            }
        }
    }

    function buscar_grado($grado)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT id FROM cursos WHERE institucion = ? AND grado = ?", array($this->id(), $grado));
        return $reg['id'];
    }

    function reparador_usuarios_cursos_matriculas()
    {
        global $BaseD;
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR, $CUOTA_LMS_CURSO;
        $Global = $BaseD;
        //$Global->debug = true;
        include "$CHML_CONFIG";
        $LMS = NewADOConnection($ADODB_TYPE);
        $LMS->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $LMS->SetCharSet('utf8');
        //$LMS->debug = true;
        $listainstituciones = $this->listar_institucioines();
        //listado de colegios
        foreach ($listainstituciones as $id => $nombre) {
            $cole = new Institucion($id);
            //$grupos_materias = $cole->listar_grupos_materias();
            $profes = $cole->listar_profesores(false);
            $alumnos = $cole->listar_estudiantes(false);
            $coordinadores = $cole->listar_coordinadores(false);
            //$materias = $cole->listar_materias();
            //$cursos = $cole->listar_cursos(true, false, false);
            /*
            if(is_array($grupos_materias))
            {
             foreach($grupos_materias as $gm)
             {
              $curso = new Curso ((int)$gm->grupo);
              $asignatura = new Materia ($gm->materia);
              $nombre = $asignatura->nombre()." ".$curso->curso();

              //verifica si existe el curso
              if(!$cole->existe_curso_lms($gm->grupo."-".$gm->materia))
              {
            //crea curso
            $cole->crear_curso_en_LMS ($gm->grupo."-".$gm->materia, $nombre);
              }
              else
              {
            //elimina y repara herramientas de lso cursos
            $Ncurso = $curso->id_curso_lms($gm->materia);
            $LMS->Execute("DELETE FROM c_tool WHERE c_id = ?", array($Ncurso));

            if (stristr($nombre, 'Párvulos') === FALSE && stristr($nombre, 'PreJard') === FALSE && stristr($nombre, 'Jard') === FALSE && stristr($nombre, 'Transici') === FALSE )
            {
             $plataforma = new Plataforma($cole->plataforma());
             if($plataforma->es_educlass())
             {
              $theme = 'educlasstheme';
              $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
              (?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 7, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 8, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 9, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 10, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
              $array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso);

             }
             else
             {
              $theme = '';
              $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
              (?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 7, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 8, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 9, 'dropbox', 'dropbox/index.php', 'dropbox.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 10, 'group', 'group/group.php', 'group.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 11, 'chat', 'chat/chat.php', 'chat.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 12, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
              (?, 13, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 14, 'glossary', 'glossary/index.php', 'glossary.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
              (?, 15, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
              $array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso);

             }
            }
            else {
             $theme = 'siepresschool';
             $sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
             (?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
             (?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 4, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 5, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 6, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
             (?, 7, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 8, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 9, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
             (?, 10, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0);";
             $array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso, $Ncurso, $Ncurso, $Ncurso);

            }

            $LMS->Execute($sql_tools, $array_tools);
              }
             }
            }
             */
            if (is_array($alumnos)) {
                foreach ($alumnos as $alumno) {
                    $usuario = new Usuario($alumno["usuario"]);

                    //verifica si el usuario existe en el lms
                    if (!$usuario->existe_lms()) {
                        if ($cole->tiene_lms()) {
                            //se inscribe en un grupo
                            $usuario->inscribe_lms();

                            /*$objGRado = new Grado($usuario->id_grado());
                            $objCur = new Curso ($objGRado->primer_grupo());
                            $objCur->matricular($usuario->id());*/

                            echo "registrado con Éxito" . $usuario->usuario() . "<br>";
                        }
                    }
                    /*
                    if(!is_null($usuario->id_curso()))
                    {
                     $cur = new Curso($usuario->id_curso());
                     foreach($cur->listar_materias() AS $mate)
                     {
                      if(!$cur->existe_matricula_lms($mate, $usuario->id_lms()))
                      {
                    var_dump($mate);
                    echo "si";
                    $cur->matricular_lms($mate, $usuario->usuario());
                      }
                     }
                    }*/
                }
            }

            if (is_array($profes)) {
                foreach ($profes as $profe) {
                    $usuario = new Usuario($profe["usuario"]);

                    if (!$usuario->existe_lms()) {
                        if ($cole->tiene_lms()) {
                            $usuario->inscribe_lms();

                            echo "registrado con Éxito" . $usuario->usuario();
                        }
                    }
                    /*
                    $recordSet2 = $Global->Execute("SELECT grupo_materia FROM grupos_profesores WHERE profesor = ?", array($usuario->id()));

                    while (!$recordSet2->EOF) {
                     $rs = $Global->Execute ("SELECT grupo, materia FROM grupos_materias WHERE id = ?", array($recordSet2->fields['grupo_materia']));

                     while (!$rs->EOF) {
                      $cur = new Curso($rs->fields['grupo']);

                      if(!$cur->existe_matricula_lms($rs->fields['materia'], $usuario->id_lms()))
                      {
                    var_dump($rs->fields['materia']);
                    echo "si";
                    $cur->matricular_lms($rs->fields['materia'], $usuario->usuario(),1);
                      }

                      $rs->MoveNext();

                      echo "  info: $code <-". $usuario->id();
                     }

                     $recordSet2->MoveNext();
                    }*/
                }
            }

            if (is_array($coordinadores)) {
                foreach ($coordinadores as $coordinador) {
                    $usuario = new Usuario($coordinador["usuario"]);

                    if (!$usuario->existe_lms()) {
                        if ($cole->tiene_lms()) {
                            $usuario->inscribe_lms();

                            echo "registrado con Éxito" . $usuario->usuario();
                        }
                    }
                }
            }
        }
        /*
        $u = $Global->Execute("SELECT u.* FROM usuarios u INNER JOIN pines p ON (u.pin_creacion = p.pin) where p.creado_en >= '2015-09-01' AND u.rol = 4");
        while (!$u->EOF) {
         //se virifica si existen estudiantes sin matricular
         $g = $Global->GetRow("SELECT * FROM grupos_estudiantes WHERE estudiante = ?", array($u->fields['id']));
         if(!$g)
         {
          //se metriculan estudiantes en algun grupo
          $user = new Usuario($u->fields['usuario']);
          $objGRado = new Grado($user->id_grado());
          $objCur = new Curso ($objGRado->primer_grupo());
          $objCur->matricular($user->id());
         }
         $u->MoveNext();
        }*/

        // se verifican las relaciones y se reparan las que esten en null
        //$LMS->Execute("UPDATE course_rel_user r, course c SET r.c_id = c.id WHERE r.course_code = c.code and r.`c_id` IS NULL");

        /*
        //$u = $Global->Execute("SELECT u.* FROM usuarios u INNER JOIN pines p ON (LOWER(u.usuario) = LOWER(p.activado_por)) INNER JOIN grupos_estudiantes e on (u.id = e.estudiante) where p.creado_en < '2015-09-01' AND u.rol = 4 and u.institucion = 1031 and u.curso = p.curso");

        $u = $Global->Execute("SELECT usuario from usuarios WHERE rol = 4 AND id not IN (SELECT u.id FROM usuarios u INNER JOIN pines p on (u.usuario = p.activado_por) WHERE u.rol = 4)");

        while (!$u->EOF) {
         $user = new Usuario($u->fields['usuario']);
         $cur = new Curso($user->id_curso());

         //$cur->desmatricular($user->id());
         $user->borrar($u->fields['usuario']);

         $u->MoveNext();
        }*/
    }

    function existe_curso_lms($code)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $res = $BaseD->Execute("SELECT * FROM course WHERE code = ?", array($code));
        if ($res->RecordCount() > 0) {
            return (true);
        } else {
            return (false);
        }
    }

    /*	function repara_cursos_lms () {
    global $ADODB_TYPE, $CHML_CONFIG;

    registro(__METHOD__, func_get_args(), $this);
    require "$CHML_CONFIG";

    $BaseD = NewADOConnection($ADODB_TYPE);
    $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
    $BaseD->SetCharSet('utf8');

    $rs = $BaseD->Execute("SELECT id, title FROM course WHERE category_code = ?", array($this->id()));
 			while (!$rs->EOF) {
 				$nombre = $rs->fields['title'];
 				$Ncurso = $rs->fields['id'];

 				if (stristr($nombre, 'Párvulos') === FALSE && stristr($nombre, 'PreJard') === FALSE && stristr($nombre, 'Jard') === FALSE && stristr($nombre, 'Transici') === FALSE ) {

					$insti = new Institucion($this->id);
					$plataforma = new Plataforma($insti->plataforma());
					if($plataforma->es_educlass())
					{
						$theme = 'educlasstheme';
						$sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
						(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 7, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 8, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 9, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
						$array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso);

					}
					else
					{
						$theme = '';
						$sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
						(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 4, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 5, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 6, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 7, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 8, 'forum', 'forum/index.php', 'forum.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 9, 'dropbox', 'dropbox/index.php', 'dropbox.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 10, 'group', 'group/group.php', 'group.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 11, 'chat', 'chat/chat.php', 'chat.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 12, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
						(?, 13, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 14, 'glossary', 'glossary/index.php', 'glossary.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
						(?, 15, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0)";
						$array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso);
					}
 				}
 				else {
 					$theme = 'siepresschool';
 					$sql_tools = "INSERT INTO c_tool (c_id, id, name, link, image, visibility, admin, address, added_tool, target, category, session_id) VALUES
 					(?, 1, 'course_description', 'course_description/', 'info.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 2, 'calendar_event', 'calendar/agenda.php', 'agenda.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
 					(?, 3, 'document', 'document/document.php', 'folder_document.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 4, 'link', 'link/link.php', 'links.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 5, 'announcement', 'announcements/announcements.php', 'valves.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 6, 'notebook', 'notebook/index.php', 'notebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0),
 					(?, 7, 'gradebook', 'gradebook/index.php', 'gradebook.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 8, 'quiz', 'exercice/exercice.php', 'quiz.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 9, 'learnpath', 'newscorm/lp_controller.php', 'scorms.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'authoring', 0),
 					(?, 10, 'student_publication', 'work/work.php', 'works.gif', 1, '0', 'squaregrey.gif', 0, '_self', 'interaction', 0);";
 					$array_tools = array($Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso,$Ncurso, $Ncurso, $Ncurso, $Ncurso);
 				}

 				$BaseD->Execute ( $sql_tools, $array_tools );
 				$rs->MoveNext();
 			}
    }*/
}

class Curso
{
    protected $id;
    protected $grado;
    protected $institucion;
    protected $grupo;
    protected $id_grado;
    function __construct($id = -1)
    {
        global $BaseD;
        if ($id <> -1 && !empty($id) && $id) {
            $sql = "SELECT global_sie.grupos.grupo, global_sie.cursos.id FROM global_sie.grupos INNER JOIN global_sie.cursos ON global_sie.grupos.curso = global_sie.cursos.id WHERE global_sie.grupos.id = ?";
            $reg = $BaseD->GetRow($sql, array($id));
            $objGrado = new Grado($reg['id']);
            $this->institucion = $objGrado->institucion();
            $this->grado = $objGrado->gradoL();
            $this->id = $id;
            $this->grupo = $reg['grupo'];
            $this->id_grado = $reg['id'];
        }
    }

    function id()
    {
        return $this->id;
    }

    function institucion()
    {
        return $this->institucion;
    }

    function curso()
    {
        return $this->grado . $this->grupo;
    }

    function grupo()
    {
        return $this->grupo;
    }

    function crear($grado, $curso, $institucion = -1)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        //$BaseD->debug = true;
        /*if ( $institucion <> -1 ) {
         $reg = $BaseD->GetRow( "SELECT id FROM cursos WHERE institucion = $institucion AND grado = '$grado' " );
         if ( $reg !== false ) {
          $grado = $reg['id'];
         }
         else
          return false;
        }*/
        //var_dump($grado);
        $sql = "INSERT INTO grupos (curso, grupo) VALUES (?, ? )";
        if ($res = $BaseD->Execute($sql, array($grado, $curso)) !== false) {
            $IdGrado = $BaseD->Insert_ID();
            $newcurso = new Curso($IdGrado);
            $col = new Institucion($institucion);

            foreach ($newcurso->listar_materias() as $materia) {
                $col->asociar_materia($grado, $materia);
            }

            return true;
        } else {
            $e = ADODB_Pear_Error();
            if ($e->code == 1062) {
                echo "Este curso ya existe.<br/>";
            }

            return false;
        }
    }

    function eliminar_curso()
    {
        global $BaseD;
        //$BaseD->debug = true;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        $BaseD->Execute("DELETE FROM grupos_estudiantes WHERE grupo = ?", array($this->id));

        if ($BaseD->Execute("DELETE FROM grupos WHERE id=?", array($this->id))) {
            return (true);
        } else {
            return (false);
        }
    }

    function listar_materias($vista = false)
    {
        global $BaseD;

        $lista = array();
        if ($vista) {
            $res = $BaseD->Execute("SELECT M.id, M.materia FROM grupos_materias GM LEFT JOIN grupos G ON GM.grupo = G.id LEFT JOIN materias M ON GM.materia = M.id WHERE curso = ? ORDER BY M.materia", array($this->id_grado));
            while (!$res->EOF) {
                $lista[$res->fields['id']] = $res->fields['materia'];
                $res->MoveNext();
            }
        } else {
            $res = $BaseD->Execute("SELECT materia FROM grupos_materias GM LEFT JOIN grupos G ON GM.grupo = G.id WHERE curso = ?", array($this->id_grado));
            while (!$res->EOF) {
                $lista[] = $res->fields['materia'];
                $res->MoveNext();
            }
        }

        @asort($lista);
        return $lista;
    }

    function matriculados($sin = false, $profesor = false, $materia = '', $xusuario = false, $coordinador = false)
    {
        global $BaseD;
        //	$BaseD->debug = true;
        $lista = array();
        $param = array();
        if ($profesor) {
            if ($sin) {
                if ($coordinador) {
                    $sql = "SELECT usuario FROM (SELECT U.usuario, U.id FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = 'coordinador' GROUP BY usuario) T LEFT JOIN (SELECT profesor, grupo FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GM.id = GP.grupo_materia WHERE grupo = ? AND materia = ?) P ON T.id = P.profesor WHERE P.grupo IS NULL";
                } else {
                    $sql = "SELECT usuario FROM (SELECT U.usuario, U.id FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = 'profesor' GROUP BY usuario) T LEFT JOIN (SELECT profesor, grupo FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GM.id = GP.grupo_materia WHERE grupo = ? AND materia = ?) P ON T.id = P.profesor WHERE P.grupo IS NULL";
                }
                $param[] = $this->institucion;
                $param[] = $this->id;
                $param[] = $materia;
            } else {
                $param[] = $this->id;
                $param[] = $materia;
                if (!$coordinador) {
                    $sql = "SELECT usuario FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GP.grupo_materia = GM.id LEFT JOIN usuarios U ON U.id = profesor WHERE grupo = ? AND materia = ? AND U.rol = 3";
                } else {
                    $sql = "SELECT usuario FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GP.grupo_materia = GM.id LEFT JOIN usuarios U ON U.id = profesor WHERE grupo = ? AND materia = ? AND U.rol = 2";
                }
            }
        } else {
            if ($sin) {
                $param[] = $this->grado();
                $sql = "SELECT usuario
					FROM usuarios U
						LEFT JOIN cursos C ON U.curso = C.id
						LEFT JOIN grupos_estudiantes GE ON GE.estudiante = U.id
					WHERE GE.id IS NULL AND U.habilitado AND C.id = ? AND U.rol = 4";
            } else {
                $param[] = $this->id;
                $sql = "SELECT usuario
					FROM grupos_estudiantes GE
						LEFT JOIN usuarios U ON GE.estudiante = U.id
					WHERE GE.grupo = ? AND U.habilitado";
            }
        }

        $res = $BaseD->Execute($sql, $param);
        while (!$res->EOF) {
            $user = new Usuario($res->fields['usuario']);
            if ($xusuario) {
                $lista[$user->id() . " "] = $user->usuario();
            } else {
                $lista[$user->id() . " "] = $user->apellidos() . " " . $user->nombres() . " (" . $user->usuario() . ")";
            }

            $res->MoveNext();
        }

        asort($lista);
        //@asort($lista, SORT_STRING | SORT_FLAG_CASE | SORT_NATURAL);
        return $lista;
    }


    function admin_matriculados($sin = false, $rol, $materia = '', $xusuario = false)
    {
        global $BaseD;
        //	$BaseD->debug = true;

        $param = array();
        if ($sin) {
            $sql = "SELECT usuario FROM (SELECT U.usuario, U.id FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE R.rol = '$rol' GROUP BY usuario) T LEFT JOIN (SELECT profesor, grupo FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GM.id = GP.grupo_materia WHERE grupo = ? AND materia = ?) P ON T.id = P.profesor WHERE P.grupo IS NULL";

            $param[] = $this->id;
            $param[] = $materia;
        } else {
            $param[] = $this->id;
            $param[] = $materia;
            $rol = ($rol == 'administrador' ? 1 : 5);
            $sql = "SELECT usuario FROM grupos_profesores GP LEFT JOIN grupos_materias GM ON GP.grupo_materia = GM.id LEFT JOIN usuarios U ON U.id = profesor WHERE grupo = ? AND materia = ? AND U.rol = $rol";
        }

        $res = $BaseD->Execute($sql, $param);
        while (!$res->EOF) {
            $user = new Usuario($res->fields['usuario']);
            if ($xusuario) {
                $lista[$user->id()] = $user->usuario();
            } else {
                $lista[$user->id()] = $user->apellidos() . " " . $user->nombres() . " (" . $user->usuario() . ")";
            }

            $res->MoveNext();
        }

        @asort($lista);
        return $lista;
    }


    function matricular($usuario, $estudiante = true, $materia = '')
    {
        // OJO De estudiante es ID
        global $BaseD;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        //$BaseD->debug = true;
        $control = true;
        $j = $BaseD->GetRow("SELECT usuario FROM usuarios WHERE id = ?", array($usuario));
        if (!$j) {$j = $usuario;}
        if ($estudiante) {
            if ($this->id() != null) {
                $res = $BaseD->Execute('INSERT INTO grupos_estudiantes (grupo, estudiante) VALUES (?, ?)', array($this->id(), $usuario));
            } else {
                $res = false;
            }
            //var_dump($res);

            if ($res) {

                $col = new Institucion($this->institucion);
                if ($col->tiene_lms()) {
                    foreach ($this->listar_materias() as $materia) {
                        $control &= $res2 = $this->matricular_lms($materia, $j['usuario']);
                    }
                }
            }
        } else {
            $reg = $BaseD->GetRow('SELECT id FROM grupos_materias WHERE grupo = ? AND materia = ?', array($this->id(), $materia));
            $res = $BaseD->Execute('INSERT INTO grupos_profesores (profesor, grupo_materia) VALUES (?, ?)', array($usuario, $reg['id']));
            $control &= $this->matricular_lms($materia, $j['usuario'], 1);
        }

        // 		$BaseD->debug = false;
        return $control;
    }

    function id_curso_lms($materia)
    {
        global $ADODB_TYPE, $CHML_CONFIG;
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');

        $x = $BaseD->GetRow("SELECT id FROM course WHERE code = ?", array($this->id() . "-" . $materia));

        if ($x) {
            return ($x['id']);
        } else {
            return (false);
        }
    }

    function existe_matricula_lms($materia, $usuario)
    {
        global $ADODB_TYPE, $CHML_CONFIG;
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;

        $Ncurso = $this->id_curso_lms($materia);

        if ($BaseD->GetRow('SELECT * FROM course_rel_user WHERE user_id = ? AND c_id = ?', array($usuario, $Ncurso))) {
            return (true);
        } else {
            return (false);
        }
    }

    function matricular_lms($materia, $usuario, $rol = 5)
    {
        global $ADODB_TYPE, $CHML_CONFIG;
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $us = new Usuario($usuario);

        $x = $BaseD->GetRow("SELECT id FROM course WHERE code = ?", array($this->id() . "-" . $materia));
        $Ncurso = $x['id'];
        if ($Ncurso) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
            $y = $BaseD->GetRow("SELECT user_id FROM user WHERE username = ?", array($usuario));
            if ($y["user_id"] != null) {
                if (!$this->existe_matricula_lms($materia, $y["user_id"])) {
                    $order = $BaseD->GetRow('select count(*) total from course_rel_user where user_id = ?', array($y["user_id"]));
                    $order = $order['total'] + 1;
                    $BaseD->Execute(
                        'INSERT INTO course_rel_user (user_id, status, is_tutor, sort, user_course_cat, relation_type, legal_agreement, c_id) VALUES (?, ?, 0, ?, 0, 0, NULL, ?)',
                        array($y["user_id"], $rol, $order, $Ncurso)
                    );
                }
            } else {
                $us->inscribe_lms();
                $y = $BaseD->GetRow("SELECT user_id FROM user WHERE username = ?", array($usuario));
                if ($y["user_id"] != null) {
                    if (!$this->existe_matricula_lms($materia, $y["user_id"])) {
                        $order = $BaseD->GetRow('select count(*) total from course_rel_user where user_id = ?', array($y["user_id"]));
                        $order = $order['total'] + 1;
                        $BaseD->Execute(
                            'INSERT INTO course_rel_user (user_id, status, is_tutor, sort, user_course_cat, relation_type, legal_agreement, c_id) VALUES (?, ?, 0, ?, 0, 0, NULL, ?)',
                            array($y["user_id"], $rol, $order, $Ncurso)
                        );
                    }
                }
            }
        }
        $BaseD->Close();
    }

    function curso_lms_invisible($materia, $visible = 4)
    {
        //$visible = 4 Invisible
        //$visible = 1 visible
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $BaseD->Execute("UPDATE course SET visibility = ? WHERE code = ?", array($visible, $this->id() . "-" . $materia));
        $BaseD->Close();
    }

    function desmatricular($usuario, $estudiante = true, $materia = '')
    {
        // OJO De estudiante es ID
        global $BaseD;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        // 		$BaseD->debug = true;
        $control = true;
        $j = $BaseD->GetRow("SELECT usuario FROM usuarios WHERE id = ?", array($usuario));
        if ($estudiante) {
            $res = $BaseD->Execute('DELETE FROM grupos_estudiantes WHERE grupo = ? AND estudiante = ?', array($this->id, $usuario));
            if ($res) {
                $col = new Institucion($this->institucion);
                if ($col->tiene_lms()) {
                    foreach ($this->listar_materias() as $materia) {
                        $control &= $res2 = $this->desmatricular_lms($materia, $j['usuario']);
                    }
                }
            }
        } else {
            if ($materia != 'ALL') {
                $reg = $BaseD->GetRow('SELECT id FROM grupos_materias WHERE grupo = ? AND materia = ?', array($this->id, $materia));
                $res = $BaseD->Execute('DELETE FROM grupos_profesores WHERE profesor = ? AND grupo_materia = ?', array($usuario, $reg['id']));
            } else {
                $res = $BaseD->Execute('DELETE FROM grupos_profesores WHERE profesor = ? ', array($usuario));
            }
            $col = new Institucion($this->institucion);
            if ($col->tiene_lms()) {
                $control &= $this->desmatricular_lms($materia, $j['usuario']);
            }
        }

        // 		$BaseD->debug = false;
        return $control;
    }

    function desmatricular_lms($materia, $usuario)
    {
        global $ADODB_TYPE, $CHML_CONFIG;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);

        $y = $BaseD->GetRow("SELECT user_id FROM user WHERE username = ?", array($usuario));

        $BaseD->SetCharSet('u<tf8');
        if ($materia != 'ALL') {
            $j = $BaseD->GetRow("SELECT id FROM course WHERE code = ?", array($this->id . "-" . $materia));
            $BaseD->Execute('DELETE FROM course_rel_user WHERE c_id = ? AND user_id = ?', array($j['id'], $y["user_id"]));
        } else {
            $BaseD->Execute('DELETE FROM course_rel_user WHERE user_id = ?', array($y["user_id"]));
        }
        $BaseD->Close();
    }

    function grado()
    {
        return $this->id_grado;
    }

    function gradoGR()
    {
        return $this->grado;
    }

    function cambiar_nombre_curso($nombre)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $BaseD;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        include "$CHML_CONFIG";

        $BaseDCHML = NewADOConnection($ADODB_TYPE);
        $BaseDCHML->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseDCHML->SetCharSet('utf8');

        $nuevo = $this->gradoGR() . $nombre;
        $rs = $BaseDCHML->Execute("SELECT id, description, title FROM course WHERE code LIKE ?", array($this->id() . "-%"));
        $ok = true;
        while (!$rs->EOF) {

            $desc = str_replace($this->curso(), $nuevo, $rs->fields[1]);
            $title = str_replace($this->curso(), $nuevo, $rs->fields[2]);
            $BaseDCHML->Execute("UPDATE course SET description = ?, title = ? WHERE id = ? ", array($desc, $title, $rs->fields[0]));
            $BaseDCHML->Execute("UPDATE c_tool_intro SET intro_text = ? WHERE c_id = ? and id = ? ", array('<h2 style="text-align: center;">Bienvenidos al ' . $desc . '</h2>', $rs->fields[0], "course_homepage"));
            $rs->MoveNext();
        }

        if ($BaseD->Execute("UPDATE grupos SET grupo = ? WHERE id = ? ", array($nombre, $this->id()))) {
            return (true);
        } else {
            return (false);
        }
    }
}

class Grado
{
    protected $grado;
    protected $gradoNL;
    protected $institucion;

    public function __construct($id)
    {
        global $BaseD;

        $reg = $BaseD->GetRow("SELECT institucion, grado FROM cursos WHERE id = ?", array($id));
        $this->grado = $id;
        $this->gradoNL = (isset($reg['grado']) != "") ? $reg['grado'] : null;
        $this->institucion = (isset($reg['institucion']) != "") ? $reg['institucion'] : null;
    }

    public function institucion()
    {
        return $this->institucion;
    }

    public function id()
    {
        return $this->grado;
    }

    public function es_preescolar()
    {
        if ($this->gradoNL == 'P' || $this->gradoNL == 'PJ' || $this->gradoNL == 'J' || $this->gradoNL == 'T') {
            return true;
        } else {
            return false;
        }
    }

    public function es_meli()
    {
        if ($this->gradoNL == 'M') {
            return true;
        } else {
            return false;
        }
    }

    public function gradoNL()
    {
        return $this->gradoNL;
    }

    public function gradoL()
    {
        switch ($this->gradoNL()) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
                $ret = $this->gradoNL();
                break;
            case 'P':
                $ret = 'Párvulos ';
                break;
            case 'PJ':
                $ret = 'PreJardín ';
                break;
            case 'J':
                $ret = 'Jardín ';
                break;
            case 'T':
                $ret = 'Transición ';
                break;
            case 'M':
                $ret = 'Meli ';
                break;
            case 'PS':
                $ret = 'PruebasSaber ';
                break;
            case 'TD':
                $ret = 'TextosDigitales ';
                break;
            default:
                $ret = '';
                break;
        }

        return $ret;
    }

    public function gradoPS()
    {
        switch ($this->gradoNL()) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
                $ret = $this->gradoNL();
                break;
            case 'P':
                $ret = 'PV';
                break;
            case 'PJ':
                $ret = 'Prejardin';
                break;
            case 'J':
                $ret = 'Jardin';
                break;
            case 'T':
                $ret = 'Transicion';
                break;
        }

        return $ret;
    }

    function primer_grupo()
    {
        global $BaseD;

        //	$BaseD->debug = true;

        $reg = $BaseD->GetRow('SELECT id FROM grupos WHERE curso = ? ORDER BY grupo LIMIT 1', array($this->grado));

        return $reg['id'];
    }

    function listar_cursos()
    {
        global $BaseD;

        $res = $BaseD->Execute('SELECT id, grupo FROM grupos WHERE curso = ? ORDER BY grupo', array($this->grado));

        $lista = array();
        while (!$res->EOF) {
            $lista[$res->fields['id']] = $this->gradoL() . $res->fields['grupo'];
            $res->MoveNext();
        }

        return $lista;
    }

    function asociacion_materias()
    {
        global $BaseD;

        $res = $BaseD->Execute("SELECT materia FROM grupos_materias GM LEFT JOIN grupos G ON GM.grupo = G.id WHERE G.curso = ?", array($this->grado));
        $lista = array();
        while (!$res->EOF) {
            $lista[] = $res->fields['materia'];
            $res->MoveNext();
        }

        return $lista;
    }

    function pines_activados()
    {
        global $BaseD, $AÑO_ACTIVO;

        // 		$BaseD->debug = true;
        $sql_generados = "SELECT COUNT(*) num FROM `pines` WHERE año = ? AND curso = ?";
        $sql_activados = "SELECT COUNT(*) num FROM `pines` WHERE año = ? AND curso = ? AND activado_por IS NOT NULL";
        $data = array($AÑO_ACTIVO, $this->id());

        $reg = $BaseD->GetRow($sql_generados, $data);
        $regreso['generados'] = $reg['num'];
        $reg = $BaseD->GetRow($sql_activados, $data);
        $regreso['activados'] = $reg['num'];

        // 		$BaseD->debug = false;
        return $regreso;
    }
}

class Usuario
{
    protected $id;
    protected $correo;
    protected $correop;
    protected $idInstitucion;
    protected $apellidos;
    protected $apellidosp;
    protected $nombres;
    protected $nombresp;
    protected $usuario;
    protected $clave;
    protected $telefono;
    protected $telefonop;
    protected $grado;
    protected $curso;
    protected $puntos;
    protected $id_grado;
    protected $id_curso;
    protected $habilitado;
    protected $pago;
    protected $pin;
    protected $administrador = false, $restringido = false, $coordinador = false, $profesor = false, $estudiante = false;
    protected $flag_preschool = false;
    protected $flag_meli = false;

    function __construct($usuario = '', $institucion = -1)
    {
        global $BASE_DN, $BaseD, $CHML_CONFIG, $SIE_PREFIX;
        date_default_timezone_set('America/Bogota');
        if (!isset($BASE_DN)) {
            include '/var/www/Front/config.inc.php';
            $BaseD = NewADOConnection($ADODB_TYPE);
            $BaseD->Connect($DB_HOST, $DB_USER, $DB_PASS, $DB_DB);
            $BaseD->SetCharSet('utf8');
        }

        // 		if ($_SERVER['REMOTE_ADDR'] == '190.85.103.210')
        // 			$BaseD->debug= true;

        if (!empty($usuario) && $usuario != null) {
            $ldap = conectar_ldap();
            $sr = ldap_read($ldap, "uid=$usuario,$BASE_DN", "(objectClass=*)", array("sn", "givenName", "mail", "mobile", "cn"));

            $x = $BaseD->GetRow("SELECT R.rol, U.id, U.curso, U.pin_creacion, clave, institucion, habilitado, pago, puntos FROM usuarios AS U LEFT JOIN roles AS R ON U.rol = R.id WHERE usuario=?", array($usuario));
            // 			$BaseD->debug = false;
            $info = ldap_get_entries($ldap, $sr);

            if ($info["count"] > 0) {
                $this->usuario = $usuario;
                $this->correo = $info[0]['mail'][0];
                $this->correop = (isset($info[0]['mail'][1]) != "") ? $info[0]['mail'][1] : $info[0]['mail'][0];
                $this->apellidos = $info[0]['sn'][0];
                $this->nombres = $info[0]['givenname'][0];
                $this->telefono = (isset($info[0]['mobile'][0]) != "") ? $info[0]['mobile'][0] : null;
                $this->telefonop = (isset($info[0]['mobile'][0]) != "") ? $info[0]['mobile'][0] : null;
                $this->id = $x['id'];
                $this->clave = $x['clave'];
                $this->idInstitucion = $x['institucion'];
                $this->habilitado = $x['habilitado'];
                $this->pago = $x['pago'];
                $this->nombresp = (isset($info[0]['cn'][1]) != "") ? $info[0]['cn'][1] : $info[0]['cn'][0];
                $this->puntos = $x['puntos'];
                $this->pin = $x['pin_creacion'];

                $objGrado = new Grado($x['curso']);
                $this->grado = $objGrado->gradoL();
                $this->id_grado = $x['curso'];
                $this->flag_preschool = $objGrado->es_preescolar();
                $this->flag_meli = $objGrado->es_meli();

                if ($x !== false) {
                    switch ($x['rol']) {
                        case 'administrador':
                            $this->administrador = true;
                            break;
                        case 'restringido':
                            $this->restringido = true;
                            break;
                        case 'coordinador':
                            $this->coordinador = true;
                            break;
                        case 'profesor':
                            $this->profesor = true;
                            break;
                        case 'estudiante':
                            $this->estudiante = true;
                            break;
                    }
                }
            } else {
                $this->id = -100;
            }
        } elseif ($institucion <> -1) {
            $this->idInstitucion = $institucion;
        }

        if (!isset($_SESSION['idCol']) || empty($_SESSION['idCol']))
            $_SESSION['idCol'] = $this->idInstitucion;

        // $int = new institucion($_SESSION['idCol']);

        //var_dump($_SESSION);
        if ($this->my_session() != null)
            if (!isset($_SESSION['sie']))
                $_SESSION[$this->my_session()] = 1;
    }

    function registar_en_grupo($usuario, $gp)
    {
        global $BASE_DN;

        if (!empty($usuario)) {
            $ldap = conectar_ldap(1);
            //$sr=ldap_read($ldap, "uid=$usuario,$BASE_DN", "(objectClass=posixAccount)", array("sn", "givenName", "mail", "mobile"));

            $sr = ldap_read($ldap, "cn=$gp,$BASE_DN", "(objectClass=posixGroup)", array("memberUid"));

            $info = ldap_get_entries($ldap, $sr);

            if ($info["count"] > 0) {

                $n = (count($info[0]['memberuid']) - 1);

                $info[0]['memberuid'][$n] = $usuario;


                $grupo2['memberUid'] = array();
                $grupo2 = array_merge_recursive($grupo2, array('memberUid' => $info[0]['memberuid']));

                unset($grupo2["memberUid"]["count"]);
                if (ldap_modify($ldap, "cn=$gp,$BASE_DN", $grupo2)) {
                    return (true);
                } else {
                    return (false);
                }
            } else {
                $grupo = array();

                $p = new Plataforma("", $gp);
                $grupo['cn'] = $p->nombre();
                $grupo['gidNumber'] = $p->id();
                $grupo['memberUid'][0] = $usuario;
                $grupo['objectClass'][0] = "posixGroup";
                $grupo['objectClass'][1] = "top";
                var_dump($p->nombre());
                $dn = "cn=" . $p->nombre() . ",$BASE_DN";
                if (ldap_add($ldap, $dn, $grupo)) {
                    return (true);
                } else {
                    return (false);
                }
            }
        }
    }

    function crear($usuario, $nombres, $apellidos, $correo, $passwd, $rol, $movil, $quien, $pin = null, $grado = 'NULL', $nombresp = null, $apellidosp = null, $correop = null, $movilp = null, $cursom = null)
    {
        global $BaseD, $BASE_DN;
        switch ($rol) {
            case 'administrador':
                $this->administrador = true;
                break;
            case 'restringido':
                $this->restringido = true;
                break;
            case 'coordinador':
                $this->coordinador = true;
                break;
            case 'profesor':
                $this->profesor = true;
                break;
            case 'estudiante':
                $this->estudiante = true;
                break;
        }

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        $usuario = trim(strtolower($usuario));
        $nombres = trim($nombres);
        $apellidos = trim($apellidos);
        $correo = trim($correo);
        $correop = trim($correop);
        $nombresp = trim($nombresp);
        $apellidosp = trim($apellidosp);

        $nombres = mb_convert_case($nombres, MB_CASE_TITLE, "UTF-8");
        $apellidos = mb_convert_case($apellidos, MB_CASE_TITLE, "UTF-8");
        $usuario = mb_convert_case($usuario, MB_CASE_LOWER, "UTF-8");
        $nombresp = mb_convert_case($nombresp, MB_CASE_TITLE, "UTF-8");
        $apellidosp = mb_convert_case($apellidosp, MB_CASE_TITLE, "UTF-8");

        $Rolid = $BaseD->GetRow("SELECT id FROM roles WHERE rol = '$rol'");
        $rol = $Rolid['id'];

        $this->habilitado = 1;

        if($quien == "EducarVirtual"){
            $this->idInstitucion = 1982;
        }else{
            if (!empty($pin)) {
                $objPin = new Pin($pin);
                $grado = $objPin->grado();
                $this->idInstitucion = $objPin->institucion();
            } else {
                $this->idInstitucion = $_SESSION['idCol'];
            }

        }

        $clave = base64_encode($passwd);

        if (!empty($grado)) {
            $sql_crear = "INSERT INTO usuarios (usuario, clave, institucion, rol, curso, creado_por, creado_en, pin_creacion, habilitado)
				VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, 1)";
            $valores = array($usuario, $clave, $this->idInstitucion, $rol, $grado, $quien, $pin);
        } else {
            $sql_crear = "INSERT INTO usuarios (usuario, clave, institucion, rol, creado_por, creado_en, pin_creacion, habilitado)
				VALUES (?, ?, ?, ?, ?, NOW(), ?, 1)";
            $valores = array($usuario, $clave, $this->idInstitucion, $rol, $quien, $pin);
        }
        $res = $BaseD->Execute($sql_crear, $valores);
        //var_dump($res);
        if ($res) {
            $this->id = $BaseD->Insert_ID();
            $this->correo = $correo;
            $this->correop = $correop;
            $this->apellidos = $apellidos;
            $this->nombres = $nombres;
            $this->nombresp = $nombresp . " " . $apellidosp;
            $this->usuario = $usuario;
            $this->id_grado = $grado;
            $objGrado = new Grado($grado);
            $this->flag_preschool = $objGrado->es_preescolar();
            $this->grado = $objGrado->gradoL();
            $ldap = conectar_ldap(1);
            $colegio = new Institucion((int) $this->idInstitucion);
            $user = array();
            $user['cn'][0] = $this->nombres . " " . $this->apellidos;
            if (($this->nombres . " " . $this->apellidos) != ($this->nombresp) && $this->nombresp != null) {
                $user['cn'][1] = $this->nombresp;
            }

            $user['gidNumber'] = $this->idInstitucion;
            $user['givenName'][0] = $this->nombres;
            $user['homeDirectory'] = "/home/users/" . $this->usuario;
            $user['mail'][0] = $this->correo;
            if ($this->correo != $this->correop && $this->correop != null) {
                $user['mail'][1] = $this->correop;
            }

            if (!empty($movilp) && $movilp != null) {
                $this->telefonop = $movilp;
                $this->telefono = $movilp;
                $user['mobile'][0] = $movilp;
            } else if (!empty($movil) && $movil != null) {
                $this->telefono = $movil;
                $user['mobile'][0] = $movil;
            }

            if ($cursom != null && $cursom != "") {
                $this->id_curso = $cursom;
            }

            $user['objectClass'][0] = "inetOrgPerson";
            $user['objectClass'][1] = "posixAccount";
            $user['objectClass'][2] = "top";
            $user['sn'][0] = $this->apellidos;
            $user['uid'][0] = $this->usuario;
            $user['uidNumber'] = $this->id;
            $user['userPassword'] = '{MD5}' . base64_encode(pack('H*', md5($passwd)));
            $dn = "uid=" . $this->usuario . ",$BASE_DN";
            if (@ldap_add($ldap, $dn, $user)) {
                $a = $BaseD->Execute("SELECT * FROM instituciones WHERE nombre LIKE 'Saber_%' AND id = ?", array($this->idInstitucion));
                if ($a->RecordCount() > 0) {
                    $BaseD->Execute("INSERT INTO estado_pines_saber (pin) VALUES (?)", array($pin));
                }
                if ($quien != 'EducarVirtual') {
                    $this->bienvenida($passwd, $pin);
                    $this->matricular($this->idInstitucion);
                }
                return true;
            } else {
                //echo "no";
                $BaseD->Execute("DELETE FROM usuarios WHERE usuario = ?", array($usuario));
                return false;
            }
        } else {
            return false;
        }
    }

    function bienvenida($passwd, $pin = 0)
    {
        global $BaseD;
        $col = new Institucion($this->idInstitucion);
        // $msg_txt = "Estimado(a) " . $this->nombres . " " . $this->apellidos . ", el Grupo Editorial Educar se complace en darte la bienvenida a tu plataforma " . $col->personalizacion("plataforma", $this) . ".\r\nPara tu comodidad te recordamos que los datos de acceso que registraste son:\r\nUsuario: " . $this->usuario . "\r\nContraseña: $passwd. \r\nRecuerda que para ingresar a " . $col->personalizacion("plataforma", $this) . " lo puedes hacer a través de la dirección " . $col->personalizacion("logout", $this) . " \r\n
        // 	Cualquier inquietud o sugerencia la recibiremos gustosos en el correo " . $col->personalizacion("correo-soporte", $this) . ", o si lo prefieres puedes comunicarte también a nuestros números de soporte: \r\nDesde Bogotá 876 4301 y desde fuera de Bogotá 018000184315 o al celular 314 4217959\r\n\r\n
        // 	¡Bienvenido!";
        // $msg_html = "
        // 	<html>
        // 	<head>
        // 	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        // 	<title>Bienvenida a " . $col->personalizacion("plataforma", $this) . "</title>
        // 	</head>
        // 	<body>
        // 	Estimado(a) " . $this->nombres . " " . $this->apellidos . ", <BR>
        // 	<P align=\"justify\">el Grupo Editorial Educar se complace en darte la bienvenida a tu plataforma <A href=\"" . $col->personalizacion("logout", $this) . "\">" . $col->personalizacion("plataforma", $this) . "</A><BR><BR>
        // 	Para tu comodidad te recordamos que los datos de acceso que registraste son:<BR><BR>
        // 	<B>Usuario:</B> " . $this->usuario . "<BR>
        // 	<B>Contraseña:</B> $passwd<BR>
        // 	<BR><BR>Recuerda que para ingresar a " . $col->personalizacion("plataforma", $this) . " lo puedes hacer a través de la dirección <A href=\"" . $col->personalizacion("logout", $this) . "\">" . $col->personalizacion("logout", $this) . "</A><BR><BR>
        // 	Cualquier inquietud o sugerencia la recibiremos gustosos en el correo <A href=\"mailto:" . $col->personalizacion("correo-soporte", $this) . "\">" . $col->personalizacion("correo-soporte", $this) . "</A>, o si lo prefieres puedes comunicarte también a nuestros números de soporte: <br>Desde Bogotá 876 4301 y desde fuera de Bogotá 018000 184315 o al celular 314 4217959<BR><BR></P><P align=\"center\"><STRONG>¡Bienvenido!</P>";

        // enviar_correo($col->personalizacion("correo-soporte", $this), $this->correo, $this->nombres . " " . $this->apellidos, $msg_txt, $msg_html, "Bienvenido(a) a " . $col->personalizacion("plataforma", $this));

        if ($this->idInstitucion == 1810 || $this->idInstitucion == 1811) {
            dar_bienvenida_plataforma_personalizada($this->usuario, $passwd, "myclassflix");
        } else if ($this->idInstitucion == 1976 || $this->idInstitucion == 1982 || $this->idInstitucion == 1983) {
            dar_bienvenida_plataforma_personalizada($this->usuario, $passwd, "nuevosaber");
        } else {
            dar_bienvenida($this->usuario, $passwd);
        }

        $a = $BaseD->Execute("SELECT * FROM instituciones WHERE nombre LIKE 'Saber_%' AND id = ?", array($this->idInstitucion));
        if ($a->RecordCount() > 0) {
            $msg_txt = "Nuevo usuario activado: \r\n\r\nNombres:" . $this->nombres . " " . $this->apellidos . "\r\nUsuario:" . $this->usuario . "\r\nTeléfono:" . $this->telefonop() . "\r\nCorreo: " . $this->correo . "\r\nPin:" . $pin . "\r\nInstitución:" . $col->nombre();
            $msg_html = "
				<html>
				<head>
				<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				<title>Nuevo usuario activado:</title>
				</head>
				<body>
				Nuevo usuario activado: <BR><BR>Nombres:" . $this->nombres . " " . $this->apellidos . "<BR>Usuario:" . $this->usuario . "<BR>Teléfono:" . $this->telefonop() . "<BR>Correo: " . $this->correo . "<BR>Pin:" . $pin . "<BR>Institución:" . $col->nombre();

            enviar_correo($col->personalizacion("correo-soporte", $this), "noreply@educar.com.co", $this->nombres . " " . $this->apellidos, $msg_txt, $msg_html, "Nuevo usuario activado");
            enviar_correo($col->personalizacion("correo-soporte", $this), "noreply@educar.com.co", $this->nombres . " " . $this->apellidos, $msg_txt, $msg_html, "Nuevo usuario activado");
        }
    }

    function modificar($nombres = null, $apellidos = null, $correo = null, $passwd = null, $movil = null, $quien = null, $grado = null, $colegio = null, $usuario = null)
    {
        global $BASE_DN, $BaseD, $ADODB_TYPE, $CHML_CONFIG, $MDL_CONFIG, $DRPL_GALERIA_CONFIG;

        include $MDL_CONFIG;

        include "$CHML_CONFIG";

        include $DRPL_GALERIA_CONFIG;

        $LMS = NewADOConnection($ADODB_TYPE);
        $LMS->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);

        $BDMdl = NewADOConnection($CFG->dbtype);
        $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
        $BDMdl->SetCharSet('utf8');

        $BDdrpl = NewADOConnection($ADODB_TYPE);
        $BDdrpl->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BDdrpl->SetCharSet('utf8');

        $x = 1;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());

        $old = new Usuario($this->usuario);
        $nombres = ((!empty($nombres)) ? mb_convert_case($nombres, MB_CASE_TITLE, "UTF-8") : $old->nombres());
        $apellidos = ((!empty($apellidos)) ? mb_convert_case($apellidos, MB_CASE_TITLE, "UTF-8") : $old->apellidos());
        $correo = ((!empty($correo)) ? $correo : $old->correo());
        $movil = ((!empty($movil)) ? $movil : $old->telefono());

        $ldap = conectar_ldap(1);
        $user = array();
        $user['cn'][0] = $nombres . " " . $apellidos;
        $user['givenName'][0] = $nombres;
        $user['mail'][0] = $correo;
        if (!empty($movil)) {
            $user['mobile'] = $movil;
        }
        if (!empty($colegio)) {
            $user['gidnumber'] = $colegio;
        }
        $user['sn'][0] = $apellidos;
        if (!empty($passwd)) {
            $user['userPassword'] = '{MD5}' . base64_encode(pack('H*', md5($passwd)));
        }
        $dn = "uid=" . $old->usuario . ",$BASE_DN";

        if (ldap_modify($ldap, $dn, $user)) {
            $LMS->Execute("UPDATE user SET lastname = ?, firstname = ?, email = ?, email_canonical = ? WHERE username = ?", array($apellidos, $nombres, $correo, $correo, $this->usuario()));
            $BDMdl->Execute("UPDATE " . $CFG->prefix . "user SET lastname = ?, firstname = ?, email = ? WHERE username = ?", array($apellidos, $nombres, $correo, $this->usuario()));
            $BDdrpl->Execute("UPDATE users SET mail = ? WHERE name = ?", array($correo, $this->usuario()));
            // 			var_dump($colegio, $old->institucion() , $colegio);
            if (!empty($colegio) && $old->institucion() != $colegio) {
                $grado = (empty($grado) ? $old->id_grado() : $grado);
                $curso = new Curso($old->id_curso());
                $curso->desmatricular($this->id());
                $NColegio = new Institucion($colegio);
                $NGrado = new Grado($grado);
                $id_NGrado = $NColegio->buscar_grado($NGrado->gradoNL());
                $x &= $BaseD->Execute("UPDATE pines SET curso = ? WHERE activado_por = ?", array($id_NGrado, $this->usuario()));
                $x &= $BaseD->Execute("UPDATE usuarios SET institucion = ?, curso = ? WHERE usuario = ?", array($colegio, $id_NGrado, $this->usuario()));
            } elseif (!empty($grado) && $old->id_grado() != $grado) {
                $curso = new Curso($old->id_curso());
                $curso->desmatricular($this->id());
                $x &= $BaseD->Execute("UPDATE usuarios SET curso = ? WHERE usuario = ?", array($grado, $this->usuario));
                $x &= $BaseD->Execute("UPDATE pines SET curso = ? WHERE activado_por = ?", array($grado, $this->usuario));
            }

            if (!empty($movil)) {
                $this->telefono = $movil;
            }
            if (!empty($usuario)) {
                $LMS->Execute("UPDATE user SET username = ?, username_canonical=? WHERE username = ?", array($usuario, $usuario, $this->usuario()));
                $BaseD->Execute("UPDATE pines SET activado_por = ? WHERE activado_por = ?", array($usuario, $this->usuario()));
                $BaseD->Execute("UPDATE usuarios SET usuario = ? WHERE usuario = ?", array($usuario, $this->usuario()));
                $BaseD->Execute("UPDATE matriculasevsaber SET usuario = ? WHERE usuario = ?", array($usuario, $this->usuario()));
                $BDMdl->Execute("UPDATE " . $CFG->prefix . "user SET username = ? WHERE username = ?", array($usuario, $this->usuario()));
                $BDdrpl->Execute("UPDATE users SET name = ? WHERE name = ?", array($usuario, $this->usuario()));
                $BDdrpl->Execute("UPDATE cas_user SET cas_name = ?  WHERE cas_name = ?", array($usuario, $this->usuario()));
                $uid = $this->usuario();

                $sr = ldap_read($ldap, "uid=$uid,$BASE_DN", "(objectClass=*)", array("cn", "gidNumber", "givenName", "mail", "mobile", "sn", "uid", "uidNumber", "userPassword"));

                // 			$BaseD->debug = false;
                $info = ldap_get_entries($ldap, $sr);

                if ($info["count"] > 0) {
                    //var_dump($info[0]);

                    $user = array();
                    $user['cn'][0] = $info[0]['cn'][0];
                    $user['gidNumber'] = $info[0]['gidnumber'][0];
                    $user['givenName'][0] = $info[0]['givenname'][0];
                    $user['homeDirectory'] = "/home/users/" . $usuario;
                    $user['mail'][0] = $info[0]['mail'][0];
                    if ($info[0]['mobile'][0] != null) {
                        $user['mobile'] = $info[0]['mobile'][0];
                    }
                    $user['objectClass'][0] = "inetOrgPerson";
                    $user['objectClass'][1] = "posixAccount";
                    $user['objectClass'][2] = "top";
                    $user['sn'][0] = $info[0]['sn'][0];
                    $user['uid'][0] = $usuario;
                    $user['uidNumber'] = $info[0]['uidnumber'][0];
                    $user['userPassword'] = $info[0]['userpassword'][0];
                    $dn = "uid=" . $usuario . ",$BASE_DN";
                    if (@ldap_add($ldap, $dn, $user)) {
                        $ldap = conectar_ldap(1);
                        $dn = "uid=" . $uid . ",$BASE_DN";
                        @ldap_delete($ldap, $dn);
                    }

                    $this->usuario = $usuario;
                }
            }
            if (!empty($passwd)) {
                $clave = base64_encode($passwd);
                $BaseD->Execute("UPDATE usuarios SET clave = ? WHERE usuario = ?", array($clave, $this->usuario()));
            }
            if (!empty($nombres)) {
                $this->nombres = $nombres;
            }
            if (!empty($apellidos)) {
                $this->apellidos = $apellidos;
            }
            if (!empty($correo)) {
                $this->correo = $correo;
            }
            if (!empty($grado)) {
                $grado = new Grado($grado);
                $this->grado = $grado->gradoL();
            }
            if (!empty($colegio)) {
                $this->idInstitucion = $colegio;
            } else {
                return true;
            }
            if ($x != false) {
                return true;
            } else {
                return false;
            }
        }
    }

    function modificar_estudiante($nombres = null, $apellidos = null, $correo = null, $passwd = null, $nombresp = null, $correop = null, $movilp = null)
    {
        global $BASE_DN, $BaseD, $ADODB_TYPE, $CHML_CONFIG, $MDL_CONFIG, $DRPL_GALERIA_CONFIG;

        include $MDL_CONFIG;

        include "$CHML_CONFIG";

        include $DRPL_GALERIA_CONFIG;

        $LMS = NewADOConnection($ADODB_TYPE);
        $LMS->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);

        $BDMdl = NewADOConnection($CFG->dbtype);
        $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
        $BDMdl->SetCharSet('utf8');

        $BDdrpl = NewADOConnection($ADODB_TYPE);
        $BDdrpl->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BDdrpl->SetCharSet('utf8');

        $x = 1;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());

        $old = new Usuario($this->usuario);
        $nombres = ((!empty($nombres)) ? mb_convert_case($nombres, MB_CASE_TITLE, "UTF-8") : $old->nombres());
        $apellidos = ((!empty($apellidos)) ? mb_convert_case($apellidos, MB_CASE_TITLE, "UTF-8") : $old->apellidos());
        $nombresp = ((!empty($nombresp)) ? mb_convert_case($nombresp, MB_CASE_TITLE, "UTF-8") : $old->nombresp());
        $correo = ((!empty($correo)) ? $correo : $old->correo());
        $correop = ((!empty($correop)) ? $correop : $old->correop());
        $movilp = ((!empty($movilp)) ? $movilp : $old->telefonop());

        $ldap = conectar_ldap(1);
        $user = array();
        $user['cn'][0] = $nombres . " " . $apellidos;
        if (($nombres . " " . $apellidos) != ($nombresp) && $nombresp != null) {
            $user['cn'][1] = $nombresp;
        }
        $user['givenName'][0] = $nombres;
        $user['sn'][0] = $apellidos;
        $user['mail'][0] = $correo;
        if ($correo != $correop && $correop != null) {
            $user['mail'][1] = $correop;
        }
        if (!empty($movilp)) {
            $user['mobile'] = $movilp;
        }
        if (!empty($passwd)) {
            $user['userPassword'] = '{MD5}' . base64_encode(pack('H*', md5($passwd)));
        }
        $dn = "uid=" . $old->usuario . ",$BASE_DN";

        if (ldap_modify($ldap, $dn, $user)) {
            $LMS->Execute("UPDATE user SET lastname = ?, firstname = ?, email = ?, email_canonical = ? WHERE username = ?", array($apellidos, $nombres, $correo, $correo, $this->usuario()));
            $BDMdl->Execute("UPDATE " . $CFG->prefix . "user SET lastname = ?, firstname = ?, email = ? WHERE username = ?", array($apellidos, $nombres, $correo, $this->usuario()));
            $BDdrpl->Execute("UPDATE users SET mail = ? WHERE name = ?", array($correo, $this->usuario()));

            if (!empty($passwd)) {
                $clave = base64_encode($passwd);
                $BaseD->Execute("UPDATE usuarios SET clave = ? WHERE usuario = ?", array($clave, $this->usuario()));
            }
            if (!empty($nombres)) {
                $this->nombres = $nombres;
            }
            if (!empty($apellidos)) {
                $this->apellidos = $apellidos;
            }
            if (!empty($correo)) {
                $this->correo = $correo;
            }

            if (!empty($nombresp) && !empty($apellidos)) {
                $this->nombresp = $nombresp . " " . $apellidos;
            }
            if (!empty($correop)) {
                $this->correop = $correop;
            }

            if ($x != false) {
                return true;
            } else {
                return false;
            }
        }
    }

    function autenticar($pass)
    {
        global $BASE_DN, $LDAP_URI;

        $ldap = conectar_ldap();
        $sr = ldap_search($ldap, $BASE_DN, "(uid=" . $this->usuario . ")", array("uid"));
        $info = ldap_get_entries($ldap, $sr);
        $ldapconn = ldap_connect($LDAP_URI)
            or die("No se pudo conectar al árbol LDAP");
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
        $bind = @ldap_bind($ldapconn, $info[0]['dn'], $pass);
        ldap_unbind($ldapconn);

        //validar_sesiones($bind);

        //return $this->validar_sesion($bind);
        return $bind;
    }

    function validar_sesion($sesion = false)
    {
        global $BaseD;

        $ip = $BaseD->GetRow("SELECT ip FROM sesiones WHERE usuario = ?", array($this->usuario()));

        if ($ip) {
            if ($this->get_ip() == $ip['ip']) {
                if ($this->tiempo_fin_de_sesion()) {
                    $this->eliminar_sesion();
                    $this->inicia_sesion();
                }
                return (true);
            } else {
                if ($this->tiempo_fin_de_sesion()) {
                    $this->eliminar_sesion();
                    $this->inicia_sesion();
                    return (true);
                } else {
                    return (false);
                }
            }
        } else {
            if ($sesion) {
                $this->inicia_sesion();
                return (true);
            } else {
                return (false);
            }
        }
    }

    function eliminar_sesion()
    {
        global $BaseD;
        $BaseD->Execute("UPDATE usuarios SET session = ?, changeint = ? WHERE usuario=?", array(null, 0, $this->usuario()));
        $BaseD->Execute("DELETE FROM sesiones WHERE usuario = ?", array($this->usuario()));
    }

    function inicia_sesion()
    {
        global $BaseD;

        $BaseD->Execute("INSERT INTO sesiones (usuario, ip) values (?,?)", array($this->usuario(), $this->get_ip()));
    }

    function tiempo_fin_de_sesion()
    {
        global $BaseD;

        $hora = $BaseD->GetRow("SELECT hora FROM sesiones WHERE usuario = ? and CONVERT_TZ(hora,'+00:00','-04:00') < CONVERT_TZ(NOW(),'+00:00','-05:00')", array($this->usuario()));

        return ($hora);
    }

    function get_ip()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }

        return $_SERVER['REMOTE_ADDR'];
    }

    function matricular($inst)
    {
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());

        $this->activar();
        $colegio = new Institucion($inst);
        $plataforma = new Plataforma($colegio->plataforma());
        if ($this->soy_estudiante()) {
            if ($plataforma->es_meli()) {
                $this->matricula_meli();
            } else if ($plataforma->es_saber()) {
                $this->matricula_pruebas();
                if ($colegio->tiene_galeria()) {
                    $this->matricula_galeria_drpl("sie");
                }
            } else if ($plataforma->es_nuevo_saber()) {
                $this->matricula_nuevo_saber();
            } else if ($plataforma->es_comprende()) {
                $this->matricula_comprende();
            } else if ($plataforma->es_sie() || $plataforma->es_sieplus() || $this->soy_preescolar() || $plataforma->es_guiandote()) {
                if ($inst == 2015 || $inst == 2165) {
                    $this->matricula_comprende();
                }

                if (!$this->soy_preescolar()) {

                    if ($colegio->tiene_lms()) {
                        $this->inscribe_lms();
                    }
                    if ($colegio->tiene_galeria()) {
                        $this->matricula_galeria();
                        $this->matricula_galeria_drpl("sie");
                    }
                    if ($colegio->tiene_plan_lector()) {
                        $this->matricula_plan();
                    }
                    if ($colegio->tiene_pruebas()) {
                        $this->matricula_nuevo_saber();
                    }
                    if ($colegio->tiene_meli()) {
                        $this->matricula_meli();
                    }
                } else {
                    if ($inst == 1260 || $inst == 1451) {
                        $this->matricula_preescolar($this->id_grado());
                    } else {
                        $this->matricula_preescolar();
                    }
                    $this->inscribe_lms();
                    $this->matricula_plan();
                }

                if ($plataforma->es_sieplus()) { }
            } else if ($plataforma->es_educlass()) {
                if (!$this->soy_preescolar()) {

                    if ($colegio->tiene_lms()) {
                        $this->inscribe_lms();
                    }
                    if ($colegio->tiene_plan_lector()) {
                        $this->matricula_plan();
                    }
                    if ($colegio->tiene_pruebas()) {
                        $this->matricula_nuevo_saber();
                    }
                    if ($colegio->tiene_meli()) {
                        $this->matricula_meli();
                    }

                    $this->matricula_educlass($this->id_grado());
                    $this->matricula_galeria_drpl("educlass", $this->id_grado());
                    //$this->matricula_galeria_drpl("sie");
                } else {
                    $this->inscribe_lms();
                    if ($inst == 1260 || $inst == 1451) {
                        $this->matricula_preescolar($this->id_grado());
                    } else {
                        $this->matricula_preescolar();
                    }
                    $this->matricula_plan();
                }
            } else if ($plataforma->es_tdigitales()) {
                if ($colegio->tiene_plan_lector()) {
                    $this->matricula_plan();
                }
            }

            if ($plataforma->es_educlass() || $plataforma->es_sie() || $plataforma->es_sieplus() || $plataforma->es_saber() || $plataforma->es_nuevo_saber()) {
                $objGRado = new Grado($this->id_grado());
                $objCur = new Curso(($this->id_curso() != null) ? $this->id_curso() : $objGRado->primer_grupo());
                $objCur->matricular($this->id());
            }
        } else {
            if ($colegio->tiene_lms()) {
                $this->inscribe_lms();
            }
            $this->matricula_educlass();
            $this->matricula_galeria();
            $this->matricula_comprende();
            $this->matricula_galeria_drpl("sie");
            $this->matricula_autor_drpl("profesor");
            $this->matricula_plan();
            $this->matricula_pruebas();
            $this->matricula_preescolar();

            if ($plataforma->es_meli() || $colegio->tiene_meli()) {
                $this->matricula_meli();
            }
        }
    }

    function activar()
    {
        global $BaseD;

        $BaseD->Execute("UPDATE usuarios SET habilitado = 1 WHERE id = ?", array($this->id()));
    }

    function desactivar()
    {
        global $BaseD;

        $BaseD->Execute("UPDATE usuarios SET habilitado = 0 WHERE id = ?", array($this->id()));
    }

    function activo()
    {
        // if ($this->soy_estudiante()) {
        //     return $this->habilitado;
        // } else {
        //     return 1;
        // }
        return $this->habilitado;
    }

    function pago()
    {
        return $this->pago;
    }

    function maxima_usuario() {
        global $BaseD;

        $res = $BaseD->GetRow("SELECT maxima_usuario FROM usuarios WHERE usuario = ?", array($this->usuario));

        return $res['maxima_usuario'];
    }

    function cambiar_maxima_usuario($fecha)
    {
        global $BaseD;

        $BaseD->Execute("UPDATE usuarios SET maxima_usuario = ? WHERE id = ?", array($fecha, $this->id()));
    }

    function dias_para_desactivar()
    {
        global $BaseD;

        $res = $BaseD->GetRow("SELECT maxima_usuario FROM usuarios WHERE habilitado = 1 AND usuario = ?", array($this->usuario));

        if (isset($res['maxima_usuario'])) {
            $maxima_usuario = strtotime('-5 hour', strtotime($res['maxima_usuario']));
            $hoy = strtotime('-5 hour', strtotime("now"));
            $dias = ceil(($maxima_usuario - $hoy) / (60 * 60 * 24));

            return $dias;
        } else {
            $res = $BaseD->GetRow("SELECT maxima_usuario FROM pines WHERE pre_activado = 1 AND activado_por = ?", array($this->usuario));

            if (isset($res['maxima_usuario'])) {
                $maxima_usuario = strtotime('-5 hour', strtotime($res['maxima_usuario']));
                $hoy = strtotime('-5 hour', strtotime("now"));
                $dias = ceil(($maxima_usuario - $hoy) / (60 * 60 * 24));

                return $dias;
            }
        }

        return false;
    }

    function matricula_comprende()
    {
        global $BaseD, $CAT_COMPRENDE, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;

            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_COMPRENDE");
            while (!$recordSet->EOF) {
                $ops = array($this->usuario, $recordSet->fields['shortname']);
                $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                $recordSet->MoveNext();
            }
            $BDMdl->Close();
        }
    }

    function matricula_meli()
    {
        global $BaseD, $CAT_MELI, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;

            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_MELI");
            while (!$recordSet->EOF) {
                $ops = array($this->usuario, $recordSet->fields['shortname']);
                $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                $recordSet->MoveNext();
            }
            $BDMdl->Close();
        }
    }

    function matricula_galeria()
    {
        global $BaseD, $CAT_GALERIA, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;

            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');
            $BDMdl->debug = false;
            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }


            $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_GALERIA");
            while (!$recordSet->EOF) {
                $ops = array($this->usuario, $recordSet->fields['shortname']);
                $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                $recordSet->MoveNext();
            }
            $BDMdl->Close();
        }
    }

    function matricula_galeria_drpl($rol, $id_grado = "")
    {
        global $ADODB_TYPE, $DRPL_GALERIA_CONFIG;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $DRPL_GALERIA_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug =true;

        if ($this->usuario != null) {
            $res = $BaseD->GetRow("SELECT uid FROM users ORDER BY uid DESC limit 1");

            if ($BaseD->Execute("INSERT INTO users (uid, name, mail, status, init) VALUES (?,?,?,?,?)", array($res['uid'] + 1, $this->usuario, $this->correo, 1, $this->usuario))) {
                $res['uid'] = $res['uid'] + 1;
            } else {
                $res = $BaseD->GetRow("SELECT uid FROM users WHERE name = ?", array($this->usuario));
            }
            $BaseD->Execute("INSERT INTO cas_user (uid, cas_name) VALUES (?, ?)", array($res['uid'], $this->usuario));
            if (!empty($id_grado)) {
                $objGRado = new Grado($id_grado);
                $rol = $rol . $objGRado->gradoNL();
            }

            $idrol = $BaseD->GetRow("SELECT rid FROM role WHERE name = ?", array($rol));
            $BaseD->Execute("INSERT INTO users_roles (uid, rid) VALUES (?,?)", array($res['uid'], $idrol['rid']));
        }
    }

    function matricula_biblioteca_drpl($rol)
    {
        global $ADODB_TYPE, $DRPL_BIBLIOTECA_CONFIG;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $DRPL_BIBLIOTECA_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug =true;

        if ($this->usuario != null) {
            $res = $BaseD->GetRow("SELECT uid FROM users ORDER BY uid DESC limit 1");

            if ($BaseD->Execute("INSERT INTO users (uid, name, mail, status, init) VALUES (?,?,?,?,?)", array($res['uid'] + 1, $this->usuario, $this->correo, 1, $this->usuario))) {
                $res['uid'] = $res['uid'] + 1;
            } else {
                $res = $BaseD->GetRow("SELECT uid FROM users WHERE name = ?", array($this->usuario));
            }

            $BaseD->Execute("INSERT INTO cas_user (uid, cas_name) VALUES (?, ?)", array($res['uid'], $this->usuario));
            $idrol = $BaseD->GetRow("SELECT rid FROM role WHERE name = ?", array($rol));
            $BaseD->Execute("INSERT INTO users_roles (uid, rid) VALUES (?,?)", array($res['uid'], $idrol['rid']));
        }
    }

    function matricula_autor_drpl($rol)
    {
        global $ADODB_TYPE, $DRPL_AUTOR_CONFIG;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $DRPL_AUTOR_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug =true;

        if ($this->usuario != null) {
            $res = $BaseD->GetRow("SELECT uid FROM users ORDER BY uid DESC limit 1");

            if ($BaseD->Execute("INSERT INTO users (uid, name, mail, status, init) VALUES (?,?,?,?,?)", array($res['uid'] + 1, $this->usuario, $this->correo, 1, $this->usuario))) {
                $res['uid'] = $res['uid'] + 1;
            } else {
                $res = $BaseD->GetRow("SELECT uid FROM users WHERE name = ?", array($this->usuario));
            }
            $BaseD->Execute("INSERT INTO cas_user (uid, cas_name) VALUES (?, ?)", array($res['uid'], $this->usuario));

            $idrol = $BaseD->GetRow("SELECT rid FROM role WHERE name = ?", array($rol));
            $BaseD->Execute("INSERT INTO users_roles (uid, rid) VALUES (?,?)", array($res['uid'], $idrol['rid']));
        }
    }

    function matricula_educlass($id_grado = "")
    {
        global $BaseD, $CAT_EDUCLASS, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;
            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');
            //$BaseD->debug = true;

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            if (!is_null($id_grado)) {
                if (empty($id_grado)) {
                    $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_EDUCLASS");
                    while (!$recordSet->EOF) {
                        $ops = array($this->usuario, $recordSet->fields['shortname']);
                        $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                        $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                        $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                        $recordSet->MoveNext();
                    }
                } else {
                    $objGRado = new Grado($id_grado);
                    $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE shortname = ? and category = ?", array("educlass" . $objGRado->gradoNL(), $CAT_EDUCLASS));
                    $ops = array($this->usuario, $recordSet->fields['shortname']);
                    $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? and curso = ?", $ops);
                    $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                    $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                }
            }
            $BDMdl->Close();
        }
    }

    function matricula_preescolar($id_grado = "")
    {
        global $BaseD, $CAT_PRESCHOOL, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;

            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            if (!is_null($id_grado)) {
                if (empty($id_grado)) {
                    $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_PRESCHOOL");
                    while (!$recordSet->EOF) {
                        $ops = array($this->usuario, $recordSet->fields['shortname']);
                        $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                        $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                        $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                        $recordSet->MoveNext();
                    }
                } else {
                    $objGRado = new Grado($id_grado);
                    $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE shortname = ? and category = ?", array($objGRado->gradoPS(), $CAT_PRESCHOOL));
                    $ops = array($this->usuario, $recordSet->fields['shortname']);
                    $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? and curso = ?", $ops);
                    $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                    $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                }
            }
            $BDMdl->Close();
        }
    }

    function matricula_plan()
    { }

    function matricula_pruebas()
    {
        global $BaseD, $CAT_PSABER, $ROL_PROFE_MDL, $MDL_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_CONFIG;
            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_PSABER");
            while (!$recordSet->EOF) {
                $ops = array($this->usuario, $recordSet->fields['shortname']);
                $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                $recordSet->MoveNext();
            }

            $BDMdl->Close();
        }
    }

    function matricula_nuevo_saber()
    {
        global $BaseD, $CAT_NUEVO_SABER, $ROL_PROFE_MDL, $MDL_SABER_CONFIG;

        if ($this->usuario != null) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            include $MDL_SABER_CONFIG;
            $BDMdl = NewADOConnection($CFG->dbtype);
            $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
            $BDMdl->SetCharSet('utf8');

            if (!$this->estudiante) {
                $rol = $ROL_PROFE_MDL;
            } else {
                $rol = 'student';
            }

            $recordSet = $BDMdl->Execute("SELECT shortname FROM " . $CFG->prefix . "course WHERE category = $CAT_NUEVO_SABER");
            while (!$recordSet->EOF) {
                $ops = array($this->usuario, $recordSet->fields['shortname']);
                $reg = $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ? AND curso = ?", $ops);
                $ops = array($this->usuario, $recordSet->fields['shortname'], $rol);
                $reg = $BaseD->Execute("INSERT INTO matriculasevsaber (usuario, curso, rol) VALUES (?,?,?)", $ops);
                $recordSet->MoveNext();
            }

            $BDMdl->Close();
        }
    }

    function inscribe_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;

        if ($this->estudiante) {
            $status = 5;
        } elseif ($this->profesor) {
            $status = 1;
        } elseif ($this->coordinador) {
            $status = 4;
        }

        if ($status != null) {
            $BaseD->Execute("DELETE FROM course_rel_user WHERE user_id = ?", array($this->id_lms()));
            $BaseD->Execute("DELETE FROM user WHERE username = ?", array($this->usuario));

            $res = $BaseD->GetRow("select id from user order by id desc limit 1");
            $st = $BaseD->Execute(
                "INSERT INTO user (user_id, id, lastname, firstname, username, username_canonical, password, auth_source, email, email_canonical, status, language, registration_date, expiration_date, active, enabled, official_code, address, roles)
		VALUES
		(?, ?, ?, ?, ?, ?, '', 'cas', ?, ?, ?, 'spanish_latin', NOW(), DATE_ADD(NOW(), INTERVAL 14 MONTH), 1, 1, ?, ?, ?)",
                array($res["id"] + 1, $res["id"] + 1, $this->apellidos, $this->nombres, mb_convert_case($this->usuario, MB_CASE_LOWER, "UTF-8"), mb_convert_case($this->usuario, MB_CASE_LOWER, "UTF-8"), $this->correo, $this->correo, $status, mb_convert_case($this->usuario, MB_CASE_LOWER, "UTF-8"), $this->idInstitucion, 'a:0:{}')
            );
            if (!$st) { }
        }
    }

    function cambiar_institucion($institucion)
    {
        global $BaseD;

        $this->idInstitucion = $institucion;
        $BaseD->Execute("UPDATE usuarios SET changeint = ? WHERE usuario = ?", array($institucion, $this->usuario));
    }

    function hacer_coordinador_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);

        $reg = $BaseD->Execute("UPDATE user SET status = 4 WHERE user_id = ?", array($this->id));
    }

    function vincular_cursos_coordinador_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        if ($this->id != null) {
            $reg = $BaseD->Execute(
                "INSERT INTO course_rel_user
			(course_code, user_id, status, role, group_id, tutor_id, sort, user_course_cat, relation_type, legal_agreement)
			SELECT code, ?, 4, NULL, 0, 0, NULL, 0, 1, 0 FROM course WHERE category_code = ?",
                array($this->id, $this->idInstitucion)
            );
        }
    }

    function vincular_profesores_coordinador_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR, $BaseD;

        $Rolid = $BaseD->GetRow("SELECT id FROM roles WHERE rol = 'profesor'");
        $rol = $Rolid['id'];

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $CHML_CONFIG;

        $BaseDL = NewADOConnection($ADODB_TYPE);
        $BaseDL->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);

        $reg = $BaseD->Execute("SELECT id FROM usuarios WHERE rol = ? AND institucion = ?", array($rol, $this->idInstitucion));
        while (!$reg->EOF) {
            $BaseDL->Execute("INSERT INTO user_rel_user (user_id, friend_user_id, relation_type, last_edit) VALUES (?,?,7,NULL)", array($reg->fields['id'], $this->id));
            $reg->MoveNext();
        }
    }

    function existe($usuario)
    {
        global $BaseD;

        if (strlen($usuario) >= 2) {
            $reg = $BaseD->Execute("SELECT id FROM usuarios WHERE usuario = '$usuario'");
            if ($reg->RecordCount() > 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    function matricular_t_digitales($usuario, $grado)
    {
        global $BaseD;

        if (!$this->existe_matricula_t_digitales($usuario)) {
            $BaseD->Execute("INSERT INTO textosdigitales (usuario, grado) values (?, ?)", array($usuario, $grado));
        }
    }

    function existe_matricula_t_digitales($usuario = "")
    {
        global $BaseD;
        if ($usuario == "") {
            $usuario = $this->usuario();
        }

        $res = $BaseD->Execute("SELECT usuario FROM textosdigitales WHERE usuario = ?", array($usuario));

        if ($res->RecordCount() > 0) {
            return (true);
        } else {
            return (false);
        }
    }

    function grado_tdigitales()
    {
        global $BaseD;
        $res = $BaseD->GetRow("SELECT grado FROM textosdigitales WHERE usuario = ?", array($this->usuario()));
        return ($res['grado']);
    }

    function id()
    {
        return $this->id;
    }

    function correo()
    {
        return $this->correo;
    }
    function correop()
    {
        return $this->correop;
    }

    function institucion()
    {
        return (int) $this->idInstitucion;
    }

    function apellidos()
    {
        return trim(ucwords($this->apellidos));
    }

    function ciudad()
    {
        return $this->ciudad;
    }

    function puntos()
    {
        return $this->puntos;
    }

    function pin()
    {
        return $this->pin;
    }

    function changeint()
    {
        global $BaseD;

        $y = $BaseD->GetRow("SELECT changeint FROM usuarios WHERE id=?", array($this->id));

        return $y['changeint'];
    }

    function puntos_x_mes($mes)
    {

        global $BaseD;

        $res = $BaseD->GetRow(
            " SELECT ELT(?, XX.part1, XX.part2, XX.part3, XX.part4, XX.part5, XX.part6, XX.part7, XX.part8, XX.part9, XX.part10, XX.part11, XX.part12) AS mes FROM (SELECT
			SUBSTRING_INDEX(puntos_x_mes,',',1) AS part1,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',2),',',-1) AS part2,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',3),',',-1) AS part3,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',4),',',-1) AS part4,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',5),',',-1) AS part5,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',6),',',-1) AS part6,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',7),',',-1) AS part7,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',8),',',-1) AS part8,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',9),',',-1) AS part9,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',10),',',-1) AS part10,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',-2),',',1) AS part11,
			SUBSTRING_INDEX(puntos_x_mes,',',-1) AS part12
		FROM usuarios WHERE usuario=?) AS XX",
            array($mes, $this->usuario)
        );

        return ($res["mes"]);
    }

    function top_puntos_x_mes($mes)
    {

        global $BaseD;

        $recordSet = $BaseD->Execute(
            " SELECT CAST(ELT(?, XX.part1, XX.part2, XX.part3, XX.part4, XX.part5, XX.part6, XX.part7, XX.part8, XX.part9, XX.part10, XX.part11, XX.part12) AS UNSIGNED) AS mes, XX.usuario FROM (SELECT
			SUBSTRING_INDEX(puntos_x_mes,',',1) AS part1,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',2),',',-1) AS part2,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',3),',',-1) AS part3,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',4),',',-1) AS part4,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',5),',',-1) AS part5,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',6),',',-1) AS part6,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',7),',',-1) AS part7,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',8),',',-1) AS part8,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',9),',',-1) AS part9,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',10),',',-1) AS part10,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',-2),',',1) AS part11,
			SUBSTRING_INDEX(puntos_x_mes,',',-1) AS part12, usuario
			FROM usuarios WHERE rol=3 AND puntos_x_mes is not Null) AS XX ORDER BY mes DESC LIMIT 3",
            array($mes)
        );

        $lista = array();

        while (!$recordSet->EOF) {
            $obj = new stdClass;
            $obj->usuario = $recordSet->fields['usuario'];
            $obj->puntos = $recordSet->fields['mes'];
            $lista[] = $obj;
            $recordSet->MoveNext();
        }

        return $lista;
    }

    function top_puntos()
    {

        global $BaseD;

        $recordSet = $BaseD->Execute("SELECT usuario, puntos FROM usuarios ORDER BY puntos DESC");

        $lista = array();

        while (!$recordSet->EOF) {
            $obj = new stdClass;
            $obj->usuario = $recordSet->fields['usuario'];
            $obj->puntos = $recordSet->fields['puntos'];
            $lista[] = $obj;
            $recordSet->MoveNext();
        }

        return $lista;
    }

    function top_puntos_x_bimestre($mesini, $mesfin)
    {

        global $BaseD;

        $recordSet = $BaseD->Execute(
            "SELECT CAST(ELT(?, XX.part1, XX.part2, XX.part3, XX.part4, XX.part5, XX.part6, XX.part7, XX.part8, XX.part9, XX.part10, XX.part11, XX.part12) + ELT(?, XX.part1, XX.part2, XX.part3, XX.part4, XX.part5, XX.part6, XX.part7, XX.part8, XX.part9, XX.part10, XX.part11, XX.part12) AS UNSIGNED) AS mes, XX.usuario FROM (SELECT
			SUBSTRING_INDEX(puntos_x_mes,',',1) AS part1,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',2),',',-1) AS part2,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',3),',',-1) AS part3,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',4),',',-1) AS part4,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',5),',',-1) AS part5,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',6),',',-1) AS part6,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',7),',',-1) AS part7,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',8),',',-1) AS part8,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',9),',',-1) AS part9,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',10),',',-1) AS part10,
			SUBSTRING_INDEX(SUBSTRING_INDEX(puntos_x_mes,',',-2),',',1) AS part11,
			SUBSTRING_INDEX(puntos_x_mes,',',-1) AS part12, usuario
			FROM usuarios WHERE rol=3 AND puntos_x_mes is not Null) AS XX ORDER BY mes DESC LIMIT 3",
            array($mesini, $mesfin)
        );
        $lista = array();

        while (!$recordSet->EOF) {
            $obj = new stdClass;
            $obj->usuario = $recordSet->fields['usuario'];
            $obj->puntos = $recordSet->fields['mes'];
            $lista[] = $obj;
            $recordSet->MoveNext();
        }

        return $lista;
    }

    function nombres()
    {
        return trim(ucwords($this->nombres));
    }

    function nombresp()
    {
        return $this->nombresp;
    }

    function usuario()
    {
        return $this->usuario;
    }

    function clave()
    {
        return $this->clave;
    }

    function telefono()
    {
        return $this->telefono;
    }

    function telefonop()
    {
        return $this->telefonop;
    }

    function grado()
    {
        return $this->grado;
    }

    function curso()
    {
        global $BaseD;

        $y = $BaseD->GetRow("SELECT grupo FROM grupos_estudiantes WHERE estudiante=?", array($this->id));
        $this->id_curso = $y['grupo'];
        $objCurso = new Curso($this->id_curso);

        return $objCurso->grupo();
    }

    function id_grado()
    {
        return $this->id_grado;
    }

    function id_curso()
    {
        global $BaseD;

        if ($this->id_curso == null || $this->id_curso == "") {
            $y = $BaseD->GetRow("SELECT grupo FROM grupos_estudiantes WHERE estudiante=?", array($this->id));
            if ($y) {
                $this->id_curso = $y['grupo'];
            }
        }

        return $this->id_curso;
    }

    function soy_admin()
    {
        return $this->administrador;
    }

    function soy_coordinador()
    {
        return $this->coordinador;
    }

    function soy_profesor()
    {
        return $this->profesor;
    }

    function soy_restringido()
    {
        return $this->restringido;
    }

    function soy_estudiante()
    {
        return $this->estudiante;
    }

    function soy_preescolar()
    {
        if ($this->my_session() == "preschool")
            return true;
        else
            return $this->flag_preschool;
    }

    function soy_educlass()
    {
        if ($this->my_session() == "educlass")
            return true;
        else
            return false;
    }

    function my_session()
    {
        global $BaseD;

        $mysession = $BaseD->GetRow("SELECT session FROM usuarios WHERE usuario=?", array($this->usuario()));

        return $mysession["session"];
    }

    function cambiar_session($ses)
    {
        global $BaseD;
        $BaseD->Execute("UPDATE usuarios SET session = ? WHERE usuario=?", array($ses, $this->usuario()));
        $_SESSION[$ses] = 1;
    }

    function soy_meli()
    {
        /*var_dump($this->flag_meli);
        echo"soy_meli";*/
        return $this->flag_meli;
    }

    function activa_preschool()
    {
        global $BaseD;

        $BaseD->Execute("UPDATE usuarios SET session = ? WHERE usuario=?", array("preschool", $this->usuario()));

        $this->flag_preschool = true;
    }

    function activa_educlass()
    {
        global $BaseD;
        $BaseD->Execute("UPDATE usuarios SET session = ? WHERE usuario=?", array("educlass", $this->usuario()));
    }

    function buscar_usuarios($termino, $campo, $rol, $colegio, $quien)
    {
        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $regresar = array();

        switch ($campo) {
            case 'apellido':
                $filtro = "sn=$termino*";
                break;
            case 'nombre':
                $filtro = "givenName=" . $termino . "*";
                break;
            case 'usuario':
                $filtro = "uid=" . $termino . "*";
                break;
            case 'correo':
                $filtro = "mail=$termino*";
                break;
        }

        $me = new Usuario($quien);
        if (!$me->soy_admin() && !$me->soy_restringido()) {
            $filtro = "&($filtro)(gidNumber=$colegio)";
        }

        $ldap = conectar_ldap(1);
        $sr = ldap_search($ldap, $BASE_DN, "(&(objectClass=posixAccount)($filtro))", array("cn", "uid", "mail"));
        $resultados = ldap_get_entries($ldap, $sr);

        for ($i = 0; $i < $resultados["count"]; $i++) {
            $to['label'] = $resultados[$i]["uid"][0] . " | " . $resultados[$i]["cn"][0] . " | " . $resultados[$i]["mail"][0];
            $to['value'] = $resultados[$i]["uid"][0];

            $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE usuario = ? AND R.rol = ?";
            $vals = array($resultados[$i]["uid"][0], $rol);

            $res = $BaseD->Execute($sql, $vals);
            if ($res->RecordCount() > 0) {
                $regresar[] = $to;
            }
        }

        return json_encode($regresar);
    }

    function buscar_todos_usuarios($termino, $campo, $rol, $colegio, $quien)
    {
        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $regresar = array();

        switch ($campo) {
            case 'apellido':
                $filtro = "sn=$termino*";
                break;
            case 'nombre':
                $filtro = "givenName=" . $termino . "*";
                break;
            case 'usuario':
                $filtro = "uid=" . $termino . "*";
                break;
            case 'correo':
                $filtro = "mail=$termino*";
                break;
        }

        $me = new Usuario($quien);
        if (!$me->soy_admin() && !$me->soy_restringido()) {
            $filtro = "&($filtro)(gidNumber=$colegio)";
        }

        $ldap = conectar_ldap(1);
        $sr = ldap_search($ldap, $BASE_DN, "(&(objectClass=posixAccount)($filtro))", array("cn", "uid", "mail"));
        $resultados = ldap_get_entries($ldap, $sr);

        for ($i = 0; $i < $resultados["count"]; $i++) {
            $to['label'] = $resultados[$i]["uid"][0] . " | " . $resultados[$i]["cn"][0] . " | " . $resultados[$i]["mail"][0];
            $to['value'] = $resultados[$i]["uid"][0];

            $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE usuario = ? AND R.rol = ?";
            $vals = array($resultados[$i]["uid"][0], $rol);

            $res = $BaseD->Execute($sql, $vals);
            if ($res->RecordCount() > 0) {
                $regresar[] = $to;
            }
        }
        return json_encode($regresar);
    }

    function buscar_usuarios2($termino, $campo, $rol, $colegio, $quien)
    {
        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $regresar = array();
        switch ($campo) {
            case 'apellido':
                $filtro = "sn=$termino*";
                break;
            case 'nombre':
                $filtro = "givenName=" . $termino . "*";
                break;
            case 'usuario':
                $filtro = "uid=" . $termino . "*";
                break;
            case 'correo':
                $filtro = "mail=$termino*";
                break;
        }
        $me = new Usuario($quien);
        $ldap = conectar_ldap(1);
        $sr = ldap_search($ldap, $BASE_DN, "(&(objectClass=posixAccount)($filtro))", array("cn", "uid", "mail"));
        $resultados = ldap_get_entries($ldap, $sr);

        $filter = "(|($filtro))";
        $justthese = array("cn");

        $sr = ldap_search($ldap, $BASE_DN, $filter, $justthese);

        $info = ldap_get_entries($ldap, $sr);

        echo $info["count"] . " entries returned\n";

        for ($i = 0; $i < $info["count"]; $i++) {
            echo ("si <br>");
            $to['label'] = $resultados[$i]["uid"][0] . " | " . $resultados[$i]["cn"][0] . " | " . $resultados[$i]["mail"][0];
            $to['value'] = $resultados[$i]["uid"][0];

            $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE usuario = ? AND R.rol = ?";
            $vals = array($resultados[$i]["uid"][0], $rol);

            $res = $BaseD->Execute($sql, $vals);
            if ($res->RecordCount() > 0) {
                $regresar[] = $to;
            }
        }

        return json_encode($regresar);
    }

    function buscar_usuarios_institucion($termino, $campo, $rol, $colegio)
    {
        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $regresar = array();

        switch ($campo) {
            case 'apellido':
                $filtro = "sn=$termino*";
                break;
            case 'nombre':
                $filtro = "givenName=" . $termino . "*";
                break;
            case 'usuario':
                $filtro = "uid=" . $termino . "*";
                break;
            case 'correo':
                $filtro = "mail=$termino*";
                break;
        }

        $filtro = "&($filtro)(gidNumber=$colegio)";

        $ldap = conectar_ldap(1);
        $sr = ldap_search($ldap, $BASE_DN, "(&(objectClass=posixAccount)($filtro))", array("cn", "uid", "mail"));
        $resultados = ldap_get_entries($ldap, $sr);

        for ($i = 0; $i < $resultados["count"]; $i++) {
            $to['label'] = $resultados[$i]["uid"][0] . " | " . $resultados[$i]["cn"][0] . " | " . $resultados[$i]["mail"][0];
            $to['value'] = $resultados[$i]["uid"][0];

            $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE usuario = ? AND R.rol = ?";
            $vals = array($resultados[$i]["uid"][0], $rol);

            $res = $BaseD->Execute($sql, $vals);
            if ($res->RecordCount() > 0) {
                $regresar[] = $to;
            }
        }

        return json_encode($regresar);
    }

    function borrar($uid)
    {

        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $usuario = new Usuario($uid);
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());

        if ($usuario->usuario() != null) {
            $BaseD->Execute("DELETE FROM usuarios_libros WHERE usuario=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM notificaciones WHERE usuario=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM grupos_estudiantes WHERE estudiante=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM grupos_profesores WHERE profesor=?", array($usuario->id()));

            if ($BaseD->Execute("DELETE FROM usuarios WHERE usuario=?", array($usuario->usuario()))) {
                $ldap = conectar_ldap(1);
                $dn = "uid=" . $uid . ",$BASE_DN";
                if (@ldap_delete($ldap, $dn)) {
                    $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ?", array($usuario->usuario()));
                    //$BaseD->Execute("DELETE FROM pines WHERE activado_por = ?", array($usuario->usuario()));
                    $this->borrar_lms($uid, $usuario->id_lms());
                    $this->borrar_mdl($uid);
                    $this->borrar_galeria_drpl($usuario->usuario());
                    registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
                    return (true);
                } else {
                    return (false);
                }
            } else {
                return (false);
            }
        } else {
            return (true);
        }
    }

    function borrar_otro($uid)
    {

        global $BaseD, $BASE_DN;
        //$BaseD->debug = true;
        $usuario = new Usuario($uid);
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());

        if ($usuario->usuario() != null) {
            $BaseD->Execute("DELETE FROM usuarios_libros WHERE usuario=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM notificaciones WHERE usuario=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM grupos_estudiantes WHERE estudiante=?", array($usuario->id()));

            $BaseD->Execute("DELETE FROM grupos_profesores WHERE profesor=?", array($usuario->id()));

            if ($BaseD->Execute("DELETE FROM usuarios WHERE usuario=?", array($usuario->usuario()))) {
                $ldap = conectar_ldap(1);
                $dn = "uid=" . $uid . ",$BASE_DN";
                if (@ldap_delete($ldap, $dn)) {
                    $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ?", array($usuario->usuario()));
                    //$BaseD->Execute("DELETE FROM pines WHERE activado_por = ?", array($usuario->usuario()));
                    $usuario->borrar_lms($uid, $usuario->id_lms());
                    $usuario->borrar_mdl($uid);
                    $usuario->borrar_galeria_drpl($usuario->usuario());
                    registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $usuario);
                    return (true);
                } else {
                    return (false);
                }
            } else {
                return (false);
            }
        } else {
            return (true);
        }
    }

    //funcion temporal
    function borrado_especial($user)
    {

        global $BaseD, $BASE_DN, $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        include $CHML_CONFIG;

        $BaseDlms = NewADOConnection($ADODB_TYPE);
        $BaseDlms->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseDlms->SetCharSet('utf8');

        $idlms = $BaseDlms->GetRow("SELECT id FROM user WHERE username = ?", array($user));

        //$BaseD->debug = true;
        //$BaseDlms->debug = true;

        $ldap = conectar_ldap(1);
        $dn = "uid=" . $user . ",$BASE_DN";
        if (@ldap_delete($ldap, $dn)) {
            $BaseD->Execute("DELETE FROM matriculasevsaber WHERE usuario = ?", array($user));
            $this->borrar_lms($user, $idlms["id"]);
            $this->borrar_mdl($user);
            echo "si";
        } else {
            echo "no";
        }
    }

    function borrar_lms($uid, $idlms)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;


        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');

        $BaseD->Execute("DELETE FROM c_item_property WHERE insert_user_id = ? OR to_user_id = ?", array($idlms, $idlms));
        $BaseD->Execute("DELETE FROM course_rel_user WHERE user_id = ?", array($idlms));

        if ($BaseD->Execute("DELETE FROM user WHERE username = ?", array($uid))) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            return (true);
        } else {
            return (false);
        }
    }

    function borrar_galeria_drpl($usuario)
    {
        global $ADODB_TYPE, $DRPL_GALERIA_CONFIG;


        include $DRPL_GALERIA_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');

        $res = $BaseD->GetRow("SELECT uid FROM users WHERE name = ?", array($usuario));
        $BaseD->Execute("DELETE FROM course_rel_user WHERE user_id = ?", array($idlms));
        $BaseD->Execute("DELETE FROM cas_user WHERE cas_name = ?", array($usuario));
        $BaseD->Execute("DELETE FROM users_roles WHERE uid = ?", array($res['uid']));

        if ($BaseD->Execute("DELETE FROM users WHERE name = ?", array($usuario))) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            return (true);
        } else {
            return (false);
        }
    }

    function existe_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $res = $BaseD->Execute("SELECT * FROM user WHERE username = ?", array($this->usuario()));

        if ($res->RecordCount() > 0) {
            return (true);
        } else {
            return (false);
        }
    }

    function id_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        $res = $BaseD->GetRow("SELECT id FROM user WHERE username = ?", array($this->usuario()));

        if ($res) {
            return ($res["id"]);
        } else {
            return (false);
        }
    }

    function borrar_mdl($uid)
    {
        global $MDL_CONFIG;


        include $MDL_CONFIG;
        $BDMdl = NewADOConnection($CFG->dbtype);
        $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
        $BDMdl->SetCharSet('utf8');

        if ($BDMdl->Execute("DELETE FROM " . $CFG->prefix . "user WHERE username=?", array($uid))) {
            registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
            return (true);
        } else {
            return (false);
        }
    }

    function solicitar_nueva_contraseña()
    {        
        global $BaseD;
        if ($this->id() != -100) {
            do {
                $token = sha1(mt_rand(10000000, 1000000000));
                $reg = $BaseD->Execute("INSERT INTO solicitud_claves (token, usuario, solicitud, ip_solicitud) VALUES (?, ?, NOW(), ?)", array($token, $this->usuario, $_SERVER['REMOTE_ADDR']));
                $e = ADODB_Pear_Error();
            } while ($e->code == 1062);

            $col = new Institucion($this->idInstitucion);
            $txt_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "\r\n\r\nAlguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:\r\n\r\n\r\n
			http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\r\n\r\n\r\n\r\n
			Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            $html_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "<BR><BR>Alguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:<BR><BR><BR>
            <A href=\"http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\">http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token</A><BR><BR><BR>Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            /*enviar_correo('noreply@educar.com.co',$this->correo, $this->nombres." ".$this->apellidos, $txt_msg, $html_msg, "Cambio Contraseña ".$col->personalizacion("plataforma"), true);
            enviar_correo($this->correo,'noreply@educar.com.co', $this->nombres." ".$this->apellidos, $txt_msg, $html_msg, "Cambio Contraseña ".$col->personalizacion("plataforma"), true);*/
            if (strpos($this->correo, 'colbender') === false && !($this->idInstitucion == 2177 && $this->estudiante) && !($this->idInstitucion == 2058 && $this->estudiante) && $this->idInstitucion != 2015 && $this->idInstitucion != 2002 && $this->idInstitucion != 2041) {
                if ($this->usuario() == 'mauricio.rodriguez') {
                    enviar_correo('noreply@educar.com.co', 
                     $this->correo,
                     $this->nombres . " " . $this->apellidos, 
                     $txt_msg, 
                     $html_msg, 
                     "Cambio Contraseña " . $col->personalizacion("plataforma"),
                     true,
                     '',
                     '',
                     true
                    
                    ); //correo usuario

                }else{
                    enviar_correo('noreply@educar.com.co', $this->correo, $this->nombres . " " . $this->apellidos, $txt_msg, $html_msg, "Cambio Contraseña " . $col->personalizacion("plataforma"), true); //correo usuario
                }
            } else {
                echo "<div class='alert alert-warning'>Esta cuenta esta restringida para el cambio de correo electrónico y contraseña, si desea más información, por favor comunícate a nuestros canales de atención.</div>";
            }
            //enviar_correo($this->correo,'noreply@educar.com.co', $this->nombres." ".$this->apellidos , $txt_msg, $html_msg, "Cambio Contraseña ".$col->personalizacion("plataforma"), true); //correo plataforma
        } else {
            echo "<div class='alert alert-warning'>El usuario o correo electrónico ingresado no fue encontrado en nuestros registros.<br>Por favor, compruebe sus datos e inténtelo de nuevo.</div>";
        }
    }

    function solicitar_con_app()
    {
        global $BaseD;
        if ($this->id() != -100) {
            do {
                $token = sha1(mt_rand(10000000, 1000000000));
                $reg = $BaseD->Execute("INSERT INTO solicitud_claves (token, usuario, solicitud, ip_solicitud) VALUES (?, ?, NOW(), ?)", array($token, $this->usuario, $_SERVER['REMOTE_ADDR']));
                $e = ADODB_Pear_Error();
            } while ($e->code == 1062);

            $col = new Institucion($this->idInstitucion);
            $txt_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "\r\n\r\nAlguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:\r\n\r\n\r\n
			http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\r\n\r\n\r\n\r\n
			Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            $html_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "<BR><BR>Alguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:<BR><BR><BR>
            <A href=\"http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\">http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token</A><BR><BR><BR>Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            enviar_correo_app('noreply@educar.com.co', $this->correo, $this->nombres . " " . $this->apellidos, $txt_msg, $html_msg, "Cambio Contraseña " . $col->personalizacion("plataforma"), true); //correo usuario
        }
    }

    function solicitar_con_plataforma_personalizada($plataforma)
    {
        global $BaseD;

        if ($this->id() != -100) {
            do {
                $token = sha1(mt_rand(10000000, 1000000000));
                $reg = $BaseD->Execute("INSERT INTO solicitud_claves (token, usuario, solicitud, ip_solicitud) VALUES (?, ?, NOW(), ?)", array($token, $this->usuario, $_SERVER['REMOTE_ADDR']));
                $e = ADODB_Pear_Error();
            } while ($e->code == 1062);

            $url = "http://localhost/{$plataforma}/confirma.php?usuario={$this->usuario}&acode={$token}";

            switch ($plataforma) {
                case 'myclassflix':
                    $html = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN'
                            'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                            <html xmlns='http://www.w3.org/1999/xhtml' lang='es' xml:lang='es'>
                            <head>
                            <meta charset='UTF-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta http-equiv='X-UA-Compatible' content='ie=edge'>
                            <meta name='robots' content='noindex, nofollow'>
                            <style>
                            @import url('https://fonts.googleapis.com/css?family=Tajawal:400,700');
                            @import url('http://fonts.googleapis.com/css?family=Tajawal:400,700');
                            *,html,body{font-family:'Tajawal',sans-serif!important}
                            body{margin:0;Margin:0;padding:0;width:100%!important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}
                            center{width:100%;min-width:580px}
                            table{border-spacing:0;border-collapse:collapse}
                            td{word-wrap:break-word;-webkit-hyphens:auto;-moz-hyphens:auto;hyphens:auto;border-collapse:collapse!important}
                            table,tr,td{padding:0}
                            table.body{height:100%;width:100%}
                            table.float-center,td.float-center,th.float-center{margin:0 auto;Margin:0 auto;float:none;text-align:center}
                            table.container{width:580px;margin:0 auto;Margin:0 auto;text-align:inherit}
                            table.row{padding:0;width:100%;position:relative}
                            table.container table.row{display:table}
                            td.medium-1,th.medium-1{width:8.33333%!important}
                            td.medium-2,th.medium-2{width:16.66667%!important}
                            td.medium-3,th.medium-3{width:25%!important}
                            td.medium-4,th.medium-4{width:33.33333%!important}
                            td.medium-5,th.medium-5{width:41.66667%!important}
                            td.medium-6,th.medium-6{width:50%!important}
                            td.medium-7,th.medium-7{width:58.33333%!important}
                            td.medium-8,th.medium-8{width:66.66667%!important}
                            td.medium-9,th.medium-9{width:75%!important}
                            td.medium-10,th.medium-10{width:83.33333%!important}
                            td.medium-11,th.medium-11{width:91.66667%!important}
                            td.medium-12,th.medium-12{width:100%!important}
                            h1{font-weight:700;color:#28ada3;text-align:center}
                            h2{font-weight:700;color:#4b4b4c;text-align:center}
                            h3{font-weight:700;color:#727176;text-align:center}
                            h4{line-height:0.1;font-weight:400;color:#808080;text-align:center}
                            p.text-justify{font-family:'Tajawal',sans-serif!important;font-size:16px;font-weight:400;color:#808080;text-align:justify}
                            p.text-center{font-family:'Tajawal',sans-serif!important;font-size:16px;font-weight:400;color:#808080;text-align:center}
                            hr{width:25px;border:2.5px solid #28ada3}
                            a{font-weight:700;color:#28ada3;text-decoration:none}
                            </style>
                            </head>
                            <body>
                            <span class='preheader'></span><table class='body'><td class='center' align='center' valign='top'><center data-parsed=''>
                            <table align='center' class='container float-center'><tbody><tr><td>
                            <table class='row'><tbody><tr><td class='medium-12'><img src='https://www.myclassflix.com/mailer/assets/images/PIEZAS-10.png' alt=''>
                            </td></tr><tr><td class='medium-12'><br/>
                            <h1>{$this->nombres} {$this->apellidos}</h1>
                            <p class='text-center'>Queremos confirmar tu solicitud de recuperación de
                            <br/>contraseña,para esto puedes pulsar el botón recuperar<br/>contraseña y hacer la modificación.</p><br/><p class='text-center'>
                            <a href='{$url}' target='_blank' rel='noopener noreferrer'>
                            <img src='https://www.myclassflix.com/mailer/assets/images/PIEZAS-14.png' alt='RECUPERAR CONTRASEÑA'></a>
                            </p><br/><br/></td></tr><tr><td class='medium-12'><img src='https://www.myclassflix.com/mailer/assets/images/Recurso%2013.png' alt=''>
                            </td></tr></tbody></table></td></tr></tbody></table></center></td></table>
                            <!-- prevent Gmail on iOS font size manipulation -->
                            <div style='display:none; white-space:nowrap; font:15px courier; line-height:0;'>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                            </body>
                            </html>";
                    break;

                case 'nuevosaber':
                    $html = "<!DOCTYPE html
                            PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                            <html xmlns='http://www.w3.org/1999/xhtml' lang='es' xml:lang='es'>
                            <head>
                            <meta charset='UTF-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta http-equiv='X-UA-Compatible' content='ie=edge'>
                            <meta name='robots' content='noindex, nofollow'>
                            <style>
                            @font-face{font-family:Dosis;font-style:normal;font-weight:400;font-display:swap;src:local('Dosis Regular'),local('Dosis-Regular'),url(https://fonts.gstatic.com/s/dosis/v8/HhyaU5sn9vOmLzlmC_W6EQ.woff2) format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:400;font-display:swap;src:local('Dosis Regular'),local('Dosis-Regular'),url(https://fonts.gstatic.com/s/dosis/v8/HhyaU5sn9vOmLzloC_U.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:700;font-display:swap;src:local('Dosis Bold'),local('Dosis-Bold'),url(https://fonts.gstatic.com/s/dosis/v8/HhyXU5sn9vOmLzHTLuCLMItyTA.woff2) format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:700;font-display:swap;src:local('Dosis Bold'),local('Dosis-Bold'),url(https://fonts.gstatic.com/s/dosis/v8/HhyXU5sn9vOmLzHTLuCFMIs.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
                            body,h1,h2,h3,h4,h5,h6{font-family:Dosis,sans-serif!important;color:#1a1a1a;text-align:center}
                            body{margin:0;Margin:0;padding:0;width:100%!important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}
                            center{width:100%;min-width:580px}
                            table{border-spacing:0;border-collapse:collapse}
                            td{word-wrap:break-word;-webkit-hyphens:auto;-moz-hyphens:auto;hyphens:auto;border-collapse:collapse!important}
                            table,td,tr{padding:0}
                            table.body{height:100%;width:100%}
                            table.float-center,td.float-center,th.float-center{margin:0 auto;Margin:0 auto;float:none;text-align:center}
                            table.container{width:580px;margin:0 auto;Margin:0 auto;text-align:inherit}
                            table.row{padding:0;width:100%;position:relative}
                            table.container table.row{display:table}
                            td.medium-1,th.medium-1{width:8.33333%!important}
                            td.medium-2,th.medium-2{width:16.66667%!important}
                            td.medium-3,th.medium-3{width:25%!important}
                            td.medium-4,th.medium-4{width:33.33333%!important}
                            td.medium-5,th.medium-5{width:41.66667%!important}
                            td.medium-6,th.medium-6{width:50%!important}
                            td.medium-7,th.medium-7{width:58.33333%!important}
                            td.medium-8,th.medium-8{width:66.66667%!important}
                            td.medium-9,th.medium-9{width:75%!important}
                            td.medium-10,th.medium-10{width:83.33333%!important}
                            td.medium-11,th.medium-11{width:91.66667%!important}
                            td.medium-12,th.medium-12{width:100%!important}
                            p.text-justify{font-size:16px;font-weight:400;text-align:justify}
                            p.text-center{font-size:16px;font-weight:400;text-align:center}
                            a{font-weight:700;color:#45b075;text-decoration:none}
                            </style>
                            </head>
                            <body>
                            <span class='preheader'></span><table class='body'><td class='center' align='center' valign='top'><center data-parsed=''>
                            <table align='center' class='container float-center'><tbody><tr><td>
                            <table class='row'><tbody><tr><td class='medium-12'><img
                            src='http://localhost/images/emailnotificaciones/header-recovery-saber.png'
                            alt='header'></td></tr><tr><td class='medium-12'><br/><h1>Estimado(a) {$this->nombres} {$this->apellidos}</h1>
                            <p class='text-center'>Alguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma,
                            <br/>si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada,
                            <br/>por favor sigue el vínculo a continuación, copialo y pegalo en tu navegador.
                            <br/><p class='text-center'><a href='{$url}' target='_blank' rel='noopener noreferrer'>{$url}</a></p>
                            <p class='text-center'>o da clic en el botón recuperar contraseña.</p>
                            <p class='text-center'><a href='{$url}' target='_blank' rel='noopener noreferrer'>
                            <img src='http://localhost/images/emailnotificaciones/recovery-saber.png'
                            alt='RECUPERAR CONTRASEÑA'></a></p><br/><br/></td></tr><tr><td class='medium-12'><img
                            src='http://localhost/images/emailnotificaciones/footer-saber.png'
                            alt='footer'></td></tr></tbody></table></td></tr></tbody></table></center></td></table>
                            <!-- prevent Gmail on iOS font size manipulation -->
                            <div style='display:none; white-space:nowrap; font:15px courier; line-height:0;'>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                            </body>
                            </html>";
                    break;
            }

            return enviar_correo_plataforma_personalizada('noreply@educar.com.co', $this->correo, $this->nombres . " " . $this->apellidos, "", $html, "Cambio de contraseña " . strtoupper($plataforma), true);
        } else {
            return "El usuario o correo electrónico ingresado no fue encontrado en nuestros registros.<br/>Por favor, compruebe sus datos e inténtelo de nuevo.";
        }
    }

    function confirma_contraseña($token, $actualiza = false)
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        if ($actualiza) {
            $BaseD->Execute("UPDATE solicitud_claves SET confirmacion = NOW(), ip_confirmacion = ? WHERE usuario = ? AND token = ? AND DATEDIFF(NOW(), solicitud) <= 8 AND confirmacion IS NULL", array($_SERVER['REMOTE_ADDR'], $this->usuario(), $token));
            if ($BaseD->Affected_Rows()) {
                return true;
            } else {
                return false;
            }
        } else {
            $res = $BaseD->Execute("SELECT 1 FROM solicitud_claves WHERE usuario = ? AND token = ? AND DATEDIFF(NOW(), solicitud) <= 8 AND confirmacion IS NULL", array($this->usuario(), $token));
            if ($res->RecordCount() > 0) {
                return true;
            } else {
                return false;
            }
        }
    }

    function ingresa($x)
    {
        if (!$this->soy_coordinador()) {
            // $this->NotificionesLMS_Numero($this->id());
            if ($this->soy_estudiante()) {
                $this->Nivel($this->id());
                $this->Porcentaje_General($this->id());
                $this->Logros($this->id());
            }
        }
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
    }

    function pin_asociado()
    {
        global $BaseD;

        if ($this->soy_estudiante()) {
            $y = $BaseD->GetRow("SELECT pin FROM pines WHERE activado_por=?", array($this->usuario()));
            return $y['pin'];
        } else {
            return '';
        }
    }

    function ultima_modificacion()
    {
        global $BASE_DN;

        $ldap = conectar_ldap();
        $sr = ldap_read($ldap, "uid=" . $this->usuario() . "," . $BASE_DN, "(objectClass=*)", array("modifyTimestamp"));
        $info = ldap_get_entries($ldap, $sr);
        date_default_timezone_set('America/Bogota');
        return date('Y-m-d H:i:s', strtotime(substr($info[0]['modifytimestamp'][0], 0, strlen($info[0]['modifytimestamp'][0]) - 1)));
    }

    function ultimo_acceso()
    {
        global $BaseD;

        $reg = $BaseD->GetRow("SELECT DATE_SUB(cuando, INTERVAL 5 HOUR) cuando FROM log_2020 WHERE metodo = 'Usuario::ingresa' AND quien = ? ORDER BY cuando DESC LIMIT 1", array($this->usuario()));

        return $reg['cuando'];
    }

    function registra_nota_biblio($libro, $pagina, $nota)
    {
        global $BaseD;

        // 		$BaseD->debug = true;
        $BaseD->Execute("INSERT INTO biblio_anotaciones (usuario, libro, pagina, anotacion) VALUES(?, ?, ?, ?)", array($this->id(), $libro, $pagina, $nota));
        // 		$BaseD->debug = false;
    }

    function editar_nota_biblio($idnota, $nota)
    {
        global $BaseD;

        $BaseD->Execute("UPDATE biblio_anotaciones SET anotacion=? WHERE id=? AND usuario=?", array($nota, $idnota, $this->id()));
    }

    function eliminar_nota_biblio($idnota)
    {
        global $BaseD;

        $BaseD->Execute("DELETE FROM biblio_anotaciones WHERE id=?", array($idnota));
    }

    function leer_notas_biblio($libro)
    {
        global $BaseD;

        $recordSet = $BaseD->Execute("SELECT id, pagina, ultima_modificacion, LEFT(anotacion, 40) anotacion FROM biblio_anotaciones WHERE usuario = ? AND libro = ? ORDER BY pagina, ultima_modificacion DESC", array($this->id(), $libro));
        while (!$recordSet->EOF) {
            $obj = new stdClass;
            $obj->id = $recordSet->fields['id'];
            $obj->pagina = $recordSet->fields['pagina'];
            $obj->ultima_modificacion = date("d/m/y", strtotime($recordSet->fields['ultima_modificacion']));
            $obj->anotacion = $recordSet->fields['anotacion'];

            $lista[] = $obj;
            $recordSet->MoveNext();
        }

        return $lista;
    }

    function leer_nota_biblio($id)
    {
        global $BaseD;

        $x = $BaseD->GetRow("SELECT pagina, ultima_modificacion, anotacion FROM biblio_anotaciones WHERE usuario = ? AND id = ?", array($this->id(), $id));

        $obj = new stdClass;
        $obj->pagina = $x['pagina'];
        $obj->ultima_modificacion = date("d/m/y", strtotime($x['ultima_modificacion']));
        $obj->anotacion = $x['anotacion'];

        return $obj;
    }

    function id_galeria_saber_preescoolar()
    {
        global $MDL_CONFIG;

        include $MDL_CONFIG;
        $BDMdl = NewADOConnection($CFG->dbtype);
        // 		$BDMdl->debug = true;
        $BDMdl->Connect($CFG->dbhost, $CFG->dbuser, $CFG->dbpass, $CFG->dbname);
        $BDMdl->SetCharSet('utf8');

        $y = $BDMdl->GetRow("SELECT id FROM " . $CFG->prefix . "user WHERE username=?", array($this->usuario()));

        return $y['id'];
    }

    function listar_cursos_lms()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        // registro(__METHOD__, func_get_args(), $this);
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        $lista = array();

        $y = $BaseD->Execute("SELECT c.code, c.id, c.title FROM course_rel_user cu INNER JOIN course c ON (c.id= cu.c_id) WHERE user_id=? AND (c.visibility = ? OR  c.visibility = ?) ORDER BY c.title ASC", array($this->id_lms(), 1, 2));

        while (!$y->EOF) {
            $curso = new stdClass();
            $curso->id = $y->fields['id'];
            $curso->nombre = $y->fields['title'];
            $curso->codigo = $y->fields['code'];
            $lista[] = $curso;
            $y->MoveNext();
        }
        $y->Close();


        return $lista;
    }

    function agregar_link_lms($curso, $categoria, $titulo, $url, $code, $on_home = 0)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $CHML_CONFIG;

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');

        $cat = $BaseD->Execute("SELECT id FROM c_link_category WHERE category_title = ? AND c_id = ?", array($categoria, $curso));

        if ($cat->RecordCount() < 1) {
            $reg = $BaseD->GetRow("SHOW TABLE STATUS LIKE 'c_link_category'");
            $BaseD->Execute("INSERT INTO c_link_category (c_id, id, category_title) VALUES(?, ?, ?)", array($curso, $reg["Auto_increment"], $categoria));
            $idcat = $BaseD->Insert_ID();
        } else {
            //$idcat=$BaseD->GetOne("SELECT id FROM c_link_category WHERE category_title = ? AND c_id = ?", array($categoria, $curso));
            $idcat = $cat->fields["id"];
        }

        $link = $BaseD->Execute("SELECT iid FROM c_link WHERE c_id = ? AND url=? AND title=? AND category_id=?", array($curso, $url, $titulo, $idcat));
        $hoy = getdate();
        $DateOfRequest = $hoy["year"] . "-" . $hoy["mon"] . "-" . $hoy["mday"] . " " . $hoy["hours"] . ":" . $hoy["minutes"] . ":" . $hoy["seconds"];

        if ($link->RecordCount() < 1) {
            $reg = $BaseD->GetRow("SHOW TABLE STATUS LIKE 'c_link'");
            $BaseD->Execute("INSERT INTO c_link (c_id, id, url, title, category_id, target, on_homepage) VALUES(?, ?, ?, ?, ?, ?, ?)", array($curso, $reg["Auto_increment"], $url, $titulo, $idcat, '_blank', $on_home));
            $idlink = $BaseD->Insert_ID();
        } else {

            //$idlink=$BaseD->GetOne("SELECT id FROM c_link WHERE c_id = ? AND url=? AND title=? AND category_id=?", array($curso, $url, $titulo, $idcat));
            $idlink = $link->fields["iid"];
        }

        $itemp = $BaseD->Execute("SELECT visibility FROM c_item_property WHERE tool = ? AND ref=? AND c_id=?", array('link', $idlink, $curso));

        if ($itemp->RecordCount() < 1) {
            $reg = $BaseD->GetRow("SHOW TABLE STATUS LIKE 'c_item_property'");
            $BaseD->Execute("INSERT c_item_property (c_id, id, tool, insert_user_id, insert_date, lastedit_date, ref, lastedit_type, lastedit_user_id, visibility) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", array($curso, $reg["Auto_increment"], 'link', $this->id_lms(), $DateOfRequest, $DateOfRequest, $idlink, 'LinkAdded', $this->id_lms(), 1));
        } else {
            if ($itemp->fields["visibility"] == 2) {
                $BaseD->Execute("UPDATE c_item_property SET lastedit_type = ?, visibility = ? WHERE tool = ? AND ref=? AND c_id=?", array('LinkAdded', 1, 'link', $idlink, $curso));
            }
        }

        $tl = $BaseD->Execute("SELECT links_id FROM track_e_links WHERE links_user_id = ? AND c_id= ? AND links_link_id= ?", array($this->id_lms(), $curso, $idlink));

        if ($tl->RecordCount() < 1) {
            $BaseD->Execute("INSERT INTO track_e_links (links_user_id, c_id, links_link_id) VALUES(?, ?, ?)", array($this->id_lms(), $curso, $idlink));
            $idtl = $BaseD->Insert_ID();
        } else {
            //$idtl=$BaseD->GetOne("SELECT links_id FROM track_e_links WHERE links_user_id = ? AND links_cours_id=? AND links_link_id=?", array($this->id(), $code, $idlink));
            $idtl = $tl->fields["links_id"];
        }
    }

    function NotificionesLMS()
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        $text = null;
        // $BaseD->Execute("");
        $cursos = $this->listar_cursos_lms();
        $curso_key = array_rand($cursos, 1);
        $curso = $cursos[$curso_key];
        include $CHML_CONFIG;
        //
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        // $BaseD->debug = true;
        $access = $BaseD->Execute("SELECT tea.*, u.id FROM track_e_access tea JOIN user u ON access_user_id = u.id WHERE tea.c_id = ? AND u.username=?", array($curso->id, $this->usuario()));
        if ($access->RecordCount() > 0) {
            $oldestTrackDate = $oldestTrackDateOrig = '3000-01-01 00:00:00';
            while (!$access->EOF) {
                $usuario_id = $access->fields['id'];
                $lastTrackInCourseDate[$access->fields['access_tool']] = $access->fields['access_date'];
                if ($oldestTrackDate > $access->fields['access_date']) {
                    $oldestTrackDate = $access->fields['access_date'];
                }
                $access->MoveNext();
            }

            if ($oldestTrackDate == $oldestTrackDateOrig) {
                $oldestTrackDate = $curso->creacion;
            }

            $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
            $noti = $BaseD->Execute("SELECT tet.*, tet.lastedit_date last_date, tet.tool tool, tet.ref ref, tet.lastedit_type type, tet.to_group_id group_id, ctt.image image, ctt.link link FROM c_item_property tet INNER JOIN c_tool ctt ON tet.c_id = ctt.c_id WHERE tet.c_id = ? AND tet.lastedit_date > ? AND (ctt.name = tet.tool OR (ctt.name = 'student_publication' AND tet.tool = 'work')) AND ctt.visibility = '1' AND tet.lastedit_user_id != ? AND (tet.session_id = 0 OR tet.session_id IS NULL) ORDER BY tet.lastedit_date", array($curso->id, $oldestTrackDate, $usuario_id));

            while (!$noti->EOF) {

                if ((!isset($lastTrackInCourseDate[$noti->fields['tool']])
                        || $lastTrackInCourseDate[$noti->fields['tool']] < $noti->fields['lastedit_date'])
                    && ($noti->fields['tool'] != 'notebook' && $noti->fields['tool'] != 'chat')
                    && ($noti->fields['visibility'] == '1' || !isset($noti->fields['visibility']))
                ) {
                    if (($noti->fields['tool'] == 'announcement' || $noti->fields['tool'] == 'calendar_event')
                        && ($noti->fields['to_user_id'] != $user_id)
                    ) {
                        continue;
                    }

                    if ($noti->fields['tool'] == 'survey') {
                        continue;
                    }
                    if ($noti->fields['tool'] == 'dropbox') {
                        $noti->fields['link'] = 'dropbox/dropbox_download.php?id=' . $noti->fields['ref'];
                    }

                    if (
                        $noti->fields['tool'] == 'work'
                        && $noti->fields['type'] == 'DirectoryCreated'
                    ) {
                        $noti->fields['lastedit_type'] = 'WorkAdded';
                    }
                    $notifications[$noti->fields['tool']] = $noti->fields;
                }
                $noti->MoveNext();
            }
            // $notifications;
            if ($notifications) {
                $text = "Tienes notificaciones en $curso->nombre ";
                foreach ($notifications as $notification) {
                    $text .= '<a href="//sie.educar.com.co/main/' .
                        $notification['link'] . '?&cidReq=' . $curso->codigo .
                        '&ref=' . $notification['ref'] .
                        '&gidReq=' . $notification['to_group_id'] .
                        '&id_session=' . $sessionId . '&gradebook=0&origin=" target="_blank">' . $notification['lastedit_type'] . '</a>' . "";
                }
            }
        } else {
            $text = "No has ingresado a " . $curso->nombre . "";
        }
        return $text;
    }

    function NotificacionesDrupalPL()
    {
        global $ADODB_TYPE, $DRPL_CONFIG;

        $text = null;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $DRPL_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');
        // $BaseD->debug =true;
        $LastAccess = $BaseD->GetRow("SELECT al.`timestamp` FROM `2016_drp_sie`.`accesslog` al JOIN `2016_drp_sie`.users u ON u.uid = al.uid WHERE u.name=? ORDER by al.`timestamp` DESC LIMIT 1", array($this->usuario));
        $LastDate = new DateTime("@$LastAccess[0]");
        $ActualDate = new DateTime();
        $LastDate->format('Y-m-d');
        $ActualDate->format('Y-m-d');
        $interval = $LastDate->diff($ActualDate);

        if ($interval->m >= 2) {
            # code...
            $text = "No has accedido a <a href='/planlector/' target='_blank'>Plan Lector</a> en $interval->m meses, recuerda que tienes muchos libros para leer";
        }
        return $text;
    }

    function NotificacionesDrupalGaleria()
    {
        global $ADODB_TYPE, $DRPL_GALERIA_CONFIG;

        $text = null;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $this->usuario());
        include $DRPL_GALERIA_CONFIG;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($databases['default']['default']['host'], $databases['default']['default']['username'], $databases['default']['default']['password'], $databases['default']['default']['database']);
        $BaseD->SetCharSet('utf8');
        // $BaseD->debug =true;
        $LastAccess = $BaseD->GetRow("SELECT al.`timestamp` FROM `accesslog` al JOIN users u ON u.uid = al.uid WHERE u.name=? ORDER by al.`timestamp` DESC LIMIT 1", array($this->usuario));
        $LastDate = new DateTime("@$LastAccess[0]");
        $ActualDate = new DateTime();
        $LastDate->format('Y-m-d');
        $ActualDate->format('Y-m-d');
        $interval = $LastDate->diff($ActualDate);
        if ($interval->m >= 2) {
            # code...
            $text = "No has accedido a <a href='/Galeria/' target='_blank'>Galeria</a> en $interval->m meses, recuerda que tienes muchos libros para leer";
        }
        return $text;
    }

    function MensajesSinLeer()
    {
        global $BaseD;
        $text = null;
        $mensajes = $BaseD->GetRow("SELECT count(*) as total FROM `mensajes` WHERE `id_destinatario`=?", array($this->id));
        if ($mensajes["total"] > 0) {
            $text = "Tienes " . $mensajes['total'] . " mensaje(s) sin leer";
        }
        return $text;
    }

    function notificaciones()
    {

        if ($html = $this->MensajesSinLeer()) {
            echo $html;
        } elseif ($html = $this->NotificionesLMS()) {
            echo $html;
        } elseif ($html = $this->NotificacionesDrupalPL()) {
            echo $html;
        } elseif ($html = $this->NotificacionesDrupalGaleria()) {
            echo $html;
        } else {
            echo "Hola $this->nombres ¿Qué vamos a hacer hoy?";
        }
    }

    function numero_notificaciones()
    {
        global $BaseD;
        $text = null;
        $mensajes = $BaseD->GetRow("SELECT count(*) as total FROM `mensajes` WHERE `id_destinatario`=?", array($this->id));
        if ($mensajes["total"] > 0) {
            $text = "" . $mensajes['total'] . "";
        }
        return $text;
    }

    /***********NOTIFICACIONES***********/

    function NotificionesLMS_Numero($id__)
    {
        // registro(__METHOD__, func_get_args(), $this);
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;

        $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        $numero = 0;
        $_SESSION['n-notification'] = $numero;
        $text = "";
        include('resources/php/traductor_mensages/traduccion.php');
        $cursos = $this->listar_cursos_lms();

        for ($i = 0; $i < sizeof($cursos); $i++) {
            $notifications = array();
            $curso = $cursos[$i];
            $access = $BaseD->Execute("SELECT tea.*, u.id FROM track_e_access tea JOIN user u ON access_user_id != u.id WHERE tea.c_id = ? AND u.username=?", array($curso->id, $this->usuario()));
            if ($access->RecordCount() > 0) {
                $oldestTrackDate = $oldestTrackDateOrig = '3000-01-01 00:00:00';
                while (!$access->EOF) {
                    $usuario_id = $access->fields['id'];
                    $lastTrackInCourseDate[$access->fields['access_tool']] = $access->fields['access_date'];
                    if ($oldestTrackDate > $access->fields['access_date']) {
                        $oldestTrackDate = $access->fields['access_date'];
                    }
                    $access->MoveNext();
                }

                if ($oldestTrackDate == $oldestTrackDateOrig) {
                    $oldestTrackDate = $curso->creacion;
                }

                $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
                $noti = $BaseD->Execute("SELECT tet.*, tet.iid, tet.visibility vis, tet.lastedit_date last_date, tet.tool tool, tet.ref ref, tet.lastedit_type type, tet.to_group_id group_id, ctt.image image, ctt.link link FROM c_item_property tet INNER JOIN c_tool ctt ON tet.c_id = ctt.c_id WHERE tet.c_id = ? AND tet.lastedit_date > ? AND (ctt.name = tet.tool OR (ctt.name = 'student_publication' AND tet.tool = 'work')) AND ctt.visibility = '1' AND tet.lastedit_user_id != ? AND (tet.session_id = 0 OR tet.session_id IS NULL) ORDER BY tet.lastedit_date", array($curso->id, $oldestTrackDate, $usuario_id));

                while (!$noti->EOF) {
                    if ((!isset($lastTrackInCourseDate[$noti->fields['tool']])
                            || $lastTrackInCourseDate[$noti->fields['tool']] < $noti->fields['lastedit_date'])
                        && ($noti->fields['tool'] != 'notebook' && $noti->fields['tool'] != 'chat')
                        && ($noti->fields['visibility'] == '1' || !isset($noti->fields['visibility']))
                    ) {
                        if ($noti->fields['tool'] == 'dropbox') {
                            //$noti->fields['link'] = 'dropbox/dropbox_download.php?id='.$noti->fields['ref'];
                        } elseif ($noti->fields['tool'] == 'work' && $noti->fields['type'] == 'DirectoryCreated') {
                            $noti->fields['lastedit_type'] = 'WorkAdded';
                        }
                        $notifications[$noti->fields['tool']] = $noti->fields;
                    }
                    $noti->MoveNext();
                }

                if ($notifications) {
                    foreach ($notifications as $notification) {
                        if ($traducion[$notification['tool']][$notification['lastedit_type']] != 'No mostrar') {
                            $id = $notification['iid'];
                            $user = $this->id;
                            $herramienta = $notification['tool'];
                            $estado = $notification['lastedit_type'];
                            $curso_ = $curso->nombre;
                            $existe = $BaseD->GetRow("SELECT * FROM notificaciones_chamilo WHERE herramienta = ? AND id_user = ? AND estado = ? AND curso = ?", array($herramienta, $user, $estado, $curso_));
                            if ($existe) {
                                if ($existe['visto'] == 0) {
                                    $numero++;
                                    $text = $text . $this->Notificacion_Link($id, $existe['id'], $notification['link'], $curso->codigo, $notification['ref'], $notification['to_group_id'], $sessionId, $notification['tool'], $traducion[$notification['tool']][$notification['lastedit_type']], $curso->nombre);
                                } else {
                                    if ($id > $existe['id_notificacion']) {
                                        $BaseD->Execute("UPDATE notificaciones_chamilo SET id_notificacion = ? , visto = '0' WHERE id = ?", array($id, $existe['id']));
                                        $numero++;
                                        $text = $text . $this->Notificacion_Link($id, $existe['id'], $notification['link'], $curso->codigo, $notification['ref'], $notification['to_group_id'], $sessionId, $notification['tool'], $traducion[$notification['tool']][$notification['lastedit_type']], $curso->nombre);
                                    }
                                }
                            } else {
                                $BaseD->Execute("INSERT INTO notificaciones_chamilo (id, id_notificacion, id_user, herramienta, estado, curso, visto) VALUES (null, ?, ?, ?, ?, ?, '0')", array($id, $user, $herramienta, $estado, $curso_));
                                $numero++;
                                $text = $text . $this->Notificacion_Link($id, $existe['id'], $notification['link'], $curso->codigo, $notification['ref'], $notification['to_group_id'], $sessionId, $notification['tool'], $traducion[$notification['tool']][$notification['lastedit_type']], $curso->nombre);
                            }
                        }
                    }
                } else { }
            } else { }
        }
        if ($numero == 0) {
            $text = "<li><a href='#'>No tienes notificaciones.</a></li>";
        }
        $this->Ingresar_elementos_cache($id__, "texto_n", $text);
        $this->Ingresar_elementos_cache($id__, "numero_n", $numero);
        //$_SESSION['notification'] = $text;
        //return $numero;
    }


    function Notificacion_Link($id, $eid, $link, $codigo, $ref, $to_group_id, $sessionId, $tool, $traducion, $nombre)
    {
        $t = "";
        $t = "<li><a href='/resources/php/request/notificaciones.php?notificacion=" . $eid . "&link=" . $link . "&cc=" . $codigo . "&ref=" . $ref . "&to_group_id=" . $to_group_id . "&id_session=" . $sessionId . "&id=" . $this->id() . "' target='_self'><img   src='/resources/imagen/notificaciones/" . $tool . ".png'>" . $traducion . " " . $nombre . "</a></li>";
        return $t;
    }

    function NotificacionInvisible($id_notificacion)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;
        $ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
        $BaseE = NewADOConnection($ADODB_TYPE);
        $BaseE->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseE->SetCharSet('utf8');
        $BaseE->Execute("UPDATE notificaciones_chamilo SET visto = '1' WHERE id = ?", array($id_notificacion));
    }

    function NotificionesLMS_final()
    {
        return $_SESSION['notification'];
    }

    /**********GAMIFICACION*************/

    function Puntaje($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM g_puntaje WHERE id_usuario = ?", array($id));
        if ($reg == true) {
            $puntaje = $reg['puntaje'];
        } else {
            $crear = $BaseD->Execute("INSERT INTO g_puntaje (id_usuario, puntaje, id_nivel) VALUES (?, '1', '1')", array($id));
            $puntaje = 1;
        }
        return $puntaje;
    }

    function Nivel($id)
    {
        global $BaseD;
        $reg0 = $BaseD->GetRow("SELECT * FROM g_puntaje WHERE id_usuario = ?", array($id));
        $puntaje = $reg0['puntaje'];
        $id_nivel_viejo = $reg0['id_nivel'];
        //echo $id_nivel_viejo;
        $reg = $BaseD->GetRow("SELECT * FROM g_nivel WHERE min <= ? AND ? <= max", array($puntaje, $puntaje));
        $result = 1;
        if ($reg == true) {
            $nivel_actual = $reg['id'];
            if ($id_nivel_viejo < $nivel_actual) {
                $reg1 = $BaseD->Execute("UPDATE g_puntaje SET id_nivel = ? WHERE id_usuario = ?", array($nivel_actual, $id));
                //$reg2 = $BaseD->GetRow("SELECT * FROM g_nivel WHERE id_nivel = ?", array($nivel_actual));
                $result = $nivel_actual;
            } else {
                $result = $reg['nombre'];
            }
        }
        $_SESSION['nivel'] = $result;
        $this->Ingresar_elementos_cache($id, "nivel_l", $result);
        //echo $result;
    }

    function Porcentaje_General($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM g_puntaje WHERE id_usuario = ?", array($id));

        if ($reg == true) {
            $puntaje = $reg['puntaje'];
            $id_nivel = $reg['id_nivel'];
        } else {
            $crear = $BaseD->Execute("INSERT INTO g_puntaje (id_usuario, puntaje, id_nivel) VALUES (?, '0', '1')", array($id));
            $puntaje = 1;
        }

        $reg1 = $BaseD->GetRow("SELECT * FROM g_nivel WHERE id = ?", array($id_nivel));
        $max = intval($reg1['max']);
        $min = intval($reg1['min']);

        /*if($porcentaje >= 100){
			$reg = $BaseD->Execute("UPDATE g_puntaje SET id_nivel = ? WHERE id_usuario = ?", array(($id_nivel+1),$id));
		}*/

        $porcentaje = (($max - ($max - $puntaje) - $min) * 100) / ($max - $min);

        /*echo $max."/";
		echo $min."/";
		echo $puntaje."/";*/
        $this->Ingresar_elementos_cache($id, "porsentaje_l", $porcentaje);
        //echo $porcentaje;
    }

    function Logros($id)
    {
        // registro(__METHOD__, func_get_args(), $this);
        global $BaseD;
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;
        $BaseE = NewADOConnection($ADODB_TYPE);
        $BaseE->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseE->SetCharSet('utf8');
        $mitex;
        $int = 0;
        $id_user = $this->id_lms();
        $nivel = isset($_SESSION['nivel']) ? $_SESSION['nivel'] : 0;
        $logros_totales = $BaseD->Execute("SELECT * FROM g_logro WHERE id_nivel = ?", array($nivel)); //cantidad de logros que existen
        while (!$logros_totales->EOF) { //recorrer los logros

            $id_logro = $logros_totales->fields['id']; //id del logro
            $titulo = $logros_totales->fields['titulo']; //titulo del logro
            $descripcion = $logros_totales->fields['descripcion']; //descripcion del logro
            $cantidad = $logros_totales->fields['cantidad']; //cantidad para completar el logro
            $herramienta = $logros_totales->fields['herramienta']; //herramienta a evaluar
            $filtro = $logros_totales->fields['filtro']; //filtro de la sentencia sql
            $valor = $logros_totales->fields['valor']; //valor o puntaje que tiene el logro

            $existe = $BaseD->GetRow("SELECT * FROM g_logro_usuario WHERE id_usuario = ? AND id_logro = ?", array($id, $id_logro)); //saber si los logros existen o no anclados al usuario
            if ($existe == true) { //si esisten
                if ($existe['completado'] == 0 && $existe['id_logro'] == $id_logro) {
                    $c = 0;
                    $imprimir;
                    //dependiendo la herramienta se ejecutara esta accion
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "work") {

                        $trabajos = $BaseE->Execute("SELECT * FROM c_item_property WHERE lastedit_user_id = ? AND lastedit_type = ? AND tool = ?", array($id_user, $filtro, $herramienta)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['iid'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //*****************************************************************************************************************	Listo
                    if ($herramienta == "link") {
                        $trabajos = $BaseE->Execute("SELECT DISTINCT links_link_id FROM track_e_links WHERE links_user_id = ?", array($id_user)); //filtro de tareas realizadas por el usuario
                        while (!$trabajos->EOF) {
                            $id_link = $trabajos->fields['links_link_id'];
                            $individual = $BaseE->GetRow("SELECT * FROM track_e_links WHERE links_link_id = ?", array($id_link));
                            $id_elemento = $individual['links_id'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "forum_post") {
                        $trabajos = $BaseE->Execute("SELECT * FROM c_item_property WHERE lastedit_user_id = ? AND lastedit_type = ? AND tool = ?", array($id_user, $filtro, $herramienta)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['iid'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "quiz") {
                        $trabajos = $BaseE->Execute("SELECT * FROM track_e_exercises WHERE exe_user_id = ?", array($id_user)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['exe_id'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //*****************************************************************************************************************
                    if ($herramienta == "avatar") {
                        if ($filtro == "accesorio") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND accesorio = ?", array($id, $cantidad));
                        } else if ($filtro == "boca") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND boca = ?", array($id, $cantidad));
                        } else if ($filtro == "cabello") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND cabello = ?", array($id, $cantidad));
                        } else if ($filtro == "cuerpo") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND cuerpo = ?", array($id, $cantidad));
                        } else if ($filtro == "ojos") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND ojos = ?", array($id, $cantidad));
                        } else if ($filtro == "ropa") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND ropa = ?", array($id, $cantidad));
                        }

                        if ($trabajos == true) {
                            $puntaje_actual = intval($this->Puntaje($id));
                            $puntaje_suma = intval($valor);
                            $puntaje_final = $puntaje_actual + $puntaje_suma;
                            $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                            $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje

                        }
                    }
                    //*****************************************************************************************************************
                    $actualizar_cantidad = $BaseD->Execute("UPDATE g_logro_usuario SET cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array($c, $id, $id_logro)); //actualizar en caso de completar las tareas
                    $porcentaje = (($c * 100) / $cantidad); //porcentaje
                    $mitex = $mitex . $this->logro_item($titulo, $descripcion, $porcentaje, 0, $herramienta);
                } else {
                    $mitex = $mitex . $this->logro_item($titulo, $descripcion, 0, 1, $herramienta);
                }
                $logros_final = $mitex;
            } else {
                $crear = $BaseD->Execute("INSERT INTO g_logro_usuario (id,id_usuario, id_logro, cantidad, completado) VALUES (NULL, ?, ?, '0','0')", array($id, $id_logro)); //crear tabla de almacenamiento en caso de no exiastir el logro anclado al usuario
                $porciento = ((0 * 100) / $cantidad);
                $mitex = $mitex . $this->logro_item($titulo, $descripcion, $porciento, 0, $herramienta);
                $logros_final = $mitex;
            }
            $logros_totales->MoveNext();
        }
        $this->Ingresar_elementos_cache($id, "logros_l", $logros_final);
        //echo $logros_final;
    }

    function Logros_faltantes($id)
    {
        global $BaseD;
        global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR;
        include $CHML_CONFIG;
        $BaseE = NewADOConnection($ADODB_TYPE);
        $BaseE->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseE->SetCharSet('utf8');
        $mitex;
        $int = 0;
        $id_user = $this->id_lms();
        $nivel = isset($_SESSION['nivel']) ? $_SESSION['nivel'] : 0;
        $logros_totales = $BaseD->Execute("SELECT * FROM g_logro WHERE id_nivel = ?", array($nivel)); //cantidad de logros que existen

        while (!$logros_totales->EOF) { //recorrer los logros

            $id_logro = $logros_totales->fields['id']; //id del logro
            $titulo = $logros_totales->fields['titulo']; //titulo del logro
            $descripcion = $logros_totales->fields['descripcion']; //descripcion del logro
            $cantidad = $logros_totales->fields['cantidad']; //cantidad para completar el logro
            $herramienta = $logros_totales->fields['herramienta']; //herramienta a evaluar
            $filtro = $logros_totales->fields['filtro']; //filtro de la sentencia sql
            $valor = $logros_totales->fields['valor']; //valor o puntaje que tiene el logro

            $existe = $BaseD->GetRow("SELECT * FROM g_logro_usuario WHERE id_usuario = ? AND id_logro = ?", array($id, $id_logro)); //saber si los logros existen o no anclados al usuario
            if ($existe == true) { //si esisten
                if ($existe['completado'] == 0 && $existe['id_logro'] == $id_logro) {
                    $c = 0;
                    $imprimir;
                    //dependiendo la herramienta se ejecutara esta accion
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "work") {

                        $trabajos = $BaseE->Execute("SELECT * FROM c_item_property WHERE lastedit_user_id = ? AND lastedit_type = ? AND tool = ?", array($id_user, $filtro, $herramienta)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['iid'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //*****************************************************************************************************************	Listo
                    if ($herramienta == "link") {
                        $trabajos = $BaseE->Execute("SELECT DISTINCT links_link_id FROM track_e_links WHERE links_user_id = ?", array($id_user)); //filtro de tareas realizadas por el usuario
                        while (!$trabajos->EOF) {
                            $id_link = $trabajos->fields['links_link_id'];
                            $individual = $BaseE->GetRow("SELECT * FROM track_e_links WHERE links_link_id = ?", array($id_link));
                            $id_elemento = $individual['links_id'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "forum_post") {
                        $trabajos = $BaseE->Execute("SELECT * FROM c_item_property WHERE lastedit_user_id = ? AND lastedit_type = ? AND tool = ?", array($id_user, $filtro, $herramienta)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['iid'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //***************************************************************************************************************** Listo
                    if ($herramienta == "quiz") {
                        $trabajos = $BaseE->Execute("SELECT * FROM track_e_exercises WHERE exe_user_id = ?", array($id_user)); //filtro de tareas realizadas por el usuario

                        while (!$trabajos->EOF) {
                            $id_elemento = $trabajos->fields['exe_id'];
                            $validacion = $BaseE->GetRow("SELECT * FROM log_logros_avatar WHERE id_elemento = ?", array($id_elemento));
                            if (!$validacion) {
                                $BaseE->Execute("INSERT INTO log_logros_avatar (id,id_user, nivel, id_elemento, id_logro) VALUES (NULL,?,?,?,?)", array($id_user, $nivel, $id_elemento, $id_logro)); //insertar logro en caso de no averlo registrado
                                $c++;
                            } else {
                                if ($validacion['id_logro'] == $id_logro) {
                                    $c++;
                                }
                            }
                            if ($c == $cantidad) {
                                $puntaje_actual = intval($this->Puntaje($id));
                                $puntaje_suma = intval($valor);
                                $puntaje_final = $puntaje_actual + $puntaje_suma;
                                $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                                $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                                break;
                            }
                            $trabajos->MoveNext();
                        }
                    }
                    //*****************************************************************************************************************
                    if ($herramienta == "avatar") {
                        if ($filtro == "accesorio") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND accesorio = ?", array($id, $cantidad));
                        } else if ($filtro == "boca") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND boca = ?", array($id, $cantidad));
                        } else if ($filtro == "cabello") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND cabello = ?", array($id, $cantidad));
                        } else if ($filtro == "cuerpo") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND cuerpo = ?", array($id, $cantidad));
                        } else if ($filtro == "ojos") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND ojos = ?", array($id, $cantidad));
                        } else if ($filtro == "ropa") { //filtro de tareas realizadas por el usuario
                            $trabajos = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ? AND ropa = ?", array($id, $cantidad));
                        }

                        if ($trabajos == true) {
                            $puntaje_actual = intval($this->Puntaje($id));
                            $puntaje_suma = intval($valor);
                            $puntaje_final = $puntaje_actual + $puntaje_suma;
                            $actualizar_logro = $BaseD->Execute("UPDATE g_logro_usuario SET completado = ?, cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array('1', $cantidad, $id, $id_logro)); //actualizar en caso de completar las tareas
                            $sumar = $BaseD->Execute("UPDATE g_puntaje SET puntaje = ? WHERE id_usuario = ?", array($puntaje_final, $id)); //sumar puntaje
                        }
                    }
                    //*****************************************************************************************************************
                    $actualizar_cantidad = $BaseD->Execute("UPDATE g_logro_usuario SET cantidad = ? WHERE id_usuario = ? AND id_logro = ?", array($c, $id, $id_logro)); //actualizar en caso de completar las tareas
                    $porcentaje = (($c * 100) / $cantidad); //porcentaje
                    if ($herramienta == "work") {
                        $imagen = "08";
                    } else if ($herramienta == "forum_post") {
                        $imagen = "09";
                    } else if ($herramienta == "avatar") {
                        $imagen = "10";
                    } else if ($herramienta == "quiz") {
                        $imagen = "11";
                    } else if ($herramienta == "link") {
                        $imagen = "12";
                    }
                    $logros_final .= "<li><img class='logo-por_' src='/resources/imagen/gamificacion/logros/Gamificacion-" . $imagen . ".png' height='50px' width='50px'><div class='content_logo2'><h5>" . $titulo . "</h5><h6>" . $descripcion . "</h6><div class='fondo_porcentaje2'><div style='width: " . $porcentaje . "%' class='porcentage_logo'></div></div></div></li>";
                } else { }
            } else {
                $crear = $BaseD->Execute("INSERT INTO g_logro_usuario (id,id_usuario, id_logro, cantidad, completado) VALUES (NULL, ?, ?, '0','0')", array($id, $id_logro)); //crear tabla de almacenamiento en caso de no exiastir el logro anclado al usuario
                $porcentaje = ((0 * 100) / $cantidad);
                $logros_final .= "<li><img class='logo-por_' src='/resources/imagen/gamificacion/logros/Gamificacion-" . $imagen . ".png' height='50px' width='50px'><div class='content_logo2'><h5>" . $titulo . "</h5><h6>" . $descripcion . "</h6><div class='fondo_porcentaje'><div style='width: " . $posciento . "%' class='porcentage_logo'></div></div></div></li>";
            }
            $logros_totales->MoveNext();
        }
        echo $logros_final;
    }

    function logro_item($titulo, $descripcion, $posciento, $tipo, $herramienta)
    {
        if ($herramienta == "work") {
            $imagen = "08";
        } else if ($herramienta == "forum_post") {
            $imagen = "09";
        } else if ($herramienta == "avatar") {
            $imagen = "10";
        } else if ($herramienta == "quiz") {
            $imagen = "11";
        } else if ($herramienta == "link") {
            $imagen = "12";
        }
        if ($tipo == 0) {
            $t = "<li><img class='logo-por' src='/resources/imagen/gamificacion/logros/Gamificacion-" . $imagen . ".png' height='50px' width='50px'><div class='content_logo'><h5>" . $titulo . "</h5><h6>" . $descripcion . "</h6><div class='fondo_porcentaje'><div style='width: " . $posciento . "%' class='porcentage_logo'></div></div></div></li>";
        } else {
            $t = "<li><img class='logo-por' src='/resources/imagen/gamificacion/logros/Gamificacion-" . $imagen . ".png' height='50px' width='50px'><div class='content_logo'><h5>" . $titulo . "</h5><h5>completado</h5><h6>" . $descripcion . "</h6></li>";
        }
        return $t;
    }

    function logro_item_generico($id)
    {
        global $BaseD;
        $logros_totales = $BaseD->Execute("SELECT * FROM g_logro_usuario WHERE id_usuario = ? AND completado = 1", array($id));
        $t = "";
        while (!$logros_totales->EOF) { //recorrer los logros
            $id_logro = $logros_totales->fields['id_logro']; //id del logro
            $logro_ = $BaseD->GetRow("SELECT * FROM g_logro WHERE id = ?", array($id_logro));
            $herramienta = $logro_['herramienta'];
            $id_logro = $logro_['id']; //id del logro
            $titulo = $logro_['titulo']; //titulo del logro
            $descripcion = $logro_['descripcion']; //descripcion del logro
            $cantidad = $logro_['cantidad']; //cantidad para completar el logro
            $herramienta = $logro_['herramienta']; //herramienta a evaluar
            $filtro = $logro_['filtro']; //filtro de la sentencia sql
            $valor = $logro_['valor']; //valor o puntaje que tiene el logro
            if ($herramienta == "work") {
                $imagen = "1";
            } else if ($herramienta == "forum_post") {
                $imagen = "2";
            } else if ($herramienta == "avatar") {
                $imagen = "3";
            } else if ($herramienta == "quiz") {
                $imagen = "4";
            } else if ($herramienta == "link") {
                $imagen = "5";
            }
            $t .= "<li><img class='logo-por_' src='/resources/imagen/gamificacion/logro_realizado/t" . $imagen . ".png' height='50px' width='50px'><div class='content_logo_2'><h5>" . $titulo . "</h5><h6>" . $descripcion . "</h6></div></li>";
            $logros_totales->MoveNext();
        }
        echo $t;
    }

    function Max_Puntaje($id)
    {
        global $BaseD;
        $reg0 = $BaseD->GetRow("SELECT * FROM g_puntaje WHERE id_usuario = ?", array($id));
        $puntaje = $reg0['puntaje'];
        $id_nivel_viejo = $reg0['id_nivel'];
        //echo $id_nivel_viejo;
        $reg = $BaseD->GetRow("SELECT * FROM g_nivel WHERE min <= ? AND ? <= max", array($puntaje, $puntaje));
        $result = $reg['max'];
        return $result;
    }

    /************************/

    function Ingresar_elementos_cache($idn, $tabla, $dato)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM notificaciones_cache WHERE id = ?", array($idn));
        if ($reg) { } else {
            $reg1 = $BaseD->Execute("INSERT INTO notificaciones_cache (id, numero_n, texto_n, nivel_l, porsentaje_l, logros_l) VALUES (?, '', '', '', '', '')", array($idn));
        }
        $reg2 = $BaseD->Execute("UPDATE notificaciones_cache SET " . $tabla . " = ? WHERE id = ?", array($dato, $idn));
        $_SESSION['' . $tabla] == $dato;
    }

    function Datos_elementos_cache($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM notificaciones_cache WHERE id = ?", array($id));
        if ($reg) {
            $_SESSION['numero_n'] = $reg['numero_n'];
            $_SESSION['texto_n'] = $reg['texto_n'];
            $_SESSION['nivel_l'] = $reg['nivel_l'];
            $_SESSION['porsentaje_l'] = $reg['porsentaje_l'];
            $_SESSION['logros_l'] = $reg['logros_l'];
        } else {
            $reg1 = $BaseD->Execute("INSERT INTO notificaciones_cache (id, numero_n, texto_n, nivel_l, porsentaje_l, logros_l) VALUES (?, '', '', '', '', '')", array($id));
        }
    }

    function gNotificaciones_n()
    {
        return isset($_SESSION['numero_n']) ? $_SESSION['numero_n'] : "";
    }

    function gNotificaciones()
    {
        return isset($_SESSION['texto_n']) ? $_SESSION['texto_n'] : "";
    }

    function gNivel()
    {
        return isset($_SESSION['nivel_l']) ? $_SESSION['nivel_l'] : "";
    }

    function gPorcentaje()
    {
        return isset($_SESSION['porsentaje_l']) ? $_SESSION['porsentaje_l'] : "";
    }

    function gLogros()
    {
        return isset($_SESSION['logros_l']) ? $_SESSION['logros_l'] : "";
    }

    /************************/

    /**************Informes************/
    function AssesosBliblioteca($args, $usuario)
    {
        global $ADODB_TYPE, $DB_HOST, $USER_CONSULTA, $PASS_CONSULTA, $DB_DB;
        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($DB_HOST, $USER_CONSULTA, $PASS_CONSULTA, $DB_DB);
        $BaseD->SetCharSet('utf8');
        $consulta = "SELECT COUNT(ac.timestamp)
					FROM 2016_drp_sie.accesslog AS ac
					JOIN 2016_drp_sie.users AS users
					ON ac.uid = users.uid
					WHERE
					users.name = '" . $usuario . "' AND
					ac.title='Inicio' AND
					CONVERT_TZ(FROM_UNIXTIME(ac.timestamp),'+00:00','-05:00') >= ? AND CONVERT_TZ(FROM_UNIXTIME(ac.timestamp),'+00:00','-05:00') <= ?";
        $rs = $BaseD->GetOne($consulta, $args);
        return $rs;
    }

    /*******************App SIE*********************/
    /****  HECTOR GOMEZ  ******/

    function sendMessageAppGeneral($mensaje, $id)
    {
        global $BaseD;
        $device = "";
        $devices = array();
        $lista = $BaseD->Execute("SELECT * FROM usuarios_dispositivos WHERE colegio = ?", array($id));
        while (!$lista->EOF) {
            $device = $lista->fields['player_id'];
            array_push($devices, $device);
            $lista->MoveNext();
        }
        $content = array(
            "en" => $mensaje
        );
        // ZDE3NDA2NDQtYjczNS00ZGIyLTgyOWItNTdhZDFjZjE2ZTlm
        $fields = array(
            'app_id' => "78b6cc76-945b-4b3b-8616-0d6d20e566dd",
            'include_player_ids' => $devices,
            'data' => array("foo" => "bar"),
            'large_icon' => "",
            'contents' => $content
        );
        $fields = json_encode($fields);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ZDE3NDA2NDQtYjczNS00ZGIyLTgyOWItNTdhZDFjZjE2ZTlm'
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        // return $response;
    }

    function sendMessageApp($mensaje, $id)
    {
        global $BaseD;
        $device = "";
        $devices = array();
        $lista = $BaseD->Execute("SELECT * FROM usuarios_dispositivos WHERE usuario = ?", array($id));
        while (!$lista->EOF) {
            $device = $lista->fields['player_id'];
            array_push($devices, $device);
            $lista->MoveNext();
        }
        $content = array(
            "en" => $mensaje
        );
        $fields = array(
            'app_id' => "78b6cc76-945b-4b3b-8616-0d6d20e566dd",
            'include_player_ids' => $devices,
            'data' => array("foo" => "bar"),
            'large_icon' => "",
            'contents' => $content
        );
        $fields = json_encode($fields);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic ZDE3NDA2NDQtYjczNS00ZGIyLTgyOWItNTdhZDFjZjE2ZTlm'
        ));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);
        // return $response;
    }

    function GetAppNivel($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM notificaciones_cache WHERE id = ?", array($id));
        return $reg['nivel_l'];
    }

    function GetAppPorcentaje($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM g_puntaje WHERE id_usuario = ?", array($id));
        if ($reg == true) {
            $puntaje = $reg['puntaje'];
            $id_nivel = $reg['id_nivel'];
        } else {
            $crear = $BaseD->Execute("INSERT INTO g_puntaje (id_usuario, puntaje, id_nivel) VALUES (?, '0', '1')", array($id));
            $puntaje = 1;
        }
        $reg1 = $BaseD->GetRow("SELECT * FROM g_nivel WHERE id = ?", array($id_nivel));
        $max = intval($reg1['max']);
        $min = intval($reg1['min']);
        $porcentaje = (($max - ($max - $puntaje) - $min) * 100) / ($max - $min);
        return $porcentaje;
    }

    function AppTeacherImage($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `imagen_usuario` WHERE `id_user` = ?", array($id));
        return $reg['imagen'];
    }

    function AppTeacherType($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `imagen_usuario` WHERE `id_user` = ?", array($id));
        return $reg['tipo'];
    }

    function AppLogoImage($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_icon` WHERE `id_colegio` = ?", array($id));
        return $reg['data'];
    }

    function AppLogoType($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_icon` WHERE `id_colegio` = ?", array($id));
        return $reg['type'];
    }

    function AppFondoImage($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_image_inst` WHERE `id_colegio` = ?", array($id));
        return $reg['data'];
    }

    function AppFondoType($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_image_inst` WHERE `id_colegio` = ?", array($id));
        return $reg['type'];
    }

    function AppNewsImage($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_news` WHERE `id` = ?", array($id));
        return $reg['data'];
    }

    function AppNewsType($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_news` WHERE `id` = ?", array($id));
        return $reg['type'];
    }

    function AddAppDevice($id, $device, $id_col)
    {
        global $BaseD;
        $res = $BaseD->GetRow("SELECT * FROM `usuarios_dispositivos` WHERE `player_id` = ?", array($device));
        if ($res) {
            $mid = $res['usuario'];
            if ($mid != $id) {
                $res1 = $BaseD->Execute("DELETE FROM `usuarios_dispositivos` WHERE `usuario` = ?", array($mid));
                if ($res1) {
                    $BaseD->Execute("INSERT INTO `usuarios_dispositivos` (`usuario`, `player_id`,`colegio`) VALUES (?, ?, ?)", array($id, $device, $id_col));
                }
            }
        } else {
            $BaseD->Execute("INSERT INTO `usuarios_dispositivos` (`usuario`, `player_id`,`colegio`) VALUES (?, ?, ?)", array($id, $device, $id_col));
        }
    }

    function AddAppEvent($id_ins, $mifecha, $titulo, $descripcion)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("INSERT INTO `app_calendar` (`id`, `id_colegio`, `fecha`, `titulo`, `descripcion`) VALUES (NULL, ?, ?, ?, ?)", array($id_ins, $mifecha, $titulo, $descripcion));
    }

    function AddAppNews($id_ins, $data, $type, $titulo, $fecha, $descripcion)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("INSERT INTO `app_news` (`id`, `id_colegio`, `fecha`, `titulo`, `descripcion`, `data`, `type`) VALUES (NULL, ?, ?, ?, ?, ?, ?)", array($id_ins, $fecha, $titulo, $descripcion, $data, $type));
    }

    function AddAppAdvertisements($id_ins, $titulo, $descripcion, $mifecha, $mihora, $tipo)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("INSERT INTO `app_advertisements` (`id`, `id_colegio`, `titulo`, `descripcion`, `fecha`, `hora`, `tipo`) VALUES (NULL, ?, ?, ?, ?, ?, ?)", array($id_ins, $titulo, $descripcion, $mifecha, $mihora, $tipo));
    }

    function AddAppLogo($id_ins, $data, $type)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_icon` WHERE `id_colegio` = ?", array($id_ins));
        if ($reg) {
            $reg1 = $BaseD->GetRow("UPDATE `app_icon` SET `data` = ? , `type` = ? WHERE `id_colegio` = ?", array($data, $type, $id_ins));
        } else {
            $reg = $BaseD->GetRow("INSERT INTO `app_icon` (`id`, `id_colegio`, `data`, `type`) VALUES (NULL, ?, ?, ?)", array($id_ins, $data, $type));
        }
    }

    function AddAppImage($id_ins, $data, $type)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_image_inst` WHERE `id_colegio` = ?", array($id_ins));
        if ($reg) {
            $reg1 = $BaseD->GetRow("UPDATE `app_image_inst` SET `data` = ? , `type` = ? WHERE `id_colegio` = ?", array($data, $type, $id_ins));
        } else {
            $reg = $BaseD->GetRow("INSERT INTO `app_image_inst` (`id`, `id_colegio`, `data`, `type`) VALUES (NULL, ?, ?, ?)", array($id_ins, $data, $type));
        }
    }

    function AddAppDataBase($id_ins, $telefono, $correo, $pagina, $ubicacion)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM `app_config` WHERE `id_colegio` = ?", array($id_ins));
        if ($reg) {
            $reg1 = $BaseD->GetRow("UPDATE `app_config` SET `telefono` = ? , `correo` = ?, `pagina` = ?, `ubicacion` = ? WHERE `id_colegio` = ?", array($telefono, $correo, $pagina, $ubicacion, $id_ins));
        } else {
            $reg1 = $BaseD->GetRow("INSERT INTO `app_config` (`id`, `id_colegio`, `anuncios`, `calendario`, `noticias`, `telefono`, `correo`, `pagina`, `ubicacion`) VALUES (NULL, ?, '0', '0', '0', ?, ?, ?, ?)", array($id_ins, $telefono, $correo, $pagina, $ubicacion));
        }
    }

    function EditAppEvent($id, $mifecha, $titulo, $descripcion)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("UPDATE `app_calendar` SET `fecha` = ? , `titulo` = ?, `descripcion` = ? WHERE `id` = ?", array($mifecha, $titulo, $descripcion, $id));
    }

    function EditAppNews($id, $data, $type, $titulo, $fecha, $descripcion)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("UPDATE `app_news` SET `fecha` = ? , `titulo` = ?, `descripcion` = ?, `data` = ?, `type` = ? WHERE `id_colegio` = ?", array($fecha, $titulo, $descripcion, $data, $type, $id));
    }

    function EditAppAdvertisements($id, $titulo, $descripcion, $mifecha, $mihora, $tipo)
    {
        global $BaseD;
        $BaseD->GetRow("UPDATE `app_advertisements` SET `fecha` = ? , `titulo` = ?, `descripcion` = ?, `hora` = ? WHERE `id` = ?", array($mifecha, $titulo, $descripcion, $mihora, $id));
    }

    function DeleteAppEvent($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("DELETE FROM `app_calendar` WHERE `app_calendar`.`id` = ?", array($id));
    }

    function DeleteAppNews($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("DELETE FROM `app_news` WHERE `app_news`.`id` = ?", array($id));
    }

    function DeleteAppAdvertisements($id)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("DELETE FROM `app_advertisements` WHERE `app_advertisements`.`id` = ?", array($id));
    }

    function ListAppEvent($id)
    {
        global $BaseD;
        $t = "";
        $lista = $BaseD->Execute("SELECT * FROM app_calendar WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $id_colegio = $lista->fields['id_colegio'];
            $fecha = $lista->fields['fecha'];
            $titulo = $lista->fields['titulo'];
            $descripcion = $lista->fields['descripcion'];
            $mid = $lista->fields['id'];
            $t = $t . '<tr><td><p>' . $titulo . '<p></td><td><p>' . $fecha . '<p></td><td><a href="edit.php?pos=1&id=' . $mid . '" class="app-btn-edit"></a><a class="app-btn-delete" href="trice.php?eliminar=1&id=' . $mid . '"></a></td></tr>';
            $lista->MoveNext();
        }
        return $t;
    }

    function ListAppNews($id)
    {
        global $BaseD;
        $t = "";
        $lista = $BaseD->Execute("SELECT * FROM app_news WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $id_colegio = $lista->fields['id_colegio'];
            $fecha = $lista->fields['fecha'];
            $titulo = $lista->fields['titulo'];
            $descripcion = $lista->fields['descripcion'];
            $mid = $lista->fields['id'];
            $t = $t . '<tr><td><p>' . $titulo . '<p></td><td><p>' . $fecha . '<p></td><td><a class="app-btn-edit" href="edit.php?pos=2&id=' . $mid . '"></a><a class="app-btn-delete" href="trice.php?eliminar=2&id=' . $mid . '"></a></td></tr>';
            $lista->MoveNext();
        }
        return $t;
    }

    function ListAppCalendarJson($id)
    {
        global $BaseD;
        $nlista = array();
        $lista = $BaseD->Execute("SELECT * FROM app_calendar WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $objeto = new stdClass();
            $objeto->id_colegio = $lista->fields['id_colegio'];
            $objeto->fecha = $lista->fields['fecha'];
            $objeto->titulo = $lista->fields['titulo'];
            $objeto->descripcion = $lista->fields['descripcion'];
            $objeto->mid = $lista->fields['id'];
            array_push($nlista, $objeto);
            $lista->MoveNext();
        }
        return $nlista;
    }

    function ListAppNewsJson($id)
    {
        global $BaseD;
        $nlista = array();
        $lista = $BaseD->Execute("SELECT * FROM app_news WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $objeto = new stdClass();
            $objeto->id_colegio = $lista->fields['id_colegio'];
            $objeto->fecha = $lista->fields['fecha'];
            $objeto->titulo = $lista->fields['titulo'];
            $objeto->descripcion = $lista->fields['descripcion'];
            $objeto->mid = $lista->fields['id'];
            array_push($nlista, $objeto);
            $lista->MoveNext();
        }
        return $nlista;
    }

    function ListAppAdvertisements($id)
    {
        global $BaseD;
        $t = "";
        $lista = $BaseD->Execute("SELECT * FROM app_advertisements WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $id_colegio = $lista->fields['id_colegio'];
            $fecha = $lista->fields['fecha'];
            $titulo = $lista->fields['titulo'];
            $descripcion = $lista->fields['descripcion'];
            $mid = $lista->fields['id'];
            $t = $t . '<tr><td><p>' . $titulo . '<p></td><td><p>' . $fecha . '<p></td><td><a class="app-btn-edit" href="edit.php?pos=3&id=' . $mid . '"></a><a class="app-btn-delete" href="trice.php?eliminar=3&id=' . $mid . '"></a></td></tr>';
            $lista->MoveNext();
        }
        return $t;
    }

    function ListAppAdvertisementsJson($id)
    {
        global $BaseD;
        $mlista = array();
        $lista = $BaseD->Execute("SELECT * FROM app_advertisements WHERE id_colegio = ? ", array($id));
        while (!$lista->EOF) {
            $objeto = new stdClass();
            $objeto->id_colegio = $lista->fields['id_colegio'];
            $objeto->fecha = $lista->fields['fecha'];
            $objeto->titulo = $lista->fields['titulo'];
            $objeto->descripcion = $lista->fields['descripcion'];
            $objeto->mid = $lista->fields['id'];
            $objeto->tipo = $lista->fields['tipo'];
            array_push($mlista, $objeto);
            $lista->MoveNext();
        }
        return $mlista;
    }

    function ListAppLogros($id)
    {
        global $BaseD;
        $nlista = array();
        $lista = $BaseD->Execute("SELECT * FROM g_logro_usuario WHERE id_usuario = ? ", array($id));
        while (!$lista->EOF) {
            if ($lista->fields['completado'] == 1) {
                $objeto = new stdClass();
                $objeto->id_logro = $lista->fields['id_logro'];
                $row = $BaseD->GetRow("SELECT * FROM g_logro WHERE id = ? ", array($objeto->id_logro));
                $objeto->titulo = $row['titulo'];
                $objeto->descripcion = $row['descripcion'];
                $objeto->tool = $row['herramienta'];
                array_push($nlista, $objeto);
            }
            $lista->MoveNext();
        }
        return $nlista;
    }

    function ListAppLogrosFaltantes($id)
    {
        global $BaseD;
        $nlista = array();
        $lista = $BaseD->Execute("SELECT * FROM g_logro_usuario WHERE id_usuario = ? ", array($id));
        while (!$lista->EOF) {
            if ($lista->fields['completado'] == 0) {
                $objeto = new stdClass();
                $objeto->cantidad = $lista->fields['cantidad'];
                $objeto->id_logro = $lista->fields['id_logro'];
                $row = $BaseD->GetRow("SELECT * FROM g_logro WHERE id = ? ", array($objeto->id_logro));
                $objeto->total = $row['cantidad'];
                $objeto->titulo = $row['titulo'];
                $objeto->descripcion = $row['descripcion'];
                $objeto->tool = $row['herramienta'];
                $objeto->porcentaje = ($objeto->cantidad * 100) / $objeto->total;
                array_push($nlista, $objeto);
            }
            $lista->MoveNext();
        }
        return $nlista;
    }

    function ListAppConfig($id)
    {
        global $BaseD;
        $lista = $BaseD->GetRow("SELECT * FROM app_config WHERE id_colegio = ? ", array($id));
        $objeto = new stdClass();
        $objeto->telefono = $lista['telefono'];
        $objeto->correo = $lista['correo'];
        $objeto->pagina = $lista['pagina'];
        $objeto->ubicacion = $lista['ubicacion'];
        return $objeto;
    }
    /*****************************************/

    function solicitar_contra_app()
    {
        global $BaseD;
        if ($this->id() != -100) {
            do {
                $token = sha1(mt_rand(10000000, 1000000000));
                $reg = $BaseD->Execute("INSERT INTO solicitud_claves (token, usuario, solicitud, ip_solicitud) VALUES (?, ?, NOW(), ?)", array($token, $this->usuario, $_SERVER['REMOTE_ADDR']));
                $e = ADODB_Pear_Error();
            } while ($e->code == 1062);

            $col = new Institucion($this->idInstitucion);
            $txt_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "\r\n\r\nAlguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:\r\n\r\n\r\n
			http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\r\n\r\n\r\n\r\n
			Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            $html_msg = "Estimado(a) " . $this->nombres . " " . $this->apellidos . "<BR><BR>Alguien (seguramente tú), ha solicitado un cambio de contraseña en nuestra plataforma " . $col->personalizacion("plataforma") . ", si fuiste tú quien realmente la solicito porque seguramente olvidaste la registrada, por favor sigue el vínculo a continuación o copia y pegalo en tu navegador:<BR><BR><BR>
			<A href=\"http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token\">http://localhost/confirma.php?usuario=" . $this->usuario . "&acode=$token</A><BR><BR><BR>Si no fuiste tú, por favor ignora este mensaje con tranquilidad";
            enviar_correo('noreply@educar.com.co', $this->correo, $this->nombres . " " . $this->apellidos, $txt_msg, $html_msg, "Cambio Contraseña " . $col->personalizacion("plataforma"), true); //correo usuario
        }
    }
    /********************************/

    /**********Guardar los recursos que se tienen**********/
    function ScoreResources($nameResource, $score, $time, $grado, $materia)
    {
        /*
      global $BaseD;
      $fecha = localtime();
      $id_usuario = this->id();
      $guardar = $BaseD->Execute("INSERT INTO r_resources (id, id_usuario, grado, materia, tiempo, puntaje, nombre_recurso, fecha) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)", array($id, $id_usuario, $grado, $materia, $time, $score, $nameResource, $fecha));
         */ }
}

class Plataforma
{
    protected $id;
    protected $nombre;
    function __construct($id = "", $nombre = "")
    {
        global $BaseD;
        if (!empty($id) || !empty($nombre)) {
            $res = $BaseD->Execute("SELECT * from plataformas where id = ? OR nombre = ?", array($id, $nombre));
            if ($res->RecordCount() > 0) {
                $this->id = $res->fields["id"];
                $this->nombre = $res->fields["nombre"];
            }
        }
    }

    function id()
    {
        return ($this->id);
    }

    function nombre()
    {
        return ($this->nombre);
    }

    function es_meli()
    {
        if ($this->nombre == "MELI") {
            return (true);
        } else {
            return (false);
        }
    }

    function es_sie()
    {
        if ($this->nombre == "SIE") {
            return (true);
        } else {
            return (false);
        }
    }

    function es_sieplus()
    {
        if ($this->nombre == "SIEPLUS") {
            return (true);
        } else {
            return (false);
        }
    }

    function es_educlass()
    {
        $educlass = isset($_SESSION['educlass']) ? $_SESSION['educlass'] : false;
        if ($this->nombre == "EDUCLASS" || $educlass) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_newsie()
    {
        $newsie = isset($_SESSION['newsie']) ? $_SESSION['newsie'] : false;
        if ($this->nombre == "SIE2017" || $newsie) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_comprende()
    {
        $comprende = isset($_SESSION['comprende']) ? $_SESSION['comprende'] : false;
        if ($this->nombre == "COMPRENDE" || $comprende) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_guiandote()
    {
        $guiandote = isset($_SESSION['guiandote']) ? $_SESSION['guiandote'] : false;
        if ($this->nombre == "GUIANDOTE" || $guiandote) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_diveraprende()
    {
        $diveraprende = isset($_SESSION['diveraprende']) ? $_SESSION['diveraprende'] : false;
        if ($this->nombre == "DIVERAPRENDE" || $diveraprende) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_saber()
    {
        $tusaber = isset($_SESSION['tusaber']) ? $_SESSION['tusaber'] : false;
        if ($this->nombre == "SABER" || $tusaber) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_tdigitales()
    {
        if ($this->nombre == "TDIGITALES") {
            return (true);
        } else {
            return (false);
        }
    }

    function es_dulcessuenos()
    {
        $dulcessuenos1 = isset($_SESSION['dulcessuenos1']) ? $_SESSION['dulcessuenos1'] : false;
        $dulcessuenos2 = isset($_SESSION['dulcessuenos2']) ? $_SESSION['dulcessuenos2'] : false;
        if ($this->nombre == "DULCESSUENOS" || $dulcessuenos1 || $dulcessuenos2) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_biblioteca()
    {
        $biblioteca = isset($_SESSION['biblioteca']) ? $_SESSION['biblioteca'] : false;
        if ($this->nombre == "BIBLIOTECA" || $biblioteca) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_preschool()
    {
        $preschool = isset($_SESSION['preschool']) ? $_SESSION['preschool'] : false;
        if ($preschool) {
            return (true);
        } else {
            return (false);
        }
    }

    function es_nuevo_saber()
    {
        if ($this->nombre == "NUEVOSABER") {
            return (true);
        } else {
            return (false);
        }
    }

    function crear_plataforma($nombre)
    {
        global $BaseD;
        if ($BaseD->GetRow("insert into plataformas (nombre) values (?)", array($nombre))) {
            return (true);
        } else {
            return (false);
        }
    }

    function eliminar_plataforma($id)
    { }

    function listar_plataformas()
    {
        global $BaseD;
        $res = $BaseD->Execute("SELECT * from plataformas");
        $lista = array();
        if ($res) {
            while (!$res->EOF) {
                $obj = new stdClass();
                $obj->id = $res->fields["id"];
                $obj->nombre = $res->fields["nombre"];
                $lista[] = $obj;
                $res->MoveNext();
            }
        }
        return $lista;
    }
}

class Pin
{
    protected $consecutivo = null;
    protected $grado = null;
    protected $creado_por = null;
    protected $creado_en = null;
    protected $activado_por = null;
    protected $activado_en = null;
    protected $pin = null;
    protected $pre_activado = null;
    protected $maxima_activacion = null;
    protected $maxima_usuario = null;

    function __construct()
    {
        //__construct ($pin)
        //__construct ($curso, $quien)
        //__construct ($curso, $quien, $maxima_activacion, $maxima_usuario)
        global $BaseD, $AÑO_ACTIVO;

        //$BaseD->debug = true;
        $args = func_get_args();
        setlocale(LC_TIME, "es_CO.UTF-8");

        if (func_num_args() == 1) {
            $res = $BaseD->GetRow("SELECT curso, creado_por, creado_en, activado_por, activado_en, pre_activado, maxima_activacion, maxima_usuario FROM pines WHERE pin = ?", array($args[0]));
            if ($res) {
                $this->pin = $args[0];
                $this->grado = $res['curso'];
                $this->creado_por = $res['creado_por'];
                $this->creado_en = $res['creado_en'];
                $this->activado_por = $res['activado_por'];
                $this->activado_en = (!empty($res['activado_en']) ? strftime("%a %d/%b/%y %H:%M", strtotime($res['activado_en'])) : 'PIN NO ACTIVADO');
                $this->pre_activado = $res['pre_activado'];
                $this->maxima_activacion = $res['maxima_activacion'];
                $this->maxima_usuario = $res['maxima_usuario'];
            } else {
                $this->pin = null;
            }
        } elseif (func_num_args() == 2) {
            $objGr = new Grado($args[0]);
            $n = $BaseD->GetRow("SELECT MAX(consecutivo) n FROM pines p INNER JOIN cursos c on(p.curso = c.id) WHERE c.institucion = ?", array($objGr->institucion()));
            $y = $objGr->gradoNL();
            if (is_numeric($y) && $y < 10) {
                $y = "0$y";
            }
            $pin = $y . chr(rand(65, 90)) . ($objGr->institucion() + 79) . chr(rand(65, 90)) . rand(0, 9) . chr(rand(65, 90));
            $res = $BaseD->Execute("INSERT INTO pines (consecutivo, pin, curso, creado_por, año) VALUES (?, ?, ?, ?, ?)", array(($n['n'] + 1), $pin, $args[0], $args[1], $AÑO_ACTIVO));
            if ($res) {
                $this->consecutivo = ($n['n'] + 1);
                $this->pin = $pin;
                $this->grado = $args[0];
                $this->creado_por = $args[1];
                $this->creado_en = strftime("%a %d/%b/%y %H:%M");
            }
        } elseif (func_num_args() == 4) {
            $objGr = new Grado($args[0]);
            $n = $BaseD->GetRow("SELECT MAX(consecutivo) n FROM pines p INNER JOIN cursos c on(p.curso = c.id) WHERE c.institucion = ?", array($objGr->institucion()));
            $y = $objGr->gradoNL();
            if (is_numeric($y) && $y < 10) {
                $y = "0$y";
            }
            $pin = $y . chr(rand(65, 90)) . ($objGr->institucion() + 79) . chr(rand(65, 90)) . rand(0, 9) . chr(rand(65, 90));
            $res = $BaseD->Execute("INSERT INTO pines (consecutivo, pin, curso, creado_por, año, maxima_activacion, maxima_usuario) VALUES (?,?,?,?,?,?,?)", array(($n['n'] + 1), $pin, $args[0], $args[1], $AÑO_ACTIVO, $args[2], $args[3]));
            if ($res) {
                $this->consecutivo = ($n['n'] + 1);
                $this->pin = $pin;
                $this->grado = $args[0];
                $this->creado_por = $args[1];
                $this->creado_en = strftime("%a %d/%b/%y %H:%M");
                $this->maxima_activacion = $args[2];
                $this->maxima_usuario = $args[3];
            }
        }
    }

    function listar_pines($json = true)
    {
        global $BaseD;
        $lista = null;
        $res = $BaseD->Execute("SELECT pines.*, cursos.grado, instituciones.nombre  FROM `pines`, `cursos`, `instituciones` where cursos.id = pines.curso AND cursos.institucion = instituciones.id  ORDER BY `creado_en` DESC");
        if ($res) {
            $lista = array();
            while (!$res->EOF) {
                $lista[] = $res->fetchRow();
            }
        }

        return (!$json) ? $lista : json_encode($lista);
    }

    function actualizar_venta($n, $a, $c, $t)
    {
        global $BaseD;
        $con = $BaseD->Execute("SELECT pin FROM control_pines WHERE pin = ?", array($this->pin));
        if ($con->RecordCount() > 0)
            $res = $BaseD->Execute("UPDATE control_pines SET nombre = ?, apellido = ?, cedula = ?, telefono = ? WHERE pin = ?", array($n, $a, $c, $t, $this->pin));
        else
            $res = $BaseD->Execute("INSERT INTO control_pines (pin, nombre, apellido, cedula, telefono ) VALUES (?,?,?,?,?)", array($this->pin, $n, $a, $c, $t));

        if ($res)
            return true;
        else
            return false;
    }

    function pin()
    {
        return $this->pin;
    }

    function consecutivo()
    {
        return $this->consecutivo;
    }

    function valida()
    {
        if (is_null($this->pin())) {
            return 1;
        } else {
            return $this->activado_en();
        }
    }

    function activa($usuario, $quien = '')
    {
        global $BaseD;

        if (empty($quien)) {
            $quien = $usuario;
        }

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $quien);
        //$BaseD->debug = true;

        if (isset($this->maxima_usuario)) {
            $grado = new Grado($this->grado);

            if (($grado->institucion() == 1976 || $grado->institucion() == 1982 || $grado->institucion() == 1983)) {
                $max = strtotime($this->creado_en);
                $now = strtotime("-2 months");
                $diff = round(($max - $now) / (60 * 60 * 24));

                if ($diff > 0) {
                    $res = $BaseD->Execute("UPDATE pines SET activado_en = NOW(), activado_por = ?, maxima_usuario = DATE_ADD(NOW(), INTERVAL 6 MONTH) WHERE pin = ?", array($usuario, $this->pin()));
                } else {
                    $res = $BaseD->Execute("UPDATE pines SET activado_en = NOW(), activado_por = ? WHERE pin = ?", array($usuario, $this->pin()));
                }
            } else {
                $res = $BaseD->Execute("UPDATE pines SET activado_en = NOW(), activado_por = ? WHERE pin = ?", array($usuario, $this->pin()));
            }
        } else {
            $res = $BaseD->Execute("UPDATE pines SET activado_en = NOW(), activado_por = ?, maxima_usuario = DATE_ADD(NOW(), INTERVAL 12 MONTH) WHERE pin = ?", array($usuario, $this->pin()));
        }

        /*$user = new Usuario ($usuario);

        if ($user->curso()) {
         $curso = new Curso($user->curso());
         $curso->desmatricular($user->id());
        }
        $user->modificar($user->nombres(), $user->apellidos(), $user->correo(), null, $user->telefono(), null, $this->grado(), $this->institucion());
        $user->matricular($this->institucion());*/
        // 		$BaseD->debug = false;

        if ($res !== false) {
            return true;
        } else {
            return false;
        }
    }

    function cambia($grado, $quien)
    {
        global $BaseD;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $quien);
        $res = $BaseD->Execute("UPDATE pines SET curso = ? WHERE pin = ?", array($grado, $this->pin()));
        return $res;
    }

    function liberar($quien)
    {
        global $BaseD;
        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI'], $quien);
        $usuario = $BaseD->GetRow("SELECT * FROM usuarios WHERE pin_creacion = ?", array($this->pin()));
        if (($this->activado_por !== null) && !($usuario)) {
            $usuario = new Usuario($this->activado_por);
            if ($usuario->id() == -100) {
                $res = $BaseD->Execute("UPDATE pines SET activado_por = ?, activado_en = ? WHERE pin = ?", array(null, null, $this->pin()));
                return $res;
            }
        }
        return false;
    }

    function grado()
    {
        return $this->grado;
    }

    function institucion()
    {
        $grado = new Grado($this->grado);

        return $grado->institucion();
    }

    function activado_en()
    {
        return $this->activado_en;
    }

    function activado_por()
    {
        return $this->activado_por;
    }

    function creado_en()
    {
        return $this->creado_en;
    }

    function creado_por()
    {
        return $this->creado_por;
    }
    function pre_activado()
    {
        return $this->pre_activado;
    }
    function maxima_activacion()
    {
        return $this->maxima_activacion;
    }
    function maxima_usuario()
    {
        return $this->maxima_usuario;
    }

    function es_preescolar()
    {
        $obj = new Grado($this->grado());

        return $obj->es_preescolar();
    }
}

class Materia
{
    protected $materia;
    protected $id;
    protected $institucion;

    function __construct($id = "", $materia = "", $institucion = "")
    {
        global $BaseD;

        if (!empty($id)) {
            $reg = $BaseD->GetRow("SELECT * FROM materias WHERE id = ?", array($id));
        } else if (!empty($materia) && !empty($institucion)) {
            $reg = $BaseD->GetRow("SELECT * FROM materias WHERE materia = ? and institucion = ?", array($materia, $institucion));
            if ($reg == false) {
                $reg = $BaseD->Execute("INSERT INTO materias (materia, institucion) VALUES (?, ? )", array($materia, $institucion));
                $id = $BaseD->Insert_ID();
                $reg = $BaseD->GetRow("SELECT materia FROM materias WHERE id = ?", array($id));
            }
        }

        if ($reg !== false) {
            $this->institucion = $reg['institucion'];
            $this->materia = $reg['materia'];
            $this->id = $reg['id'];
        }
    }

    function nombre()
    {
        return $this->materia;
    }

    function id()
    {
        return $this->id;
    }

    function institucion()
    {
        return $this->institucion;
    }

    function borrar_materia()
    {
        global $BaseD;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);

        $BaseD->Execute("DELETE FROM grupos_materias WHERE materia = ?", array($this->id));
        if ($BaseD->Execute("DELETE FROM materias WHERE materia = ? AND institucion = ?", array($this->materia, $this->institucion))) {
            $this->borrar_cursos_lms($this->institucion, $this->materia);
            return (true);
        } else {
            return (false);
        }
    }

    function renombrar_materia($nuevo)
    {
        global $ADODB_TYPE, $CHML_CONFIG, $BaseD;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        include "$CHML_CONFIG";
        $BaseDCHML = NewADOConnection($ADODB_TYPE);
        $BaseDCHML->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseDCHML->SetCharSet('utf8');
        $rs = $BaseDCHML->Execute("SELECT id, description, title FROM course WHERE code LIKE ?", array("%-" . $this->id()));
        $ok = true;
        while (!$rs->EOF) {

            $desc = str_replace($this->nombre(), $nuevo, $rs->fields[1]);
            $title = str_replace($this->nombre(), $nuevo, $rs->fields[2]);
            $BaseDCHML->Execute("UPDATE course SET description = ?, title = ? WHERE id = ? ", array($desc, $title, $rs->fields[0]));
            $BaseDCHML->Execute("UPDATE c_tool_intro SET intro_text = ? WHERE c_id = ? and id = ? ", array('<h2 style="text-align: center;">Bienvenidos al ' . $desc . '</h2>', $rs->fields[0], "course_homepage"));
            $rs->MoveNext();
        }

        if ($BaseD->Execute("UPDATE materias SET materia = ? WHERE id = ? ", array($nuevo, $this->id()))) {
            return (true);
        } else {
            return (false);
        }
    }

    function borrar_cursos_lms($idcole, $materia)
    {
        global $ADODB_TYPE, $CHML_CONFIG;

        registro(__METHOD__, func_get_args(), $_SERVER['REQUEST_URI']);
        include "$CHML_CONFIG";

        $BaseD = NewADOConnection($ADODB_TYPE);
        $BaseD->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
        $BaseD->SetCharSet('utf8');
        //$BaseD->debug = true;
        //$BaseD->Execute('DELETE FROM course WHERE category_code = ? and title LIKE ?', array($idcole, $materia."%"))
        if ($BaseD->Execute("UPDATE course SET visibility = ? WHERE category_code = ? and title LIKE ?", array(4, $idcole, $materia . "%"))) {
            return (true);
        } else {
            return (false);
        }
    }
}

class avatar
{

    protected $id;
    protected $accesorio;
    protected $boca;
    protected $cabello;
    protected $cuerpo;
    protected $ojos;
    protected $ropa;
    protected $tipo;
    protected $imagen;
    protected $utilizado;


    function __construct($id)
    {
        global $BaseD;

        $reg = $BaseD->GetRow("SELECT * FROM avatar WHERE id = ?", array($id));

        if ($reg == true) {
            $this->id = $reg['id'];
            $this->accesorio = $reg['accesorio'];
            $this->boca = $reg['boca'];
            $this->cabello = $reg['cabello'];
            $this->cuerpo = $reg['cuerpo'];
            $this->ojos = $reg['ojos'];
            $this->ropa = $reg['ropa'];
        } else {
            $reg1 = $BaseD->Execute("INSERT INTO avatar (id, accesorio, boca, cabello, cuerpo, ojos, ropa) VALUES (?, 1, 1, 1, 1, 1, 1)", array($id));
            $this->id = $id;
            $this->accesorio = 1;
            $this->boca = 1;
            $this->cabello = 1;
            $this->cuerpo = 1;
            $this->ojos = 1;
            $this->ropa = 1;
        }
    }

    function Id()
    {
        return $this->id;
    }

    function Accesorio()
    {
        return $this->accesorio;
    }

    function Ropa()
    {
        return $this->ropa;
    }

    function Cuerpo()
    {
        return $this->cuerpo;
    }

    function Ojos()
    {
        return $this->ojos;
    }

    function Cabello()
    {
        return $this->cabello;
    }

    function Boca()
    {
        return $this->boca;
    }

    function setAtributes($id, $accesorio, $boca, $cabello, $cuerpo, $ojos, $ropa)
    {
        global $BaseD;
        $this->accesorio = $accesorio;
        $this->boca = $boca;
        $this->cabello = $cabello;
        $this->cuerpo = $cuerpo;
        $this->ojos = $ojos;
        $this->ropa = $ropa;
        $reg = $BaseD->Execute("UPDATE avatar SET accesorio = ?, boca = ?, cabello = ?, cuerpo = ?, ojos = ?, ropa = ? WHERE id = ?", array($accesorio, $boca, $cabello, $cuerpo, $ojos, $ropa, $id));
        if ($reg == true) {
            $reg2 = $BaseD->Execute("UPDATE imagen_usuario SET utilizado = 0 WHERE id_user = ?", array($id));
            return true;
        }
    }

    function setImage($id_user, $imagen, $tipo)
    {
        global $BaseD;
        $reg = $BaseD->GetRow("SELECT * FROM imagen_usuario WHERE id_user = ?", array($id_user));
        if ($reg == true) {
            $reg2 = $BaseD->Execute("UPDATE imagen_usuario SET imagen = ?, tipo = ?, utilizado = 1 WHERE id_user = ?", array($imagen, $tipo, $id_user));
        } else {
            $reg2 = $BaseD->Execute("INSERT INTO imagen_usuario (id, id_user, imagen, tipo, utilizado) VALUES (NULL,?,?,?,1)", array($id_user, $imagen, $tipo));
        }
    }

    function createAtributes($id, $accesorio, $boca, $cabello, $cuerpo, $ojos, $ropa)
    {
        global $BaseD;
        $this->id = $id;
        $this->accesorio = $accesorio;
        $this->boca = $boca;
        $this->cabello = $cabello;
        $this->cuerpo = $cuerpo;
        $this->ojos = $ojos;
        $this->ropa = $ropa;
        $reg = $BaseD->Execute("INSERT INTO avatar (id, accesorio, boca, cabello, cuerpo, ojos, ropa) VALUES (?, ?, ?, ?, ?, ?, ?)", array($this->id, $this->accesorio, $this->boca, $this->cabello, $this->cuerpo, $this->ojos, $this->ropa));

        if ($reg == true) {
            echo "agregado";
        }
    }
}

function xcopy($source, $dest, $permissions = 0755)
{
    // Check for symlinks
    if (is_link($source)) {
        return symlink(readlink($source), $dest);
    }

    // Simple copy for a file
    if (is_file($source)) {
        return copy($source, $dest);
    }

    // Make destination directory
    if (!is_dir($dest)) {
        mkdir($dest, $permissions);
    }

    // Loop through the folder
    $dir = dir($source);
    while (false !== $entry = $dir->read()) {
        // Skip pointers
        if ($entry == '.' || $entry == '..') {
            continue;
        }

        // Deep copy directories
        xcopy("$source/$entry", "$dest/$entry");
    }

    // Clean up
    $dir->close();
    return true;
}

function conectar_ldap($admin = 0)
{
    global $LDAP_URI, $DN_ADM, $PASS_ADM;
    // 	var_dump($LDAP_URI, $DN_ADM, $PASS_ADM);
    if (!isset($LDAP_URI)) {
        include '/var/www/Front/config.inc.php';
    }

    $ldapconn = ldap_connect($LDAP_URI)
        or die("No se pudo conectar al árbol LDAP");
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
    if ($admin) {
        $bind = ldap_bind($ldapconn, $DN_ADM, $PASS_ADM);
    } else {
        $bind = ldap_bind($ldapconn);
    }
    if (!$bind) {
        die('No se pudo autenticar con el árbol LDAP ' . ldap_error($ldapconn));
    }

    return $ldapconn;
}

/*
 *---------------------------------------------------------------------------------------------------------------------------
 * Older Version of Send Mail with PHPMailer
 * Update: 08/30/2018 - Manuel Gil
 *---------------------------------------------------------------------------------------------------------------------------
 *
 function enviar_correo($from, $to, $nombre, $msg_txt, $msg_html, $subject, $confirma = false, $imagen = '', $nom_imag = '')
{
    // global $smtp_params;
    include_once 'PHPMailer/PHPMailerAutoload.php';
    //SMTP Settings
    $mail = new PHPMailer;
    //$mail->SMTPDebug = 1;
    $mail->CharSet = 'UTF-8';
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'mail.educar.com.co';                   // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'notificaciones';                   // SMTP username
    $mail->Password = 'Notificaciones.2018*';             // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    if ($subject != 'SOPORTE SIE' || $subject != 'SOPORTE PLATAFORMA SIE') {
        $mail->AddReplyTo('noreply@educar.com.co', 'Plataformas Educar Editores');
        $mail->SetFrom('noreply@educar.com.co', 'Plataformas Educar Editores - NO RESPONDER');
        $mail->AddAddress($to, $nombre);
        // $mail->addBCC('noreply@educar.com.co');
    } else {
        $mail->SetFrom($from, $nombre);
        $mail->AddAddress('noreply@educar.com.co', 'Plataformas Educar Editores');
        if (!empty($imagen) && file_exists($imagen)) {
            $mail->AddAttachment($imagen, $nom_imag);
        }
    }

    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body = $msg_html;
    $mail->AltBody = $msg_txt;
    // $mail->WordWrap = 80;

    $suc = false;

    if (filter_var($to, FILTER_VALIDATE_EMAIL) !== false && strpos($to, 'nomail') === false && strpos($to, 'nocorreo') === false && $to != "noreply@educar.com.co" && $to != "noreply@educar.com.co") {
        $suc = $mail->Send();
    }

    //Success
    if ($suc && $confirma) {
        echo "<div class='alert alert-success'>Estimado(a) $nombre, hemos enviado un mensaje al correo electrónico '$to'.<br/>Por favor, revisa en tu bandeja de spam o correo no deseado.<br/>Si este no es tu correo, contáctanos haciendo <a href='http://localhost/soporte.php'>clic aquí</a>.</div>";
    }

    if (!$suc) {
        echo "<div class='alert alert-danger'>Ocurrio un error al enviar el correo: por favor, contáctanos haciendo <a href='http://localhost/soporte.php'>clic aquí</a>.<br/>{$mail->ErrorInfo}</div>";
    }
}
 */

/**
 *---------------------------------------------------------------------------------------------------------------------------
 * New Version of Send Mail with SendGrid
 * @author Manuel Gil <manuel.gil@educar.com.co>
 * @version 1.0.0 - 08/30/2018
 *---------------------------------------------------------------------------------------------------------------------------
 */
function enviar_correo($from, $to, $nombre, $msg_txt, $msg_html, $subject, $confirma = false, $imagen = '', $nom_imag = '', $vardump = false)
{
    include_once '/var/www/Front/resources/php/libs/SendGrid/mailer.class.php';

    $suc = false;

    if (strpos($to, 'nomail') === false && strpos($to, 'nocorreo') === false && strpos($to, 'prueba') === false) {
        $suc = Mailer::send($from, $to, $nombre, $msg_txt, $msg_html, $subject, $imagen, $nom_imag);
        if ($vardump) {
            echo $suc;
            die;
        }
    }

    //Success
    if ($suc && $confirma) {
        echo "<div class='alert alert-success'>Estimado(a) $nombre, hemos enviado un mensaje al correo electrónico '$to'.<br/>Por favor, revisa en tu bandeja de spam o correo no deseado.<br/>Si este no es tu correo, contáctanos haciendo <a href='http://localhost/soporte.php'>clic aquí</a>.</div>";
    }

    if (!$suc && $confirma) {
        echo "<div class='alert alert-danger'>Ocurrio un error al enviar el correo: por favor, contáctanos haciendo <a href='http://localhost/soporte.php'>clic aquí</a>.";
    }    
}

function enviar_correo_app($from, $to, $nombre, $msg_txt, $msg_html, $subject, $confirma = false, $imagen = '', $nom_imag = '')
{
    include_once '/var/www/Front/resources/php/libs/SendGrid/mailer.class.php';

    if (strpos($to, 'nomail') === false && strpos($to, 'nocorreo') === false) {
        Mailer::send($from, $to, $nombre, $msg_txt, $msg_html, $subject, $imagen, $nom_imag);
    }
}

function enviar_correo_plataforma_personalizada($from, $to, $nombre, $msg_txt, $msg_html, $subject, $confirma = false, $imagen = '', $nom_imag = '')
{
    include_once '/var/www/Front/resources/php/libs/SendGrid/mailer.class.php';

    $suc = false;

    if (strpos($to, 'nomail') === false && strpos($to, 'nocorreo') === false) {
        $suc = Mailer::send($from, $to, $nombre, $msg_txt, $msg_html, $subject, $imagen, $nom_imag);
    }

    //Success
    if ($suc && $confirma) {
        return "Estimado(a) $nombre, hemos enviado un mensaje al correo electrónico '$to'.<br/>Por favor, revisa en tu bandeja de spam o correo no deseado.";
    }

    if (!$suc && $confirma) {
        return "Ocurrio un error al enviar el correo.<br/>Por favor, inténtelo de nuevo más tarde.";
    }
}

function enviar_correo_masivo($from, $to, $nombre, $msg_txt, $msg_html, $subject, $confirma = false, $imagen = '', $nom_imag = '')
{
    global $smtp_params;

    include_once 'PHPMailer/PHPMailerAutoload.php';

    //SMTP Settings
    $mail = new PHPMailer;
    $mail->SMTPDebug = 1;
    $mail->CharSet = "UTF-8";
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = $smtp_params["auth"];
    $mail->Host = $smtp_params['host'];
    $mail->Port = $smtp_params['port'];
    $mail->Username = $smtp_params["username"];
    $mail->Password = $smtp_params["password"];
    //

    // if ($subject != 'SOPORTE SIE' && $subject != 'SOPORTE PLATAFORMA SIE') {
    // $mail->SetFrom('noreply@educar.com.co', 'Plataformas Educar Editores - NO RESPONDER');
    $mail->Subject = "$subject";
    //recipient
    // $mail->AddAddress($to, $nombre);
    // }
    // else {
    $mail->SetFrom($from, $nombre);
    // $mail->Subject = "$subject";
    // $to = 'solicitudesit@educar.com.co';
    $mail->AddAddress($to, 'Usuario');
    if (!empty($imagen) && file_exists($imagen)) {
        $mail->AddAttachment($imagen, $nom_imag);
    }
    // }

    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body = $msg_html;
    $mail->AltBody = $msg_txt;
    // $mail->WordWrap = 80;

    $suc = $mail->Send();
    //Success
    if ($suc && $confirma) {
        echo "<BR><BR><span style=\"color: #000; font-size: 20px;\"><span style=\"color: #004DD9; font-size: inherit;\">$nombre</span> se envió correctamente un correo a <span style=\"color: #004DD9; font-size: inherit;\">$to</span></span>";
    }
    if (!$suc && $confirma) {
        echo "Error al enviar el correo: " . $mail->ErrorInfo;
    }
}

function registro($metodo, $argumentos, $clase, $quien = '')
{
    global $BaseD, $ADMuser;

    $quien = (!empty($_SESSION['phpCAS']['user']) ? $_SESSION['phpCAS']['user'] : (empty($quien) && !empty($ADMuser) ? $ADMuser : $quien));
    $referrer = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : '';
    $BaseD->Execute("INSERT INTO log_2020 (quien, metodo, argumentos, contexto, ip, forward) VALUES (?, ?, ?, ?, ?, ?)", array($quien, $metodo, http_build_query($argumentos), json_encode($clase, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK), $_SERVER['REMOTE_ADDR'], $referrer));
}

function listar_all($rol = 'estudiante', $h = 1)
{

    global $BaseD;

    // 	$BaseD->debug = true;

    $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE R.rol = ? AND habilitado = ? ORDER BY institucion";
    $recordSet = $BaseD->Execute($sql, array($rol, $h));

    if ($recordSet) {
        $usuarios = array();
        while (!$recordSet->EOF) {
            if ($rol == 'estudiante') {
                $estudiante = new Usuario($recordSet->fields['usuario']);
                $c = new Institucion($estudiante->institucion());
                $usuario['id'] = $estudiante->id();
                $usuario['usuario'] = $estudiante->usuario();
                $usuario['nombres'] = $estudiante->nombres();
                $usuario['apellidos'] = $estudiante->apellidos();
                $usuario['mail'] = $estudiante->correo();
                $usuario['curso'] = $estudiante->grado() . $estudiante->curso();
                $usuario['idcurso'] = $estudiante->id_curso();
                $usuario['movil'] = $estudiante->telefono();
                $usuario['plataforma'] = $c->plataforma(true);
                $usuario['ciudad'] = $c->ciudad();
                $usuario['colegio'] = $c->nombre();
                $usuarios[] = $usuario;
            } else {

                $user = new Usuario($recordSet->fields['usuario']);
                $c = new Institucion($user->institucion());
                $usuario['id'] = $user->id();
                $usuario['usuario'] = $user->usuario();
                $usuario['nombres'] = $user->nombres();
                $usuario['apellidos'] = $user->apellidos();
                $usuario['mail'] = $user->correo();
                $usuario['movil'] = $user->telefono();
                $usuario['plataforma'] = $c->plataforma(true);
                $usuario['ciudad'] = $c->ciudad();
                $usuario['colegio'] = $c->nombre();
                $usuarios[] = $usuario;
            }
            $recordSet->MoveNext();
        }
    }

    return $usuarios;
    // 	$BaseD->debug = false;
}

function listar($institucion, $rol = 'estudiante', $h = 1)
{
    global $BaseD;

    // 	$BaseD->debug = true;
    if ($rol == 'administrador' || $rol == 'restringido') {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($rol, $h));
    } else if ($rol != 'estudiante') {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($institucion, $rol, $h));
    } else {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($institucion, $rol, $h));
    }


    if ($recordSet) {
        $usuarios = array();
        while (!$recordSet->EOF) {
            if ($rol == 'estudiante') {
                $estudiante = new Usuario($recordSet->fields['usuario']);
                $usuario['id'] = $estudiante->id();
                $usuario['usuario'] = $estudiante->usuario();
                $usuario['nombres'] = $estudiante->nombres();
                $usuario['apellidos'] = $estudiante->apellidos();
                $usuario['mail'] = $estudiante->correo();
                $usuario['curso'] = $estudiante->grado() . $estudiante->curso();
                $usuario['idcurso'] = $estudiante->id_curso();
                $usuario['idgrado'] = $estudiante->id_grado();
                $usuario['movil'] = $estudiante->telefono();
                $usuarios[] = $usuario;
            } else {
                $user = new Usuario($recordSet->fields['usuario']);
                $usuario['id'] = $user->id();
                $usuario['usuario'] = $user->usuario();
                $usuario['nombres'] = $user->nombres();
                $usuario['apellidos'] = $user->apellidos();
                $usuario['mail'] = $user->correo();
                $usuario['movil'] = $user->telefono();
                $usuario['puntos'] = $user->puntos();
                $usuario['puntos_x_mes'] = $user->puntos_x_mes(date("m"));
                $usuarios[] = $usuario;
            }
            $recordSet->MoveNext();
        }
    }

    return $usuarios;
    // 	$BaseD->debug = false;
}

function listar_carga_usuarios($institucion, $rol = 'estudiante', $h = 1)
{
    global $BaseD;

    // 	$BaseD->debug = true;
    if ($rol == 'administrador' || $rol == 'restringido') {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($rol, $h));
    } else if ($rol != 'estudiante') {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($institucion, $rol, $h));
    } else {
        $sql = "SELECT usuario FROM usuarios U LEFT JOIN roles R ON U.rol = R.id WHERE institucion = ? AND R.rol = ? AND habilitado = ? ORDER BY usuario";
        $recordSet = $BaseD->Execute($sql, array($institucion, $rol, $h));
    }

    if ($recordSet) {
        $usuarios = array();
        while (!$recordSet->EOF) {

            $user = new Usuario($recordSet->fields['usuario']);
            $cur = $user->listar_cursos_lms();
            $k = 0;
            foreach ($cur as $id => $value) {
                $usuario['id'] = $user->id();
                $usuario['usuario'] = $user->usuario();
                $usuario['nombres'] = $user->nombres();
                $usuario['apellidos'] = $user->apellidos();
                $usuario['curso'] = $value->nombre;
                if ($k == 0) {
                    $usuario['attr'] = array('usuario' => array('rowspan' => count($cur)), 'nombres' => array('rowspan' => count($cur)), 'apellidos' => array('rowspan' => count($cur)));
                } else {
                    $usuario['attr'] = array('usuario' => array('display' => 'none'), 'nombres' => array('display' => 'none'), 'apellidos' => array('display' => 'none'));
                }
                $usuarios[] = $usuario;
                $k++;
            }
            if ($k == 0) {
                $usuario['id'] = $user->id();
                $usuario['usuario'] = $user->usuario();
                $usuario['nombres'] = $user->nombres();
                $usuario['apellidos'] = $user->apellidos();
                $usuario['curso'] = "******";
                $usuario['attr'] = array('usuario' => array('rowspan' => 1), 'nombres' => array('rowspan' => 1), 'apellidos' => array('rowspan' => 1));
                $usuarios[] = $usuario;
            }
            $recordSet->MoveNext();
        }
    }

    return $usuarios;
    // 	$BaseD->debug = false;
}

function listar_colegios($Fjson = true, $ciudad = '%', $NoId = false, $ConCiudad = false)
{
    global $BaseD;

    $listado = array();
    if ($ConCiudad) {
        $recordSet = $BaseD->Execute("SELECT id, nombre, ciudad FROM instituciones WHERE ciudad LIKE ? ORDER BY nombre ASC", array($ciudad));
    } else {
        $recordSet = $BaseD->Execute("SELECT id, nombre FROM instituciones WHERE ciudad LIKE ? ORDER BY nombre ASC", array($ciudad));
    }

    if (!$recordSet) {
        $listado = null;
    } else {
        while (!$recordSet->EOF) {
            if ($ConCiudad) {
                $name = $recordSet->fields['nombre'] . " - " . $recordSet->fields['ciudad'];
            } else {
                $name = $recordSet->fields['nombre'];
            }
            if ($NoId) {
                $listado[] = $name;
            } else {
                $listado[$recordSet->fields['id']] = $name;
            }
            $recordSet->MoveNext();
        }
        $recordSet->Close();
    }

    if ($Fjson) {
        return json_encode($listado);
    } else {
        return $listado;
    }
}

function listar_ciudades($Fjson = true)
{
    global $BaseD;

    $listado = array();
    $recordSet = $BaseD->Execute("SELECT ciudad FROM instituciones GROUP BY ciudad ORDER BY ciudad");
    if (!$recordSet) {
        $listado = null;
    } else {
        while (!$recordSet->EOF) {
            $listado[] = $recordSet->fields['ciudad'];
            $recordSet->MoveNext();
        }
        $recordSet->Close();
    }

    if ($Fjson) {
        return json_encode($listado);
    } else {
        return $listado;
    }
}

function ultima_actualizacion_informes()
{
    global $BaseD;

    $reg = $BaseD->GetRow("SELECT MAX(CONVERT_TZ(momento,'+00:00','-05:00')) cuando FROM Actualizaciones_Informes WHERE accion = 'Final'");

    return $reg['cuando'];
}

function reparar()
{
    global $BaseD;
    global $ADODB_TYPE, $CHML_CONFIG, $CHML_COUR, $CUOTA_LMS_CURSO;

    $Global = $BaseD;
    //$Global->debug = true;
    registro(__METHOD__, func_get_args(), $this);
    include "$CHML_CONFIG";

    $LMS = NewADOConnection($ADODB_TYPE);
    $LMS->Connect($_configuration['db_host'], $_configuration['db_user'], $_configuration['db_password'], $_configuration['main_database']);
    $LMS->SetCharSet('utf8');
    //	$LMS->debug = true;
    $LMS->Execute("START TRANSACTION;");
    $LMS->Execute("DELETE FROM course_rel_user WHERE status != 4");
    $LMS->Execute("DELETE FROM user WHERE status = 5");
    $recordSet = $Global->Execute("SELECT usuario FROM usuarios WHERE usuario != 'administrador'");
    $status = 5;
    while (!$recordSet->EOF) {
        echo "\nRepara usuario: " . $recordSet->fields['usuario'];
        $usuario = new Usuario($recordSet->fields['usuario']);
        $id = $usuario->id();
        if (!empty($id)) {
            // 				$Global->Execute("UPDATE pines SET activado_por = NULL, activado_en = NULL WHERE pin = ?", array($recordSet->fields['pin']));

            $check_usuarios = $LMS->GetRow("SELECT user_id FROM user WHERE username = ?", array($usuario->usuario()));
            if (count($check_usuarios)) {
                $LMS->Execute("UPDATE user SET lastname = ?, firstname = ?, user_id = ?, id = ? WHERE username = ?", array($usuario->apellidos(), $usuario->nombres(), $usuario->id(), $usuario->id(), $usuario->usuario()));
            } else {
                $LMS->Execute("INSERT INTO user (user_id, id, lastname, firstname, username, username_canonical, password, auth_source, email, status, language, registration_date, expiration_date, active) VALUES (?, ?, ?, ?, ?, ?, '', 'cas', ?, ?, 'spanish_latin', NOW(), DATE_ADD(NOW(), INTERVAL 14 MONTH), 1)", array($usuario->id(), $usuario->id(), $usuario->apellidos(), $usuario->nombres(), mb_convert_case($this->usuario, MB_CASE_LOWER, "UTF-8"), mb_convert_case($this->usuario, MB_CASE_LOWER, "UTF-8"), $usuario->correo(), ($usuario->soy_estudiante() ? 5 : 1)));
            }

            /*			$LMS->Execute("INSERT INTO user (user_id, lastname, firstname, status,username, email, auth_source, language, active) VALUES(?, ?, ?, ?, ?, ?, 'cas', 'spanish_latin', 1)", array($usuario->id(), $usuario->apellidos(), $usuario->nombres(), ($usuario->soy_estudiante() ? 5 : 1), $usuario->usuario(), $usuario->correo()));*/


            if (!$usuario->soy_estudiante()) {
                $recordSet2 = $Global->Execute("SELECT grupo_materia FROM grupos_profesores WHERE profesor = ?", array($usuario->id()));
                while (!$recordSet2->EOF) {
                    $rs = $Global->Execute(
                        "SELECT grupo, materia FROM grupos_materias WHERE id = ?",
                        array(
                            $recordSet2->fields['grupo_materia']
                        )
                    );
                    while (!$rs->EOF) {
                        $code = $rs->fields['grupo'] . "-" . $rs->fields['materia'];
                        $x = $Global->GetRow("SELECT id FROM course WHERE code = ?", array($code));
                        $Ncurso = $x['id'];

                        $LMS->Execute(
                            'INSERT INTO course_rel_user (user_id, status, is_tutor, sort, user_course_cat, relation_type, legal_agreement, c_id)
							VALUES (?, 1, 0, 1, 0, 0, 0, ?)',
                            array($usuario->id(), $Ncurso)
                        );

                        /*$LMS->Execute("INSERT INTO course_rel_user (course_code, user_id, status, group_id, tutor_id, sort, user_course_cat, legal_agreement)
                                  VALUES (?, ?, 1, 0, 0, 1, 0, 0)", array($rs->fields['grupo']."-".$rs->fields['materia'], $usuario->id()));*/
                        $rs->MoveNext();

                        echo "  info: $code <-" . $usuario->id();
                    }

                    $recordSet2->MoveNext();
                }
            } else {
                $recordSet2 = $Global->Execute("SELECT grupo FROM grupos_estudiantes WHERE estudiante = ?", array($usuario->id()));
                while (!$recordSet2->EOF) {
                    $rs = $Global->Execute(
                        "SELECT grupo, materia FROM grupos_materias WHERE grupo = ?",
                        array(
                            $recordSet2->fields['grupo']
                        )
                    );
                    while (!$rs->EOF) {
                        $x = $Global->GetRow("SELECT id FROM course WHERE code = ?", array($rs->fields['grupo'] . "-" . $rs->fields['materia']));
                        $Ncurso = $x['id'];

                        $LMS->Execute('INSERT INTO course_rel_user (user_id, status, is_tutor, sort, user_course_cat, relation_type, legal_agreement, c_id) VALUES (?, 5, 0, 1, 0, 0, 0, ?)', array($usuario->id(), $Ncurso));

                        /*$LMS->Execute("INSERT INTO course_rel_user (course_code, user_id, status, group_id, tutor_id, sort, user_course_cat, legal_agreement)
                                  VALUES (?, ?, 5, 0, 0, 1, 0, 0)", array(
                                   $rs->fields['grupo']."-".$rs->fields['materia'], $usuario->id()	));*/
                        $rs->MoveNext();

                        echo "  info: " . $rs->fields['grupo'] . "-" . $rs->fields['materia'] . " <-" . $usuario->id();
                    }

                    $recordSet2->MoveNext();
                }
            }
        }
        $recordSet->MoveNext();
    }
    $LMS->Execute("COMMIT");
    // 	$Global->debug = false;
}

function dar_bienvenida($usuario, $password)
{
    global $BaseD;

    $usuario = new Usuario($usuario);
    $institucion = new Institucion($usuario->institucion());
    $plataforma = $institucion->plataforma(true);
    $fecha = date("Y-m-d H:i:s");

    $html = "<html><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /><head>";
    $html .= "<!-- Estilos --><style>";
    $html .= "@import url(http://fonts.googleapis.com/css?family=Dosis:400,700);";
    $html .= "@import url(https://fonts.googleapis.com/css?family=Dosis:400,700);";
    $html .= "body{font-family:'Dosis',sans-serif!important}";
    $html .= ".colorgris{color:#333}.colorzul{color:#00ACB0}.colorgriscuerpo{color:#666;font-family:'Dosis',sans-serif;text-align:center;font-size:17px}";
    $html .= ".nombre{color:#666;font-family:'Dosis',sans-serif;font-weight:700;font-size:23px;z-index:-1000;margin-top:-60px}.contenedor{text-align:center;position:relative}";
    $html .= ".contenedortextomensaje{margin-top:50px}.spam{font-size:13px}.linea{z-index:-10000}#textoimagen{display:inline-block;vertical-align:top;text-align:left;padding-top:80px}";
    $html .= "</style></head>";
    $html .= "<body><div class='contenedor'>";

    if (($plataforma == "SIE" || $plataforma == "SIEPLUS") && $usuario->soy_preescolar()) {
        $subject = "Bienvenido(a) a SIE PRESCHOOL";

        $html .= "<img src='http://localhost/images/emailnotificaciones/sie_preshool_bin_cabecera.png'>";
        $html .= "<div class='nombre'>{$usuario->nombres()} {$usuario->apellidos()}</div><div class='contenedortextomensaje colorgriscuerpo'>Para <b>EDUCAR</b> es un gusto tenerte en nuestra plataforma,<br>recuerda que tus datos de acceso son:<br><br>";
        $html .= "<b>Usuario:</b> {$usuario->usuario()}<br><b>Contraseña:</b> {$password}<br><br>";
        $html .= "Dentro de nuestra plataforma contarás con herramientas como:<br><br><br><center><img src='http://localhost/images/emailnotificaciones/sie_preshool_bin_herramientas.png'></center><br><br><div><img src='http://localhost/images/emailnotificaciones/sie_preschool_tutoriales.png' style='width: 400px; padding-right: 20px'>";
        $html .= "<p id='textoimagen'>Para conocer mejor tu<br>plataforma puedes acceder<br>a nuestros tutoriales.<br><br><b>Ingresa a tu avatar y pulsa<br>el botón \"TUTORIALES\". </b></p></div><br><br>Para ingresar a tu plataforma, puedes escribir la <br>siguiente dirección en tu navegador:<br><b>www.educar.com.co/plataformas</b> ó <br><br><a href='http://educar.com.co/plataformas/'>";
        $html .= "<img src='http://localhost/images/emailnotificaciones/sie_preschool_boton_bin.png'></a>";
    } else if ($plataforma == "SIE" || $plataforma == "SIEPLUS") {
        $subject = "Bienvenido(a) a SIE";

        $html .= "<img src='http://localhost/images/emailnotificaciones/sie_bin_cabecera.png'>";
        $html .= "<div class='nombre'>{$usuario->nombres()} {$usuario->apellidos()}</div><div class='contenedortextomensaje colorgriscuerpo'>Para <b>EDUCAR</b> es un gusto tenerte en nuestra plataforma,<br>recuerda que tus datos de acceso son:<br><br>";
        $html .= "<b>Usuario:</b> {$usuario->usuario()}<br><b>Contraseña:</b> {$password}<br><br>";
        $html .= "Dentro de nuestra plataforma contarás con herramientas como:<br><br><br><center><img src='http://localhost/images/emailnotificaciones/sie_bin_herramientas.png'></center><br><br><div><img src='http://localhost/images/emailnotificaciones/sie_tutoriales.png' style='width: 400px; padding-right: 20px'>";
        $html .= "<p id='textoimagen'>Para conocer mejor tu<br>plataforma puedes acceder<br>a nuestros tutoriales.<br><br><b>Ingresa a tu avatar y pulsa<br>el botón \"TUTORIALES\". </b></p></div><br><br>Para ingresar a tu plataforma, puedes escribir la <br>siguiente dirección en tu navegador:<br><b>www.educar.com.co/plataformas</b> ó <br><br><a href='http://educar.com.co/plataformas/'>";
        $html .= "<img src='http://localhost/images/emailnotificaciones/sie_boton_bin.png'></a>";
    } else if ($plataforma == "EDUCLASS") {
        $subject = "Bienvenido(a) a EDUCLASS";

        $html .= "<img src='http://localhost/images/emailnotificaciones/educlass_bin_cabecera.png'>";
        $html .= "<div class='nombre'>{$usuario->nombres()} {$usuario->apellidos()}</div><div class='contenedortextomensaje colorgriscuerpo'>Para <b>EDUCAR</b> es un gusto tenerte en nuestra plataforma,<br>recuerda que tus datos de acceso son:<br><br>";
        $html .= "<b>Usuario:</b> {$usuario->usuario()}<br><b>Contraseña:</b> {$password}<br><br>";
        $html .= "Dentro de nuestra plataforma contarás con herramientas como:<br><br><br><center><img src='http://localhost/images/emailnotificaciones/educlass_bin_herramientas.png'></center><br><br><div><img src='http://localhost/images/emailnotificaciones/educlass_tutoriales.png' style='width: 400px; padding-right: 20px'>";
        $html .= "<p id='textoimagen'>Para conocer mejor tu<br>plataforma puedes acceder<br>a nuestros tutoriales.<br><br><b>Ingresa a tu avatar y pulsa<br>el botón \"TUTORIALES\". </b></p></div><br><br>Para ingresar a tu plataforma, puedes escribir la <br>siguiente dirección en tu navegador:<br><b>www.educar.com.co/plataformas</b> ó <br><br><a href='http://educar.com.co/plataformas/'>";
        $html .= "<img src='http://localhost/images/emailnotificaciones/educlass_boton_bin.png'></a>";
    } else {
        $subject = "Bienvenido(a) a {$plataforma}";

        $html .= "<img src='http://localhost/images/emailnotificaciones/estandar_cabecera.png'>";
        $html .= "<div class='nombre'>{$usuario->nombres()} {$usuario->apellidos()}</div><div class='contenedortextomensaje colorgriscuerpo'>Para <b>EDUCAR</b> es un gusto tenerte en nuestra plataforma,<br>recuerda que tus datos de acceso son:<br><br>";
        $html .= "<b>Usuario:</b> {$usuario->usuario()}<br><b>Contraseña:</b> {$password}<br><br>";
        $html .= "Para ingresar a tu plataforma, puedes escribir la <br>siguiente dirección en tu navegador:<br><b>www.educar.com.co/plataformas</b>ó <br><br><a href='http://educar.com.co/plataformas/'>";
        $html .= "<img src='http://localhost/images/emailnotificaciones/estantar_bien_boton.png'></a>";
    }

    $html .= "<br><br><div class='spam'>Si este mensaje ha llegado a su correo no deseado, por favor presione el botón <b>'Esto no es Spam'</b>.</div>";
    $html .= "<br></div><img src='http://localhost/images/emailnotificaciones/footer.png'></div></body></html>";

    $correo = strtolower($usuario->correo());

    enviar_correo("noreply@educar.com.co", "{$correo}", "{$usuario->nombres()} {$usuario->apellidos()}", "", "{$html}", "{$subject}");

    if ($usuario->soy_estudiante()) {
        enviar_correo("noreply@educar.com.co", "{$usuario->correop()}", "{$usuario->nombresp()}", "", "{$html}", "{$subject}");
    }

    $sql = "INSERT INTO `notificaciones` (`usuario`, `quien`, `notificacion`, `fecha_creacion`, `fecha_notificacion`, `institucion`, `curso`, `code`, `ref`, `to_group_id`, `tool`, `lastedit_type`, `link`, `estado`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    $BaseD->GetRow($sql, array($usuario->id(), $usuario->usuario(), 0, $fecha, $fecha, $usuario->institucion(), $subject, "", 0, null, "welcome", "", "", 1));
}

function dar_bienvenida_plataforma_personalizada($usuario, $password, $plataforma)
{
    $usuario = new Usuario($usuario);

    switch ($plataforma) {
        case 'myclassflix':
            $html = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN'
                            'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                            <html xmlns='http://www.w3.org/1999/xhtml' lang='es' xml:lang='es'>
                            <head>
                            <meta charset='UTF-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta http-equiv='X-UA-Compatible' content='ie=edge'>
                            <meta name='robots' content='noindex, nofollow'>
                            <style>
                            @import url('https://fonts.googleapis.com/css?family=Tajawal:400,700');
                            @import url('http://fonts.googleapis.com/css?family=Tajawal:400,700');
                            *,html,body{font-family:'Tajawal',sans-serif!important}
                            body{margin:0;Margin:0;padding:0;width:100%!important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}
                            center{width:100%;min-width:580px}
                            table{border-spacing:0;border-collapse:collapse}
                            td{word-wrap:break-word;-webkit-hyphens:auto;-moz-hyphens:auto;hyphens:auto;border-collapse:collapse!important}
                            table,tr,td{padding:0}
                            table.body{height:100%;width:100%}
                            table.float-center,td.float-center,th.float-center{margin:0 auto;Margin:0 auto;float:none;text-align:center}
                            table.container{width:580px;margin:0 auto;Margin:0 auto;text-align:inherit}
                            table.row{padding:0;width:100%;position:relative}
                            table.container table.row{display:table}
                            td.medium-1,th.medium-1{width:8.33333%!important}
                            td.medium-2,th.medium-2{width:16.66667%!important}
                            td.medium-3,th.medium-3{width:25%!important}
                            td.medium-4,th.medium-4{width:33.33333%!important}
                            td.medium-5,th.medium-5{width:41.66667%!important}
                            td.medium-6,th.medium-6{width:50%!important}
                            td.medium-7,th.medium-7{width:58.33333%!important}
                            td.medium-8,th.medium-8{width:66.66667%!important}
                            td.medium-9,th.medium-9{width:75%!important}
                            td.medium-10,th.medium-10{width:83.33333%!important}
                            td.medium-11,th.medium-11{width:91.66667%!important}
                            td.medium-12,th.medium-12{width:100%!important}
                            h1{font-weight:700;color:#28ada3;text-align:center}
                            h2{font-weight:700;color:#4b4b4c;text-align:center}
                            h3{font-weight:700;color:#727176;text-align:center}
                            h4{line-height:0.1;font-weight:400;color:#808080;text-align:center}
                            p.text-justify{font-family:'Tajawal',sans-serif!important;font-size:16px;font-weight:400;color:#808080;text-align:justify}
                            p.text-center{font-family:'Tajawal',sans-serif!important;font-size:16px;font-weight:400;color:#808080;text-align:center}
                            hr{width:25px;border:2.5px solid #28ada3}
                            a{font-weight:700;color:#28ada3;text-decoration:none}
                            </style>
                            </head>
                            <body>
                            <span class='preheader'></span><table class='body'><td class='center' align='center' valign='top'><center data-parsed=''>
                            <table align='center' class='container float-center'><tbody><tr><td>
                            <table class='row'><tbody><tr><td class='medium-12'><img src='https://www.myclassflix.com/mailer/assets/images/PIEZAS-16.png' alt=''>
                            </td></tr><tr><td class='medium-12'><br/>
                            <h1>¡BIENVENIDO!</h1>
                            <h2>{$usuario->nombres()} {$usuario->apellidos()}</h2>
                            <p class='text-center'>Queremos informarte que desde este momento eres parte de
                            <br/>nuestro grupo de estudiantes y estamos felices de contar contigo.
                            <br/><br/>Recuerda que tus datos de acceso son:</p><br/><p class='text-center'>
                            <b>Usuario:</b> {$usuario->usuario()}<br/><b>Contraseña:</b> {$password}
                            </p><br/><br/></td></tr><tr><td class='medium-12'><img src='https://www.myclassflix.com/mailer/assets/images/Recurso%2013.png' alt=''>
                            </td></tr></tbody></table></td></tr></tbody></table></center></td></table>
                            <!-- prevent Gmail on iOS font size manipulation -->
                            <div style='display:none; white-space:nowrap; font:15px courier; line-height:0;'>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                            </body>
                            </html>";
            break;

        case 'nuevosaber':
            $html = "<!DOCTYPE html
                            PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                            <html xmlns='http://www.w3.org/1999/xhtml' lang='es' xml:lang='es'>
                            <head>
                            <meta charset='UTF-8'>
                            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                            <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
                            <meta http-equiv='X-UA-Compatible' content='ie=edge'>
                            <meta name='robots' content='noindex, nofollow'>
                            <style>
                            @font-face{font-family:Dosis;font-style:normal;font-weight:400;font-display:swap;src:local('Dosis Regular'),local('Dosis-Regular'),url(https://fonts.gstatic.com/s/dosis/v8/HhyaU5sn9vOmLzlmC_W6EQ.woff2) format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:400;font-display:swap;src:local('Dosis Regular'),local('Dosis-Regular'),url(https://fonts.gstatic.com/s/dosis/v8/HhyaU5sn9vOmLzloC_U.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:700;font-display:swap;src:local('Dosis Bold'),local('Dosis-Bold'),url(https://fonts.gstatic.com/s/dosis/v8/HhyXU5sn9vOmLzHTLuCLMItyTA.woff2) format('woff2');unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}
                            @font-face{font-family:Dosis;font-style:normal;font-weight:700;font-display:swap;src:local('Dosis Bold'),local('Dosis-Bold'),url(https://fonts.gstatic.com/s/dosis/v8/HhyXU5sn9vOmLzHTLuCFMIs.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
                            body,h1,h2,h3,h4,h5,h6{font-family:Dosis,sans-serif!important;color:#1a1a1a;text-align:center}
                            body{margin:0;Margin:0;padding:0;width:100%!important;min-width:100%;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;box-sizing:border-box}
                            center{width:100%;min-width:580px}
                            table{border-spacing:0;border-collapse:collapse}
                            td{word-wrap:break-word;-webkit-hyphens:auto;-moz-hyphens:auto;hyphens:auto;border-collapse:collapse!important}
                            table,td,tr{padding:0}
                            table.body{height:100%;width:100%}
                            table.float-center,td.float-center,th.float-center{margin:0 auto;Margin:0 auto;float:none;text-align:center}
                            table.container{width:580px;margin:0 auto;Margin:0 auto;text-align:inherit}
                            table.row{padding:0;width:100%;position:relative}
                            table.container table.row{display:table}
                            td.medium-1,th.medium-1{width:8.33333%!important}
                            td.medium-2,th.medium-2{width:16.66667%!important}
                            td.medium-3,th.medium-3{width:25%!important}
                            td.medium-4,th.medium-4{width:33.33333%!important}
                            td.medium-5,th.medium-5{width:41.66667%!important}
                            td.medium-6,th.medium-6{width:50%!important}
                            td.medium-7,th.medium-7{width:58.33333%!important}
                            td.medium-8,th.medium-8{width:66.66667%!important}
                            td.medium-9,th.medium-9{width:75%!important}
                            td.medium-10,th.medium-10{width:83.33333%!important}
                            td.medium-11,th.medium-11{width:91.66667%!important}
                            td.medium-12,th.medium-12{width:100%!important}
                            p.text-justify{font-size:16px;font-weight:400;text-align:justify}
                            p.text-center{font-size:16px;font-weight:400;text-align:center}
                            a{font-weight:700;color:#45b075;text-decoration:none}
                            </style>
                            </head>
                            <body>
                            <span class='preheader'></span><table class='body'><td class='center' align='center' valign='top'><center data-parsed=''>
                            <table align='center' class='container float-center'><tbody><tr><td>
                            <table class='row'><tbody><tr><td class='medium-12'><img
                            src='http://localhost/images/emailnotificaciones/header-welcome-saber.png'
                            alt=''></td></tr><tr><td class='medium-12'><br/><h1>¡BIENVENIDO!</h1><h2>{$usuario->nombres()} {$usuario->apellidos()}</h2>
                            <p class='text-center'>Te informamos que desde este momento eres parte
                            de nuestro grupo de estudiantes que se animaron a<br/>prepararse para sus <strong style='color: #45b075;'>Pruebas de
                            Estado</strong> de una manera distinta, y estamos felices de contar contigo.<br/><br/>Recuerda que tus datos de acceso son:</p><br/>
                            <p class='text-center'><b>Usuario: </b>{$usuario->usuario()}<br/><b>Contraseña: </b>{$password}</p><p class='text-center'>
                            <img src='http://localhost/images/emailnotificaciones/welcome-saber.png'
                            alt=''></p><br/><br/></td></tr><tr><td class='medium-12'><img
                            src='http://localhost/images/emailnotificaciones/footer-saber.png'
                            alt=''></td></tr></tbody></table></td></tr></tbody></table></center></td></table>
                            <!-- prevent Gmail on iOS font size manipulation -->
                            <div style='display:none; white-space:nowrap; font:15px courier; line-height:0;'>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                            </body>
                            </html>";
            break;
    }

    $correo = strtolower($usuario->correo());

    enviar_correo_plataforma_personalizada('noreply@educar.com.co', "{$correo}", "{$usuario->nombres()} {$usuario->apellidos()}", "", "{$html}", "Bienvenido(a) a " . strtoupper($plataforma));

    if ($usuario->soy_estudiante()) {
        enviar_correo_plataforma_personalizada('noreply@educar.com.co', "{$usuario->correop()}", "{$usuario->nombresp()}", "", "{$html}", "Bienvenido(a) a " . strtoupper($plataforma));
    }
}

function send_push_notification($title, $message, $userId)
{
    global $BaseD;

    $app_id = "78b6cc76-945b-4b3b-8616-0d6d20e566dd";
    $rest_api_key = "ZDE3NDA2NDQtYjczNS00ZGIyLTgyOWItNTdhZDFjZjE2ZTlm";

    $devices = array();
    $res = $BaseD->Execute("SELECT player_id FROM usuarios_dispositivos WHERE usuario = ? ", array($userId));

    while (!$res->EOF) {
        $device = $res->fields['player_id'];
        array_push($devices, $device);
        $res->MoveNext();
    }

    $heading = array(
        "en" => $title,
        "es" => $title
    );

    $content = array(
        "en" => $message,
        "es" => $message
    );

    $fields = array(
        'app_id' => $app_id,
        'include_player_ids' => $devices,
        'headings' => $heading,
        'contents' => $content
    );

    $fields = json_encode($fields);

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json; charset=utf-8',
        'Authorization: Basic ' . $rest_api_key
    ));

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    curl_close($ch);
}


// $BaseD->Close();
