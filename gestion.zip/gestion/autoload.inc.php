<?php

function autoloader($className)
{
    if (is_readable("app/models/$className.class.php")) {
        require_once "app/models/$className.class.php";
    }
}

spl_autoload_register('autoloader');

?>